# Editor Collab v2

Build levels together with friends, on PC and Android. **No server needed.**

## How it works
1. **You:** open your level in the editor, tap the collab button, press **Send**. Your level is copied to the clipboard.
2. Paste it to your friend in Discord (or any chat). If it is too long for a message, paste it into a text file and send the file.
3. **Friend:** copies the whole message, opens the editor, taps the collab button, presses **Receive**. The level is imported as a new local level called `<level> (collab)`.
4. They edit and decorate, press **Send**, and message it back.
5. You copy their message, open **your** level, press **Receive**. Their changes are merged into your level - your own edits are kept.

## The rule
A level you *received* can **never be published** by you. Only the original owner can publish it.

## Good to know
- Merging works on objects. If you both edit the *same* object, both versions are kept - delete the extra one.
- Receive while editing the matching level to merge; anywhere else it imports a new copy.
- Very big levels may not fit in the clipboard on some phones. If Send says nothing was copied, trim the level or send in parts.
