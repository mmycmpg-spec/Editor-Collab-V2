# Editor Collab v2

Build levels together with friends, on PC and Android. **No server needed.**

## Sessions
- **Create Session** - you host the open level. Your session code is copied to the clipboard. Send it to your friends (Discord, any chat; if it is too long, send it as a .txt file).
- **Join Session** - copy the host's code, open the editor, press Join Session. You are **teleported into the level** (imported as a new local level `<name> (collab)`).
- **Share Level** - copies your current version of the level so you can send it to friends.
- **Sync Now** - copy a friend's level code, open the matching level, press Sync Now. Their changes are merged into yours.
- **Leave Session** - ends the session.

## The rule
A level you *received* can **never be published** by you. Only the original owner can publish it.

## Good to know
- The session code is the level itself, so it is long.
- If you both edit the *same* object, both versions are kept - delete the extra one.
