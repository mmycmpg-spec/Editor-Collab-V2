# Editor Collab v2

Build levels together with friends, on PC and Android.

## How it works
1. **Host:** open your level in the editor, tap the collab button, press **Create**. The session ID is copied for you - send it to your friend.
2. **Friend:** open the editor, tap the collab button, press **Join**, paste the ID. The level is imported as a **new local level** named `<level> (collab)`.
3. Both of you edit. Press **Sync Now** to swap changes - your edits and your friends' edits are merged. The editor reloads when friends' changes come in.
4. **Auto Sync** uploads your own changes every 5 seconds. It never reloads your editor.

## The rule
A level you *received* can **never be published** by you. Only the original owner can publish it.

## Setup
You need a collab server running somewhere your friends can reach (see the `server` folder in the source). Put its address in this mod's settings. Everyone must use the same address.

## Good to know
- If two people move/edit the *same* object between syncs, both versions are kept - delete the extra one.
- Merging works on objects, so deletions and additions from both sides are combined.
