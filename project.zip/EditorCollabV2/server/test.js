'use strict';
const assert = require('assert');
const server = require('./server');

async function main() {
  await new Promise((r) => server.listen(0, r));
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (m) => (await fetch(base + '/message', { method: 'POST', body: JSON.stringify(m) })).json();

  assert.strictEqual(await (await fetch(base)).text(), 'Editor Collab v2 server OK');

  const c = await call({ type: 'CREATE_SESSION', userId: 'A', username: 'Alice', levelName: 'Lvl', levelData: 'v1' });
  assert(c.ok && /^[A-Z2-9]{6}$/.test(c.sessionId));
  const id = c.sessionId;

  const j = await call({ type: 'JOIN_SESSION', sessionId: id.toLowerCase(), userId: 'B', username: 'Bob' });
  assert(j.ok && j.levelData === 'v1' && j.ownerName === 'Alice' && j.version === 1 && !j.isOwner);

  // Bob pushes, Alice (still on v1) conflicts and gets Bob's copy
  assert((await call({ type: 'PUSH', sessionId: id, userId: 'B', baseVersion: 1, levelData: 'bob' })).version === 2);
  const conflict = await call({ type: 'PUSH', sessionId: id, userId: 'A', baseVersion: 1, levelData: 'alice' });
  assert(!conflict.ok && conflict.conflict && conflict.levelData === 'bob' && conflict.version === 2);
  assert((await call({ type: 'PUSH', sessionId: id, userId: 'A', baseVersion: 2, levelData: 'merged' })).version === 3);

  // PULL only returns data when newer
  const p1 = await call({ type: 'PULL', sessionId: id, userId: 'B', sinceVersion: 2 });
  assert(p1.changed && p1.levelData === 'merged');
  const p2 = await call({ type: 'PULL', sessionId: id, userId: 'B', sinceVersion: 3 });
  assert(!p2.changed && p2.levelData === undefined);

  // Presence
  const st = await call({ type: 'STATUS', sessionId: id, userId: 'A', username: 'Alice' });
  assert.deepStrictEqual(st.collaborators, ['Bob']);

  // Bob leaves, owner leaves -> session closed for everyone
  await call({ type: 'LEAVE_SESSION', sessionId: id, userId: 'B' });
  assert.deepStrictEqual((await call({ type: 'STATUS', sessionId: id, userId: 'A' })).collaborators, []);
  await call({ type: 'LEAVE_SESSION', sessionId: id, userId: 'A' });
  const gone = await call({ type: 'STATUS', sessionId: id, userId: 'B' });
  assert(!gone.ok && gone.closed);

  assert(!(await call({ type: 'NOPE' })).ok);
  assert(!(await call({ type: 'JOIN_SESSION', sessionId: 'ZZZZZZ', userId: 'B' })).ok);
  console.log('server tests passed');
  server.close();
}
main().catch((e) => { console.error(e); process.exit(1); });
