# Editor Collab server

Tiny Node.js server (no dependencies, Node 18+). Sessions live in memory, so
restarting the server ends all sessions.

    node server.js          # listens on :8080  (PORT=3000 node server.js to change)
    node test.js            # self-test

## Where to run it
Your friends' phones must be able to reach it, so `localhost` will not work.
- **Free hosting:** push the `server` folder to Render / Railway / Fly.io as a Node web service
  (start command `node server.js`). Use the https address it gives you.
- **From your PC:** run it, then expose it with a tunnel such as
  `cloudflared tunnel --url http://localhost:8080` and use the https address.

Everyone sets **Server URL** in the mod settings to that address.

## Notes
- Anyone with a session ID can join, so share IDs only with friends.
- The publish block is enforced inside the mod. A determined person with a
  modified client could get around it - it stops accidents and casual re-uploads.
