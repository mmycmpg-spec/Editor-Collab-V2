// Editor Collab v2 - sync server. Zero dependencies, in-memory sessions.
// Run:  node server.js        (PORT env var changes the port, default 8080)
'use strict';
const http = require('http');
const crypto = require('crypto');

const PORT = parseInt(process.env.PORT || '8080', 10);
const MAX_BODY = 25 * 1024 * 1024;          // 25 MB per request
const SESSION_TTL_MS = 6 * 60 * 60 * 1000;  // idle sessions die after 6h
const ACTIVE_MS = 20 * 1000;                // "online" = polled in last 20s
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O/1/I

const sessions = new Map(); // id -> session
const closed = new Map();   // id -> closedAt (so pollers learn it ended)

function newSessionId() {
  for (;;) {
    let id = '';
    const bytes = crypto.randomBytes(6);
    for (const b of bytes) id += ALPHABET[b % ALPHABET.length];
    if (!sessions.has(id)) return id;
  }
}

const str = (v, max = 64) => (typeof v === 'string' ? v.slice(0, max) : '');
const norm = (id) => str(id, 16).trim().toUpperCase();

function touch(s, userId, username) {
  const m = s.members.get(userId) || { name: '' };
  if (username) m.name = username;
  m.lastSeen = Date.now();
  s.members.set(userId, m);
  s.updatedAt = Date.now();
}

function others(s, userId) {
  const now = Date.now();
  const out = [];
  for (const [id, m] of s.members) {
    if (id === userId) continue;
    if (now - m.lastSeen > ACTIVE_MS) continue;
    out.push(m.name || 'Player');
  }
  return out;
}

function getSession(msg) {
  const id = norm(msg.sessionId);
  const s = sessions.get(id);
  if (!s) {
    return { err: closed.has(id) ? { ok: false, closed: true, error: 'Session was closed by the owner.' }
                                 : { ok: false, closed: true, error: 'Session not found.' } };
  }
  return { s };
}

const handlers = {
  CREATE_SESSION(msg) {
    const userId = str(msg.userId), levelData = str(msg.levelData, MAX_BODY);
    if (!userId || !levelData) return { ok: false, error: 'Missing userId or levelData.' };
    const id = newSessionId();
    const s = {
      id, ownerId: userId, ownerName: str(msg.username) || 'Player',
      levelName: str(msg.levelName) || 'Unnamed', levelData, version: 1,
      members: new Map(), createdAt: Date.now(), updatedAt: Date.now(),
    };
    touch(s, userId, s.ownerName);
    sessions.set(id, s);
    return { ok: true, sessionId: id, version: 1 };
  },

  JOIN_SESSION(msg) {
    const { s, err } = getSession(msg); if (err) return err;
    const userId = str(msg.userId); if (!userId) return { ok: false, error: 'Missing userId.' };
    touch(s, userId, str(msg.username) || 'Player');
    return {
      ok: true, sessionId: s.id, levelName: s.levelName, levelData: s.levelData,
      version: s.version, ownerId: s.ownerId, ownerName: s.ownerName,
      isOwner: s.ownerId === userId, collaborators: others(s, userId),
    };
  },

  LEAVE_SESSION(msg) {
    const { s, err } = getSession(msg); if (err) return { ok: true };
    const userId = str(msg.userId);
    if (userId === s.ownerId) { sessions.delete(s.id); closed.set(s.id, Date.now()); }
    else s.members.delete(userId);
    return { ok: true };
  },

  // Cheap poll: version number + who is online. No level data.
  STATUS(msg) {
    const { s, err } = getSession(msg); if (err) return err;
    const userId = str(msg.userId);
    touch(s, userId, str(msg.username));
    return { ok: true, version: s.version, ownerName: s.ownerName, collaborators: others(s, userId) };
  },

  // Download the latest copy if newer than sinceVersion.
  PULL(msg) {
    const { s, err } = getSession(msg); if (err) return err;
    const userId = str(msg.userId);
    touch(s, userId, str(msg.username));
    const since = Number(msg.sinceVersion) || 0;
    const res = { ok: true, version: s.version, collaborators: others(s, userId), changed: s.version > since };
    if (res.changed) res.levelData = s.levelData;
    return res;
  },

  // Upload a new copy. Only accepted if you started from the latest version;
  // otherwise you get the latest back so you can merge and push again.
  PUSH(msg) {
    const { s, err } = getSession(msg); if (err) return err;
    const userId = str(msg.userId);
    const data = str(msg.levelData, MAX_BODY);
    if (!data) return { ok: false, error: 'Empty level data.' };
    touch(s, userId, str(msg.username));
    if ((Number(msg.baseVersion) || 0) !== s.version) {
      return { ok: false, conflict: true, version: s.version, levelData: s.levelData };
    }
    s.levelData = data;
    s.version += 1;
    s.lastAuthor = userId;
    return { ok: true, version: s.version, collaborators: others(s, userId) };
  },
};

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY) { reject(Object.assign(new Error('too large'), { code: 413 })); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function send(res, code, obj) {
  const body = typeof obj === 'string' ? obj : JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': typeof obj === 'string' ? 'text/plain' : 'application/json',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

const server = http.createServer(async (req, res) => {
  try {
    if (req.method === 'GET') return send(res, 200, 'Editor Collab v2 server OK');
    if (req.method === 'POST' && req.url.split('?')[0] === '/message') {
      let msg;
      try { msg = JSON.parse(await readBody(req)); }
      catch (e) { return send(res, e.code === 413 ? 413 : 400, { ok: false, error: 'Bad request.' }); }
      const h = Object.prototype.hasOwnProperty.call(handlers, msg && msg.type) ? handlers[msg.type] : null;
      if (!h) return send(res, 200, { ok: false, error: 'Unknown message type.' });
      return send(res, 200, h(msg));
    }
    send(res, 404, 'Not found');
  } catch (e) {
    console.error(e);
    send(res, 500, { ok: false, error: 'Server error.' });
  }
});

setInterval(() => {
  const now = Date.now();
  for (const [id, s] of sessions) if (now - s.updatedAt > SESSION_TTL_MS) { sessions.delete(id); closed.set(id, now); }
  for (const [id, t] of closed) if (now - t > 10 * 60 * 1000) closed.delete(id);
}, 60 * 1000).unref();

if (require.main === module) {
  server.listen(PORT, '0.0.0.0', () => console.log(`Editor Collab server listening on :${PORT}`));
}
module.exports = server;
