// Editor Collab v2 - relay server
// No dependencies. Run with:  node server.js   (PORT env var is used if set)
//
// How it works
//  - The owner creates a session and gets a 4 digit code.
//  - Friends join with the code and receive the current level.
//  - Everyone sends "diffs" (objects added / removed). The server applies each
//    diff to its own copy of the level and forwards it to everybody else.
//  - Clients receive events by long-polling GET /poll.

const http = require("http");
const crypto = require("crypto");

const PORT = process.env.PORT || 8080;
const POLL_TIMEOUT_MS = 25000;
const SESSION_IDLE_MS = 6 * 60 * 60 * 1000;
const MAX_BODY = 25 * 1024 * 1024; // 25 MB (levels can be big)

const sessions = new Map(); // code -> session

function newCode() {
  for (let i = 0; i < 200; i++) {
    const code = String(1000 + crypto.randomInt(9000));
    if (!sessions.has(code)) return code;
  }
  return null;
}

function newId() {
  return crypto.randomBytes(8).toString("hex");
}

// A level string looks like  "header;obj;obj;obj;"
function parseLevel(levelString) {
  const parts = String(levelString || "").split(";");
  const header = parts.shift() || "";
  const objects = new Map();
  for (const p of parts) {
    if (!p) continue;
    objects.set(p, (objects.get(p) || 0) + 1);
  }
  return { header, objects };
}

function buildLevel(session) {
  let out = session.header + ";";
  for (const [obj, count] of session.objects) {
    for (let i = 0; i < count; i++) out += obj + ";";
  }
  return out;
}

function applyDiff(session, added, removed) {
  for (const obj of removed || []) {
    const n = session.objects.get(obj) || 0;
    if (n <= 1) session.objects.delete(obj);
    else session.objects.set(obj, n - 1);
  }
  for (const obj of added || []) {
    session.objects.set(obj, (session.objects.get(obj) || 0) + 1);
  }
}

function pushEvent(session, event, exceptClientId) {
  for (const [id, client] of session.clients) {
    if (id === exceptClientId) continue;
    client.queue.push(event);
    flush(client);
  }
}

function flush(client) {
  if (client.pending && client.queue.length > 0) {
    const res = client.pending;
    client.pending = null;
    clearTimeout(client.timer);
    const events = client.queue.splice(0, client.queue.length);
    send(res, 200, { events });
  }
}

function send(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Content-Length": Buffer.byteLength(body),
    "Access-Control-Allow-Origin": "*",
  });
  res.end(body);
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on("data", (c) => {
      size += c.length;
      if (size > MAX_BODY) {
        reject(new Error("too big"));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => {
      try {
        const text = Buffer.concat(chunks).toString("utf8");
        resolve(text ? JSON.parse(text) : {});
      } catch (e) {
        reject(e);
      }
    });
    req.on("error", reject);
  });
}

function closeSession(code, reason) {
  const session = sessions.get(code);
  if (!session) return;
  pushEvent(session, { type: "ended", reason });
  sessions.delete(code);
  console.log(`session ${code} closed (${reason})`);
}

function removeClient(session, clientId) {
  const client = session.clients.get(clientId);
  if (!client) return;
  if (client.pending) {
    clearTimeout(client.timer);
    send(client.pending, 200, { events: [] });
    client.pending = null;
  }
  session.clients.delete(clientId);
}

const routes = {
  async "POST /create"(req, res) {
    const b = await readJson(req);
    const code = newCode();
    if (!code) return send(res, 503, { error: "No free session codes" });
    const { header, objects } = parseLevel(b.levelString);
    const clientId = newId();
    const session = {
      code,
      ownerId: clientId,
      ownerName: String(b.name || "Owner").slice(0, 32),
      levelName: String(b.levelName || "Collab level").slice(0, 64),
      header,
      objects,
      clients: new Map(),
      lastActive: Date.now(),
    };
    session.clients.set(clientId, {
      name: session.ownerName,
      queue: [],
      pending: null,
      timer: null,
    });
    sessions.set(code, session);
    console.log(`session ${code} created by ${session.ownerName}`);
    send(res, 200, { code, clientId });
  },

  async "POST /join"(req, res) {
    const b = await readJson(req);
    const session = sessions.get(String(b.code || ""));
    if (!session) return send(res, 404, { error: "Session not found" });
    const clientId = newId();
    const name = String(b.name || "Player").slice(0, 32);
    const users = [...session.clients.values()].map((c) => c.name);
    session.clients.set(clientId, { name, queue: [], pending: null, timer: null });
    session.lastActive = Date.now();
    pushEvent(session, { type: "joined", name }, clientId);
    console.log(`${name} joined ${session.code}`);
    send(res, 200, {
      clientId,
      ownerName: session.ownerName,
      levelName: session.levelName,
      levelString: buildLevel(session),
      users,
    });
  },

  async "POST /diff"(req, res) {
    const b = await readJson(req);
    const session = sessions.get(String(b.code || ""));
    if (!session || !session.clients.has(b.clientId))
      return send(res, 404, { error: "Session not found" });
    const added = Array.isArray(b.added) ? b.added : [];
    const removed = Array.isArray(b.removed) ? b.removed : [];
    applyDiff(session, added, removed);
    session.lastActive = Date.now();
    const from = session.clients.get(b.clientId).name;
    pushEvent(session, { type: "diff", from, added, removed }, b.clientId);
    send(res, 200, { ok: true });
  },

  async "POST /leave"(req, res) {
    const b = await readJson(req);
    const session = sessions.get(String(b.code || ""));
    if (!session) return send(res, 200, { ok: true });
    const client = session.clients.get(b.clientId);
    if (!client) return send(res, 200, { ok: true });
    if (b.clientId === session.ownerId) {
      closeSession(session.code, "The owner closed the session");
    } else {
      const name = client.name;
      removeClient(session, b.clientId);
      pushEvent(session, { type: "left", name });
    }
    send(res, 200, { ok: true });
  },

  async "GET /poll"(req, res, url) {
    const code = url.searchParams.get("code");
    const clientId = url.searchParams.get("clientId");
    const session = sessions.get(String(code || ""));
    const client = session && session.clients.get(clientId);
    if (!client) return send(res, 404, { error: "Session not found" });
    session.lastActive = Date.now();
    // A newer poll replaces an older one
    if (client.pending) {
      clearTimeout(client.timer);
      send(client.pending, 200, { events: [] });
      client.pending = null;
    }
    if (client.queue.length > 0) {
      const events = client.queue.splice(0, client.queue.length);
      return send(res, 200, { events });
    }
    client.pending = res;
    client.timer = setTimeout(() => {
      if (client.pending === res) {
        client.pending = null;
        send(res, 200, { events: [] });
      }
    }, POLL_TIMEOUT_MS);
  },

  async "GET /"(req, res) {
    send(res, 200, { ok: true, name: "Editor Collab v2 server", sessions: sessions.size });
  },
};

const server = http.createServer(async (req, res) => {
  try {
    if (req.method === "OPTIONS") {
      res.writeHead(204, {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
      });
      return res.end();
    }
    const url = new URL(req.url, "http://localhost");
    const handler = routes[`${req.method} ${url.pathname}`];
    if (!handler) return send(res, 404, { error: "Not found" });
    await handler(req, res, url);
  } catch (e) {
    console.error("request error:", e.message);
    if (!res.headersSent) send(res, 400, { error: "Bad request" });
  }
});

// Remove idle sessions
setInterval(() => {
  const now = Date.now();
  for (const [code, s] of sessions) {
    if (now - s.lastActive > SESSION_IDLE_MS) closeSession(code, "Session expired");
  }
}, 10 * 60 * 1000);

server.keepAliveTimeout = 65000;
server.listen(PORT, () => console.log(`Editor Collab server listening on ${PORT}`));
