#include "../src/LevelMerge.hpp"
#include <cassert>
#include <iostream>
using namespace collab;

int main() {
    std::string base   = "H1;a;b;c;";
    // hash ignores order, notices changes
    assert(hashLevel("H;a;b;c;") == hashLevel("H;c;a;b;"));
    assert(hashLevel("H;a;b;") != hashLevel("H;a;b;c;"));
    assert(hashLevel("H;a;b;") != hashLevel("H2;a;b;"));
    assert(hashLevel("H;a;b;") != hashLevel("H;a;x;"));

    // I add d, they add e -> both present
    {
        auto r = splitLevel(mergeLevels(base, "H1;a;b;c;d;", "H1;a;b;c;e;"));
        assert(r.size() == 6 && r[0] == "H1");
        assert(hashLevel(mergeLevels(base, "H1;a;b;c;d;", "H1;a;b;c;e;")) == hashLevel("H1;a;b;c;d;e;"));
    }
    // I delete b, they add e -> b gone, e present
    assert(hashLevel(mergeLevels(base, "H1;a;c;", "H1;a;b;c;e;")) == hashLevel("H1;a;c;e;"));
    // They delete a, I add d -> a gone, d present
    assert(hashLevel(mergeLevels(base, "H1;a;b;c;d;", "H1;b;c;")) == hashLevel("H1;b;c;d;"));
    // Nothing changed locally -> equals theirs
    assert(hashLevel(mergeLevels(base, base, "H1;a;b;c;e;")) == hashLevel("H1;a;b;c;e;"));
    // Both delete same object
    assert(hashLevel(mergeLevels(base, "H1;a;c;", "H1;a;c;")) == hashLevel("H1;a;c;"));
    // Header: mine changed -> mine wins; otherwise theirs
    assert(splitLevel(mergeLevels(base, "H1mine;a;b;c;", "H1theirs;a;b;c;"))[0] == "H1mine");
    assert(splitLevel(mergeLevels(base, base, "H1theirs;a;b;c;"))[0] == "H1theirs");
    // Both edit same object differently -> both versions survive
    assert(hashLevel(mergeLevels(base, "H1;a;b2;c;", "H1;a;b3;c;")) == hashLevel("H1;a;b2;b3;c;"));
    // Empty inputs don't crash
    mergeLevels("", "", ""); mergeLevels("H;", "", "H;x;");
    // Idempotent: merging an already-merged state with itself changes nothing
    std::string m = mergeLevels(base, "H1;a;c;d;", "H1;a;b;c;e;");
    assert(hashLevel(mergeLevels(m, m, m)) == hashLevel(m));
    std::cout << "merge tests passed\n";
}
