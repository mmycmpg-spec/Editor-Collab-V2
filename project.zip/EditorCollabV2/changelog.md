# v1.2.0
- Removed the server completely. Levels are swapped through the clipboard (Send / Receive)
- Changes from both sides are merged at object level
- Received levels are remembered and can never be published

# v1.1.0
- Fixed overlapping buttons in the panel

# v1.0.0
- Initial version
