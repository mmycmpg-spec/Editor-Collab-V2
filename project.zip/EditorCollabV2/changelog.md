# v1.1.0
- Added the sync server (`server/`) and a working client: create, join, Sync Now, auto-sync upload
- Joining imports the level as a new local level
- Changes from both sides are merged at object level
- Received levels are remembered on disk and can never be published
- Fixed overlapping buttons in the collab panel; added Copy ID
- Works over plain HTTP, so it runs on Android

# v1.0.0
- Initial version
