# v1.3.0
- Session buttons back: Create Session, Join Session, Share Level, Sync Now, Leave Session
- Join Session teleports you into the level
- Crash hardening: scene changes happen on the next frame, bad codes are rejected before decoding
- Fixed overlapping buttons

# v1.2.0
- No server; levels travel through the clipboard
