# Editor Collab v2 (Geode mod)

- `src/` - the mod. `src/LevelMerge.hpp` is plain C++ (tested by `tests/test_merge.cpp`).
- `server/` - the sync server. See `server/README.md`.
- `.github/workflows/build.yml` - builds Android + Windows `.geode` files on GitHub.

Build locally: `geode build` (needs the Geode SDK). Easiest on Android: push to GitHub,
open the Actions tab, download "Build Output", install the `.geode` file.
