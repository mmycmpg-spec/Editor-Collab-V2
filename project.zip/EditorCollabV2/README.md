# Editor Collab v2 (Geode mod)

No server. `src/LevelMerge.hpp` is plain C++ tested by `tests/test_merge.cpp`.
`.github/workflows/build.yml` builds Android + Windows `.geode` files on GitHub
(Actions tab -> "Build Output").
