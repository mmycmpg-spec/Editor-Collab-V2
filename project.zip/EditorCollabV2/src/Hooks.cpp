#include <Geode/Geode.hpp>
#include <Geode/modify/LevelInfoLayer.hpp>
#include <Geode/modify/LevelEditorLayer.hpp>
#include <Geode/modify/EditLevelLayer.hpp>
#include <Geode/modify/EditorUI.hpp>
#include "CollabManager.hpp"
#include "CollabUI.hpp"

using namespace geode::prelude;

// ============================================================
// HOOK 1: Warning banner when viewing a shared (non-owned) level
// ============================================================
class $modify(CollabLevelInfoLayer, LevelInfoLayer) {
    bool init(GJGameLevel* level, bool challenge) {
        if (!LevelInfoLayer::init(level, challenge)) return false;

        auto* mgr = CollabManager::get();

        if (mgr->isInSession() && !mgr->canPublishLevel()) {
            auto winSize = CCDirector::sharedDirector()->getWinSize();

            auto* warnBg = CCScale9Sprite::create("GJ_square07.png");
            warnBg->setContentSize({320, 40});
            warnBg->setPosition({winSize.width / 2, 35});
            warnBg->setColor({180, 30, 30});
            warnBg->setOpacity(200);
            this->addChild(warnBg, 50);

            auto* warnLabel = CCLabelBMFont::create(
                "Shared level - Publishing blocked",
                "chatFont.fnt");
            warnLabel->setScale(0.5f);
            warnLabel->setColor({255, 255, 255});
            warnLabel->setPosition({winSize.width / 2, 35});
            this->addChild(warnLabel, 51);
        }

        return true;
    }
};

// ============================================================
// HOOK 2: Block the publish/share button for shared levels
// ============================================================
class $modify(CollabEditLevelLayer, EditLevelLayer) {
    void onShare(CCObject* sender) {
        auto* mgr = CollabManager::get();

        if (!mgr->canPublishLevel()) {
            FLAlertLayer::create(
                "Cannot Publish",
                mgr->getPublishBlockReason(),
                "OK"
            )->show();
            return; // Block the upload
        }

        EditLevelLayer::onShare(sender);
    }
};

// ============================================================
// HOOK 3: Add collab button to the editor + auto sync
// ============================================================
class $modify(CollabEditorUI, EditorUI) {
    bool init(LevelEditorLayer* lel) {
        if (!EditorUI::init(lel)) return false;

        auto* collabBtn = CollabButton::create();

        auto winSize = CCDirector::sharedDirector()->getWinSize();
        collabBtn->setPosition({winSize.width - 40, winSize.height - 40});
        collabBtn->setScale(0.9f);
        this->addChild(collabBtn, 100);

        if (Mod::get()->getSettingValue<bool>("auto-sync")) {
            this->schedule(schedule_selector(CollabEditorUI::autoSyncTick), 5.0f);
        }

        return true;
    }

    void autoSyncTick(float dt) {
        auto* mgr = CollabManager::get();
        if (!mgr->isInSession() || !mgr->isOwner()) return;

        auto* lel = LevelEditorLayer::get();
        if (!lel) return;

        std::string levelString = lel->m_level->m_levelString;
        mgr->syncLevelData(levelString);
    }
};

// ============================================================
// HOOK 4: Editor object tracking - send edits to collaborators
// ============================================================
class $modify(CollabEditorLayer, LevelEditorLayer) {
    GameObject* createObject(int key, CCPoint position, bool noUndo) {
        auto* obj = LevelEditorLayer::createObject(key, position, noUndo);

        auto* mgr = CollabManager::get();
        if (obj && mgr->isInSession()) {
            mgr->sendObjectAdd(std::to_string(key));
        }
        return obj;
    }

    void removeObject(GameObject* obj, bool noUndo) {
        auto* mgr = CollabManager::get();
        if (obj && mgr->isInSession()) {
            mgr->sendObjectDelete(obj->m_uniqueID);
        }
        LevelEditorLayer::removeObject(obj, noUndo);
    }
};
