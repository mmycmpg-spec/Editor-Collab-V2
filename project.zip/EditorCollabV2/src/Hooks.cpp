#include <Geode/Geode.hpp>
#include <Geode/modify/EditLevelLayer.hpp>
#include <Geode/modify/EditorUI.hpp>
#include "CollabManager.hpp"
#include "CollabUI.hpp"

using namespace geode::prelude;

// ============================================================
// HOOK 1: Block uploading a received level + show a banner
// ============================================================
class $modify(CollabEditLevelLayer, EditLevelLayer) {
    bool init(GJGameLevel* level) {
        if (!EditLevelLayer::init(level)) return false;

        if (!CollabManager::get()->canPublishLevel(level->m_levelName)) {
            auto winSize = CCDirector::sharedDirector()->getWinSize();
            auto* warn = CCLabelBMFont::create("Shared level - publishing blocked", "bigFont.fnt");
            warn->setScale(0.35f);
            warn->setColor({255, 90, 90});
            warn->setPosition({winSize.width / 2, 12});
            this->addChild(warn, 50);
        }
        return true;
    }

    void onShare(CCObject* sender) {
        auto* mgr = CollabManager::get();
        std::string name = m_level->m_levelName;

        if (!mgr->canPublishLevel(name)) {
            FLAlertLayer::create("Cannot Publish", mgr->getPublishBlockReason(name), "OK")->show();
            return;
        }
        EditLevelLayer::onShare(sender);
    }
};

// ============================================================
// HOOK 2: Collab button in the editor
// ============================================================
class $modify(CollabEditorUI, EditorUI) {
    bool init(LevelEditorLayer* lel) {
        if (!EditorUI::init(lel)) return false;

        auto* collabBtn = CollabButton::create();
        auto winSize = CCDirector::sharedDirector()->getWinSize();
        collabBtn->setPosition({winSize.width - 24, winSize.height - 118});
        this->addChild(collabBtn, 100);

        return true;
    }
};
