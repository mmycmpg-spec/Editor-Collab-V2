#include <Geode/Geode.hpp>
#include <Geode/modify/EditLevelLayer.hpp>
#include <Geode/modify/EditorUI.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include "CollabManager.hpp"
#include "CollabUI.hpp"
#include <algorithm>

using namespace geode::prelude;

// ============================================================
// Block the publish button for levels received in a session
// ============================================================
class $modify(CollabEditLevelLayer, EditLevelLayer) {
    bool init(GJGameLevel* level) {
        if (!EditLevelLayer::init(level)) return false;

        std::string name = level->m_levelName;
        if (!CollabManager::get()->canPublishLevel(name)) {
            auto winSize = CCDirector::sharedDirector()->getWinSize();
            auto* label = CCLabelBMFont::create(
                "Shared level - publishing is blocked", "chatFont.fnt");
            label->setScale(0.55f);
            label->setColor({255, 90, 90});
            label->setPosition({winSize.width / 2, 20});
            this->addChild(label, 50);
        }
        return true;
    }

    void onShare(CCObject* sender) {
        std::string name = m_level->m_levelName;
        auto* mgr = CollabManager::get();

        if (!mgr->canPublishLevel(name)) {
            FLAlertLayer::create(
                "Cannot Publish",
                mgr->getPublishBlockReason(name),
                "OK"
            )->show();
            return;
        }

        EditLevelLayer::onShare(sender);
    }
};

// ============================================================
// Editor: collab button + live sync tick
// ============================================================
class $modify(CollabEditorUI, EditorUI) {
    bool init(LevelEditorLayer* lel) {
        if (!EditorUI::init(lel)) return false;

        auto* collabBtn = CollabButton::create();
        auto winSize = CCDirector::sharedDirector()->getWinSize();
        collabBtn->setPosition({winSize.width - 24, winSize.height - 118});
        this->addChild(collabBtn, 100);

        float interval = static_cast<float>(
            Mod::get()->getSettingValue<double>("sync-interval"));
        interval = std::clamp(interval, 0.3f, 5.f);
        this->schedule(schedule_selector(CollabEditorUI::collabTick), interval);

        return true;
    }

    void collabTick(float) {
        CollabManager::get()->editorTick(m_editorLayer);
    }
};

// ============================================================
// Main menu: collab button, so you can Join without opening the editor
// ============================================================
class $modify(CollabMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;

        auto* collabBtn = CollabButton::create();
        auto winSize = CCDirector::sharedDirector()->getWinSize();
        collabBtn->setPosition({24, winSize.height - 24});
        this->addChild(collabBtn, 100);
        return true;
    }
};
