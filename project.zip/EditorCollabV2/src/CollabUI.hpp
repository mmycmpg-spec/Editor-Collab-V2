#pragma once
#include <Geode/Geode.hpp>
#include <Geode/ui/Popup.hpp>
#include <Geode/ui/TextInput.hpp>
#include "CollabManager.hpp"

using namespace geode::prelude;

// Main collab panel shown in the editor
class CollabPanel : public CCLayer {
public:
    static CollabPanel* create();
    bool init();
    void update(float dt) override;

private:
    // UI elements
    CCLabelBMFont* m_statusLabel = nullptr;
    CCLabelBMFont* m_sessionIdLabel = nullptr;
    CCLabelBMFont* m_ownerLabel = nullptr;
    CCNode* m_collaboratorList = nullptr;
    CCLabelBMFont* m_publishStatusLabel = nullptr;

    // Buttons
    CCMenuItemSpriteExtra* m_createBtn = nullptr;
    CCMenuItemSpriteExtra* m_joinBtn = nullptr;
    CCMenuItemSpriteExtra* m_shareBtn = nullptr;
    CCMenuItemSpriteExtra* m_leaveBtn = nullptr;
    CCMenuItemSpriteExtra* m_syncBtn = nullptr;

    // Callbacks
    void onCreateSession(CCObject*);
    void onJoinSession(CCObject*);
    void onShareLevel(CCObject*);
    void onLeaveSession(CCObject*);
    void onManualSync(CCObject*);

    void refreshUI();
    void updateCollaboratorList();
    void updatePublishStatus();

    float m_autoSyncTimer = 0.f;
    float m_autoSyncInterval = 5.f;
};

// Floating collab button shown in editor toolbar
class CollabButton : public CCNode {
public:
    static CollabButton* create();
    bool init();

private:
    CCMenuItemSpriteExtra* m_btn = nullptr;
    void onTogglePanel(CCObject*);
    CollabPanel* m_panel = nullptr;
    bool m_panelOpen = false;
};

// Share level popup
class ShareLevelPopup : public geode::Popup {
protected:
    bool init();
    void onShareToFriend(CCObject* sender);
    void buildFriendsList();

public:
    static ShareLevelPopup* create();
};

// Join session popup
class JoinSessionPopup : public geode::Popup {
protected:
    geode::TextInput* m_sessionInput = nullptr;
    bool init();
    void onJoin(CCObject*);

public:
    static JoinSessionPopup* create();
};
