#pragma once
#include <Geode/Geode.hpp>
#include <Geode/ui/Popup.hpp>
#include <Geode/ui/TextInput.hpp>
#include "CollabManager.hpp"

using namespace geode::prelude;

// Main collab panel shown in the editor (drag to move, +/- to resize)
class CollabPanel : public CCLayer {
public:
    static CollabPanel* create();
    bool init();
    ~CollabPanel() override;
    void update(float dt) override;

    bool ccTouchBegan(CCTouch* touch, CCEvent* event) override;
    void ccTouchMoved(CCTouch* touch, CCEvent* event) override;
    void ccTouchEnded(CCTouch* touch, CCEvent* event) override;
    void ccTouchCancelled(CCTouch* touch, CCEvent* event) override;

    static constexpr float kWidth = 250.f;
    static constexpr float kHeight = 210.f;

private:
    // UI elements
    CCLabelBMFont* m_statusLabel = nullptr;
    CCLabelBMFont* m_sessionIdLabel = nullptr;
    CCLabelBMFont* m_ownerLabel = nullptr;
    CCNode* m_collaboratorList = nullptr;
    CCLabelBMFont* m_publishStatusLabel = nullptr;

    // Buttons
    CCMenuItemSpriteExtra* m_createBtn = nullptr;
    CCMenuItemSpriteExtra* m_joinBtn = nullptr;
    CCMenuItemSpriteExtra* m_shareBtn = nullptr;
    CCMenuItemSpriteExtra* m_leaveBtn = nullptr;
    CCMenuItemSpriteExtra* m_syncBtn = nullptr;

    // Callbacks
    void onCreateSession(CCObject*);
    void onJoinSession(CCObject*);
    void onShareLevel(CCObject*);
    void onLeaveSession(CCObject*);
    void onManualSync(CCObject*);
    void onBigger(CCObject*);
    void onSmaller(CCObject*);

    void applyScale(float scale);
    void refreshUI();
    void updateCollaboratorList();
    void updatePublishStatus();

    bool m_dragging = false;
    float m_autoSyncTimer = 0.f;
    float m_autoSyncInterval = 5.f;
};

// Small button shown in the editor that opens/closes the panel
class CollabButton : public CCNode {
public:
    static CollabButton* create();
    bool init();

private:
    CCMenuItemSpriteExtra* m_btn = nullptr;
    void onTogglePanel(CCObject*);
    CollabPanel* m_panel = nullptr;
    bool m_panelOpen = false;
};

// Share level popup
class ShareLevelPopup : public geode::Popup {
protected:
    bool init();
    void onShareToFriend(CCObject* sender);
    void buildFriendsList();

public:
    static ShareLevelPopup* create();
};

// Join session popup
class JoinSessionPopup : public geode::Popup {
protected:
    geode::TextInput* m_sessionInput = nullptr;
    bool init();
    void onJoin(CCObject*);

public:
    static JoinSessionPopup* create();
};
