#pragma once
#include <Geode/Geode.hpp>
#include <Geode/ui/Popup.hpp>
#include <Geode/ui/TextInput.hpp>
#include "CollabManager.hpp"

using namespace geode::prelude;

// Main collab panel shown in the editor (drag to move, +/- to resize)
class CollabPanel : public CCLayer {
public:
    static CollabPanel* create();
    bool init();
    void update(float dt) override;

    bool ccTouchBegan(CCTouch* touch, CCEvent* event) override;
    void ccTouchMoved(CCTouch* touch, CCEvent* event) override;
    void ccTouchEnded(CCTouch* touch, CCEvent* event) override;
    void ccTouchCancelled(CCTouch* touch, CCEvent* event) override;

    static constexpr float kWidth = 260.f;
    static constexpr float kHeight = 240.f;

private:
    CCLabelBMFont* m_statusLabel = nullptr;
    CCLabelBMFont* m_sessionIdLabel = nullptr;
    CCLabelBMFont* m_ownerLabel = nullptr;
    CCNode* m_collaboratorList = nullptr;
    CCLabelBMFont* m_publishStatusLabel = nullptr;
    CCLabelBMFont* m_updateLabel = nullptr;

    void onCreateSession(CCObject*);
    void onJoinSession(CCObject*);
    void onCopyId(CCObject*);
    void onLeaveSession(CCObject*);
    void onSyncNow(CCObject*);
    void onBigger(CCObject*);
    void onSmaller(CCObject*);

    void applyScale(float scale);
    void refreshUI();
    void updateCollaboratorList();

    bool m_dragging = false;
    float m_refreshTimer = 0.f;
};

// Small button shown in the editor that opens/closes the panel
class CollabButton : public CCNode {
public:
    static CollabButton* create();
    bool init();

private:
    void onTogglePanel(CCObject*);
    CollabPanel* m_panel = nullptr;
    bool m_panelOpen = false;
};

// Join session popup
class JoinSessionPopup : public geode::Popup {
protected:
    geode::TextInput* m_sessionInput = nullptr;
    bool init();
    void onJoin(CCObject*);

public:
    static JoinSessionPopup* create();
};
