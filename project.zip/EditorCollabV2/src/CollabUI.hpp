#pragma once
#include <Geode/Geode.hpp>
#include <Geode/ui/Popup.hpp>
#include <Geode/ui/TextInput.hpp>
#include "CollabManager.hpp"

using namespace geode::prelude;

// Main collab panel (drag to move, +/- to resize)
class CollabPanel : public CCLayer {
public:
    static CollabPanel* create();
    bool init();
    ~CollabPanel() override;

    bool ccTouchBegan(CCTouch* touch, CCEvent* event) override;
    void ccTouchMoved(CCTouch* touch, CCEvent* event) override;
    void ccTouchEnded(CCTouch* touch, CCEvent* event) override;
    void ccTouchCancelled(CCTouch* touch, CCEvent* event) override;

    static constexpr float kWidth = 250.f;
    static constexpr float kHeight = 210.f;

private:
    CCLabelBMFont* m_statusLabel = nullptr;
    CCLabelBMFont* m_codeLabel = nullptr;
    CCLabelBMFont* m_ownerLabel = nullptr;
    CCNode* m_collaboratorList = nullptr;
    CCLabelBMFont* m_publishStatusLabel = nullptr;

    void onCreateSession(CCObject*);
    void onJoinSession(CCObject*);
    void onCopyCode(CCObject*);
    void onLeaveSession(CCObject*);
    void onBigger(CCObject*);
    void onSmaller(CCObject*);

    void applyScale(float scale);
    void refreshUI();
    void updateCollaboratorList();

    bool m_dragging = false;
};

// Small button that opens/closes the panel
class CollabButton : public CCNode {
public:
    static CollabButton* create();
    bool init();

private:
    CCMenuItemSpriteExtra* m_btn = nullptr;
    void onTogglePanel(CCObject*);
    CollabPanel* m_panel = nullptr;
    bool m_panelOpen = false;
};

// Join session popup: type the 4 digit code
class JoinSessionPopup : public geode::Popup {
protected:
    geode::TextInput* m_codeInput = nullptr;
    bool init();
    void onJoin(CCObject*);
    void doJoin(std::string const& code);

public:
    static JoinSessionPopup* create();
};
