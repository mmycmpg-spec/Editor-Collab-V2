#pragma once
#include <Geode/Geode.hpp>
#include "CollabManager.hpp"

using namespace geode::prelude;

// Collab panel shown in the editor (drag to move, +/- to resize)
class CollabPanel : public CCLayer {
public:
    static CollabPanel* create();
    bool init();
    void update(float dt) override;

    bool ccTouchBegan(CCTouch* touch, CCEvent* event) override;
    void ccTouchMoved(CCTouch* touch, CCEvent* event) override;
    void ccTouchEnded(CCTouch* touch, CCEvent* event) override;
    void ccTouchCancelled(CCTouch* touch, CCEvent* event) override;

    static constexpr float kWidth = 260.f;
    static constexpr float kHeight = 170.f;

private:
    CCLabelBMFont* m_levelLabel = nullptr;
    CCLabelBMFont* m_publishLabel = nullptr;
    CCLabelBMFont* m_infoLabel = nullptr;

    void onSend(CCObject*);
    void onReceive(CCObject*);
    void onBigger(CCObject*);
    void onSmaller(CCObject*);

    void applyScale(float scale);
    void refreshUI();

    bool m_dragging = false;
    float m_refreshTimer = 0.f;
};

// Small button shown in the editor that opens/closes the panel
class CollabButton : public CCNode {
public:
    static CollabButton* create();
    bool init();

private:
    void onTogglePanel(CCObject*);
    CollabPanel* m_panel = nullptr;
    bool m_panelOpen = false;
};
