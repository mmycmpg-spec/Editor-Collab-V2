#pragma once
// Pure C++ helpers (no Geode/GD includes) so they can be unit tested anywhere.
// A GD level string is:  header;object;object;...;
#include <string>
#include <string_view>
#include <vector>
#include <unordered_set>
#include <functional>

namespace collab {

// Splits on ';' and drops empty segments. Element 0 is the header.
inline std::vector<std::string> splitLevel(std::string const& raw) {
    std::vector<std::string> out;
    size_t start = 0;
    while (start <= raw.size()) {
        size_t end = raw.find(';', start);
        if (end == std::string::npos) end = raw.size();
        if (end > start) out.emplace_back(raw, start, end - start);
        start = end + 1;
    }
    return out;
}

// Order-independent fingerprint: same header + same set of objects => equal.
struct ContentHash {
    size_t header = 0;
    size_t count = 0;
    size_t sum = 0;
    size_t xr = 0;
    bool operator==(ContentHash const& o) const {
        return header == o.header && count == o.count && sum == o.sum && xr == o.xr;
    }
    bool operator!=(ContentHash const& o) const { return !(*this == o); }
};

inline ContentHash hashLevel(std::string const& raw) {
    ContentHash h;
    std::hash<std::string_view> hasher;
    size_t start = 0;
    bool first = true;
    while (start <= raw.size()) {
        size_t end = raw.find(';', start);
        if (end == std::string::npos) end = raw.size();
        if (end > start) {
            size_t v = hasher(std::string_view(raw).substr(start, end - start));
            if (first) { h.header = v; first = false; }
            else { h.count++; h.sum += v; h.xr ^= (v * 0x9E3779B97F4A7C15ull); }
        }
        start = end + 1;
    }
    return h;
}

// 3-way merge at object level.
//   base   = last copy both sides agreed on
//   mine   = what is in my editor now
//   theirs = latest copy on the server
// Objects I deleted stay deleted, objects I added are kept, everything else
// follows `theirs`. A header (colors, settings) I changed wins over theirs.
// An object edited on both sides ends up present twice (once per edit) -
// that is the price of not tracking object identity.
inline std::string mergeLevels(std::string const& base, std::string const& mine,
                               std::string const& theirs) {
    auto b = splitLevel(base), m = splitLevel(mine), t = splitLevel(theirs);
    auto objects = [](std::vector<std::string> const& v) {
        return std::unordered_set<std::string>(v.empty() ? v.end() : v.begin() + 1, v.end());
    };
    auto bs = objects(b), ms = objects(m), ts = objects(t);

    std::string header;
    if (!m.empty() && (b.empty() || m[0] != b[0])) header = m[0];
    else if (!t.empty()) header = t[0];
    else if (!m.empty()) header = m[0];

    std::string out = header + ";";
    for (size_t i = 1; i < t.size(); i++) {
        if (bs.count(t[i]) && !ms.count(t[i])) continue; // I deleted it
        out += t[i]; out += ';';
    }
    for (size_t i = 1; i < m.size(); i++) {
        if (!bs.count(m[i]) && !ts.count(m[i])) { out += m[i]; out += ';'; } // I added it
    }
    return out;
}

} // namespace collab
