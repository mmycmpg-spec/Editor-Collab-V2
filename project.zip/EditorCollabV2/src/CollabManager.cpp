#include "CollabManager.hpp"
#include "LocalServer.hpp"
#include <Geode/utils/web.hpp>
#include <Geode/ui/Notification.hpp>
#include <algorithm>
#include <thread>

namespace {
    // ---- tiny JSON writer (we only ever send simple objects) ----
    std::string jsonString(std::string const& s) {
        std::string out = "\"";
        for (unsigned char c : s) {
            switch (c) {
                case '"': out += "\\\""; break;
                case '\\': out += "\\\\"; break;
                case '\n': out += "\\n"; break;
                case '\r': out += "\\r"; break;
                case '\t': out += "\\t"; break;
                default:
                    if (c < 0x20) {
                        char buf[8];
                        snprintf(buf, sizeof(buf), "\\u%04x", c);
                        out += buf;
                    } else {
                        out += static_cast<char>(c);
                    }
            }
        }
        out += "\"";
        return out;
    }

    std::string jsonArray(std::vector<std::string> const& items) {
        std::string out = "[";
        for (size_t i = 0; i < items.size(); i++) {
            if (i) out += ",";
            out += jsonString(items[i]);
        }
        out += "]";
        return out;
    }

    web::WebResponse postJson(std::string const& url, std::string const& body) {
        return web::WebRequest()
            .header("Content-Type", "application/json")
            .timeout(std::chrono::seconds(60))
            .bodyString(body)
            .postSync(url);
    }

    // Reads the JSON body of a response (even for error status codes)
    std::optional<matjson::Value> parseBody(web::WebResponse const& res) {
        auto text = res.string();
        if (!text) return std::nullopt;
        auto json = matjson::parse(text.unwrap());
        if (!json) return std::nullopt;
        return json.unwrap();
    }

    std::string errorFrom(web::WebResponse const& res) {
        auto body = parseBody(res);
        if (body) {
            auto err = (*body)["error"].asString().unwrapOr("");
            if (!err.empty()) return err;
        }
        if (res.code() <= 0) {
            return "Could not reach the server.\nCheck the Server URL in the mod settings.";
        }
        return "The server returned an error (" + std::to_string(res.code()) + ").";
    }

    std::vector<std::string> stringList(matjson::Value const& value) {
        std::vector<std::string> out;
        auto arr = value.asArray().unwrapOr(std::vector<matjson::Value>{});
        for (auto& v : arr) {
            auto s = v.asString();
            if (s) out.push_back(s.unwrap());
        }
        return out;
    }
}

CollabManager* CollabManager::get() {
    static auto* instance = new CollabManager();
    return instance;
}

std::string CollabManager::onlineUrl() {
    std::string url = Mod::get()->getSettingValue<std::string>("server-url");
    // trim spaces
    while (!url.empty() && url.back() == ' ') url.pop_back();
    while (!url.empty() && url.front() == ' ') url.erase(url.begin());
    // ws:// -> http://, wss:// -> https://
    if (url.rfind("wss://", 0) == 0) url = "https://" + url.substr(6);
    else if (url.rfind("ws://", 0) == 0) url = "http://" + url.substr(5);
    else if (!url.empty() && url.rfind("http", 0) != 0) url = "https://" + url;
    while (!url.empty() && url.back() == '/') url.pop_back();
    return url;
}

void CollabManager::changed() {
    if (onStateChanged) onStateChanged();
}

// ------------------------------------------------------------------
// Object scanning
// ------------------------------------------------------------------

std::string CollabManager::saveString(GameObject* obj, LevelEditorLayer* editor) {
    std::string s = obj->getSaveString(editor);
    while (!s.empty() && s.back() == ';') s.pop_back();
    return s;
}

CollabManager::ObjectCounts CollabManager::scanObjects(LevelEditorLayer* editor) {
    ObjectCounts out;
    if (!editor || !editor->m_objects) return out;
    for (auto* obj : CCArrayExt<GameObject*>(editor->m_objects)) {
        if (!obj) continue;
        auto s = saveString(obj, editor);
        if (!s.empty()) out[s]++;
    }
    return out;
}

// ------------------------------------------------------------------
// Sessions
// ------------------------------------------------------------------

void CollabManager::createSession(LevelEditorLayer* editor, DoneCallback cb) {
    if (m_inSession) {
        cb(false, "You are already in a session.\nLeave it first.");
        return;
    }
    if (!editor) {
        cb(false, "Open a level in the editor first.");
        return;
    }

    // No online server set -> host the session on this phone (Wi-Fi / hotspot mode)
    std::string base = onlineUrl();
    if (base.empty()) {
        int port = collab::startLocalServer();
        if (port == 0) {
            cb(false, "Could not start hosting on this device.");
            return;
        }
        base = "http://127.0.0.1:" + std::to_string(port);
    }

    // Take everything we need from the editor now (on the main thread)
    std::string levelName = editor->m_level->m_levelName;
    std::string levelString = editor->getLevelString();
    auto snapshot = scanObjects(editor);
    auto* levelPtr = editor->m_level;
    std::string name = Mod::get()->getSettingValue<std::string>("username");

    std::thread([=, this] {
        std::string body = "{\"name\":" + jsonString(name) +
                           ",\"levelName\":" + jsonString(levelName) +
                           ",\"levelString\":" + jsonString(levelString) + "}";
        auto res = postJson(base + "/create", body);
        bool ok = res.code() == 200;
        auto json = parseBody(res);
        std::string error = ok ? "" : errorFrom(res);

        queueInMainThread([=, this] {
            if (!ok || !json) {
                cb(false, error.empty() ? "Bad answer from the server." : error);
                return;
            }
            m_session = CollabSession{};
            m_base = base;
            m_session.code = (*json)["code"].asString().unwrapOr("");
            m_session.clientId = (*json)["clientId"].asString().unwrapOr("");
            m_session.ownerName = name;
            m_session.levelName = levelName;
            m_session.isOwner = true;
            m_inSession = true;
            m_levelPtr = levelPtr;
            m_snapshot = snapshot;
            m_snapshotReady = true;
            m_pendingRemote.clear();
            startPolling();
            log::info("[CollabV2] Session {} created", m_session.code);
            changed();
            cb(true, m_session.code);
        });
    }).detach();
}

void CollabManager::joinSession(std::string const& code, DoneCallback cb) {
    if (m_inSession) {
        cb(false, "You are already in a session.\nLeave it first.");
        return;
    }
    std::string online = onlineUrl();
    std::string name = Mod::get()->getSettingValue<std::string>("username");

    std::thread([=, this] {
        // 1) look for a host on the same Wi-Fi / hotspot
        std::string base = collab::discoverHost(code);
        // 2) otherwise try the online server, if one is set
        if (base.empty()) base = online;

        if (base.empty()) {
            queueInMainThread([=] {
                cb(false,
                   "Could not find that session.\n"
                   "Make sure you are on the same Wi-Fi or connected to the host's hotspot, "
                   "and that the code is right.");
            });
            return;
        }

        std::string body = "{\"code\":" + jsonString(code) + ",\"name\":" + jsonString(name) + "}";
        auto res = postJson(base + "/join", body);
        bool ok = res.code() == 200;
        auto json = parseBody(res);
        std::string error = ok ? "" : errorFrom(res);

        queueInMainThread([=, this] {
            if (!ok || !json) {
                cb(false, error.empty() ? "Bad answer from the host." : error);
                return;
            }

            std::string ownerName = (*json)["ownerName"].asString().unwrapOr("Owner");
            std::string levelName = (*json)["levelName"].asString().unwrapOr("Collab level");
            std::string levelString = (*json)["levelString"].asString().unwrapOr("");
            auto users = stringList((*json)["users"]);

            // Make a local copy of the owner's level in My Levels
            auto* level = GameLevelManager::sharedState()->createNewLevel();
            if (!level) {
                cb(false, "Could not create the level on this device.");
                return;
            }
            std::string localName = levelName + " (collab)";
            level->m_levelName = localName;
            level->m_levelString = ZipUtils::compressString(levelString, false, 0);

            m_session = CollabSession{};
            m_base = base;
            m_session.code = code;
            m_session.clientId = (*json)["clientId"].asString().unwrapOr("");
            m_session.ownerName = ownerName;
            m_session.levelName = localName;
            m_session.isOwner = false;
            for (auto& u : users) {
                if (u != name) m_session.collaborators.push_back(u);
            }
            m_inSession = true;
            m_levelPtr = level;
            m_snapshot.clear();
            m_snapshotReady = false; // taken when the editor opens
            m_pendingRemote.clear();
            markReceived(localName);
            startPolling();
            log::info("[CollabV2] Joined session {}", code);
            changed();
            cb(true, ownerName);

            // "Teleport" to the owner's level
            auto* scene = LevelEditorLayer::scene(level, false);
            CCDirector::sharedDirector()->replaceScene(CCTransitionFade::create(0.5f, scene));
        });
    }).detach();
}

void CollabManager::leaveSession() {
    if (!m_inSession) return;

    auto base = m_base;
    std::string body = "{\"code\":" + jsonString(m_session.code) +
                       ",\"clientId\":" + jsonString(m_session.clientId) + "}";

    m_generation++;
    m_inSession = false;
    m_session = CollabSession{};
    m_pendingRemote.clear();
    m_snapshot.clear();
    m_snapshotReady = false;
    m_levelPtr = nullptr;
    changed();

    std::thread([base, body] {
        postJson(base + "/leave", body);
    }).detach();
    log::info("[CollabV2] Left session");
}

void CollabManager::endSession(std::string const& reason) {
    if (!m_inSession) return;
    m_generation++;
    m_inSession = false;
    m_session = CollabSession{};
    m_pendingRemote.clear();
    m_snapshot.clear();
    m_snapshotReady = false;
    m_levelPtr = nullptr;
    changed();
    FLAlertLayer::create("Session ended", reason, "OK")->show();
}

// ------------------------------------------------------------------
// Receiving events (long polling)
// ------------------------------------------------------------------

void CollabManager::startPolling() {
    int gen = ++m_generation;
    std::string base = m_base;
    std::string code = m_session.code;
    std::string clientId = m_session.clientId;

    std::thread([=, this] {
        int failures = 0;
        while (m_generation.load() == gen) {
            auto res = web::WebRequest()
                .timeout(std::chrono::seconds(45))
                .getSync(base + "/poll?code=" + code + "&clientId=" + clientId);
            if (m_generation.load() != gen) break;

            if (res.code() == 200) {
                failures = 0;
                auto text = res.string();
                if (text) {
                    std::string body = text.unwrap();
                    queueInMainThread([=, this] {
                        if (m_generation.load() == gen) handleEvents(body);
                    });
                }
            } else if (res.code() == 404) {
                queueInMainThread([=, this] {
                    if (m_generation.load() == gen) endSession("The session no longer exists.");
                });
                break;
            } else {
                if (++failures >= 8) {
                    queueInMainThread([=, this] {
                        if (m_generation.load() == gen) endSession("Lost the connection to the server.");
                    });
                    break;
                }
                std::this_thread::sleep_for(std::chrono::seconds(2));
            }
        }
    }).detach();
}

void CollabManager::handleEvents(std::string const& text) {
    auto parsed = matjson::parse(text);
    if (!parsed) return;
    auto root = parsed.unwrap();
    auto events = root["events"].asArray().unwrapOr(std::vector<matjson::Value>{});

    for (auto& ev : events) {
        std::string type = ev["type"].asString().unwrapOr("");

        if (type == "diff") {
            RemoteDiff diff;
            diff.from = ev["from"].asString().unwrapOr("Someone");
            diff.added = stringList(ev["added"]);
            diff.removed = stringList(ev["removed"]);
            m_pendingRemote.push_back(std::move(diff));

            if (Mod::get()->getSettingValue<bool>("notify-on-edit")) {
                auto now = std::chrono::steady_clock::now();
                if (now - m_lastEditNotice > std::chrono::seconds(6)) {
                    m_lastEditNotice = now;
                    Notification::create(
                        ev["from"].asString().unwrapOr("Someone") + " edited the level",
                        NotificationIcon::Info)->show();
                }
            }
        } else if (type == "joined") {
            std::string name = ev["name"].asString().unwrapOr("Someone");
            m_session.collaborators.push_back(name);
            Notification::create(name + " joined the session", NotificationIcon::Success)->show();
            changed();
        } else if (type == "left") {
            std::string name = ev["name"].asString().unwrapOr("Someone");
            auto it = std::find(m_session.collaborators.begin(), m_session.collaborators.end(), name);
            if (it != m_session.collaborators.end()) m_session.collaborators.erase(it);
            Notification::create(name + " left the session", NotificationIcon::Warning)->show();
            changed();
        } else if (type == "ended") {
            endSession(ev["reason"].asString().unwrapOr("The session was closed."));
            return;
        }
    }
}

// ------------------------------------------------------------------
// Editor sync
// ------------------------------------------------------------------

void CollabManager::editorTick(LevelEditorLayer* editor) {
    if (!m_inSession || !editor) return;
    if (editor->m_level != m_levelPtr) return; // a different level is open

    // First time in this editor: remember what the level looks like now
    if (!m_snapshotReady) {
        m_snapshot = scanObjects(editor);
        m_snapshotReady = true;
    }

    // 1) Send what we changed since last time
    auto current = scanObjects(editor);
    std::vector<std::string> added, removed;
    for (auto& [s, count] : current) {
        auto it = m_snapshot.find(s);
        int before = it == m_snapshot.end() ? 0 : it->second;
        for (int i = before; i < count; i++) added.push_back(s);
    }
    for (auto& [s, count] : m_snapshot) {
        auto it = current.find(s);
        int now = it == current.end() ? 0 : it->second;
        for (int i = now; i < count; i++) removed.push_back(s);
    }
    if (!added.empty() || !removed.empty()) {
        m_snapshot = std::move(current);
        sendDiff(std::move(added), std::move(removed));
    }

    // 2) Apply what the others changed
    if (!m_pendingRemote.empty()) {
        auto pending = std::move(m_pendingRemote);
        m_pendingRemote.clear();
        for (auto& diff : pending) applyRemote(editor, diff);
        m_snapshot = scanObjects(editor); // so we don't send their edits back
    }
}

void CollabManager::sendDiff(std::vector<std::string> added, std::vector<std::string> removed) {
    auto base = m_base;
    std::string body = "{\"code\":" + jsonString(m_session.code) +
                       ",\"clientId\":" + jsonString(m_session.clientId) +
                       ",\"added\":" + jsonArray(added) +
                       ",\"removed\":" + jsonArray(removed) + "}";
    std::thread([base, body] {
        auto res = postJson(base + "/diff", body);
        if (res.code() != 200) {
            queueInMainThread([] {
                log::warn("[CollabV2] Could not send edits to the server");
            });
        }
    }).detach();
}

void CollabManager::applyRemote(LevelEditorLayer* editor, RemoteDiff const& diff) {
    // Removals: find a local object with the same save string
    if (!diff.removed.empty()) {
        std::unordered_map<std::string, std::vector<GameObject*>> byString;
        if (editor->m_objects) {
            for (auto* obj : CCArrayExt<GameObject*>(editor->m_objects)) {
                if (obj) byString[saveString(obj, editor)].push_back(obj);
            }
        }
        std::vector<GameObject*> toRemove;
        for (auto& s : diff.removed) {
            auto it = byString.find(s);
            if (it != byString.end() && !it->second.empty()) {
                toRemove.push_back(it->second.back());
                it->second.pop_back();
            }
        }
        if (!toRemove.empty()) {
            if (editor->m_editorUI) editor->m_editorUI->deselectAll();
            for (auto* obj : toRemove) editor->removeObject(obj, true);
        }
    }

    // Additions: create objects from their save strings
    if (!diff.added.empty()) {
        std::string objects;
        for (auto& s : diff.added) {
            objects += s;
            objects += ';';
        }
        editor->createObjectsFromString(objects, true, true);
    }
}

// ------------------------------------------------------------------
// Publish guard - levels received through a session can't be published
// ------------------------------------------------------------------

void CollabManager::markReceived(std::string const& levelName) {
    auto list = Mod::get()->getSavedValue<std::vector<std::string>>("received-levels", {});
    if (std::find(list.begin(), list.end(), levelName) == list.end()) {
        list.push_back(levelName);
        Mod::get()->setSavedValue("received-levels", list);
    }
}

bool CollabManager::canPublishLevel(std::string const& levelName) const {
    auto list = Mod::get()->getSavedValue<std::vector<std::string>>("received-levels", {});
    return std::find(list.begin(), list.end(), levelName) == list.end();
}

std::string CollabManager::getPublishBlockReason(std::string const& levelName) const {
    if (canPublishLevel(levelName)) return "";
    return "This level was shared with you in a collab session.\n"
           "Only the original owner can publish it.";
}
