#include "CollabManager.hpp"
#include <Geode/utils/web.hpp>
#include <Geode/ui/Notification.hpp>
#include <algorithm>
#include <random>
#include <thread>

CollabManager* CollabManager::s_instance = nullptr;

namespace {
    // ws://host -> http://host, wss://host -> https://host, no trailing slash
    std::string toHttpUrl(std::string url) {
        while (!url.empty() && (url.back() == '/' || url.back() == ' ')) url.pop_back();
        if (url.rfind("wss://", 0) == 0) return "https://" + url.substr(6);
        if (url.rfind("ws://", 0) == 0) return "http://" + url.substr(5);
        return url;
    }

    std::string pack(std::string const& raw) {
        return std::string(ZipUtils::compressString(raw, false, 0));
    }
    std::string unpack(std::string const& packed) {
        return std::string(ZipUtils::decompressString(packed, false, 0));
    }

    std::string str(json const& v, char const* key) {
        return v[key].asString().unwrapOr("");
    }
    int num(json const& v, char const* key) {
        return static_cast<int>(v[key].asInt().unwrapOr(0));
    }
    bool flag(json const& v, char const* key) {
        return v[key].asBool().unwrapOr(false);
    }

    void toast(std::string const& text, NotificationIcon icon = NotificationIcon::Success) {
        Notification::create(text, icon)->show();
    }

    std::string currentLevelString() {
        auto* lel = LevelEditorLayer::get();
        if (!lel) return "";
        return std::string(lel->getLevelString());
    }
}

CollabManager* CollabManager::get() {
    if (!s_instance) s_instance = new CollabManager();
    return s_instance;
}

// ---- helpers -------------------------------------------------

std::string CollabManager::url() const {
    return toHttpUrl(Mod::get()->getSettingValue<std::string>("server-url"));
}

std::string CollabManager::userId() {
    // Random id made once per install. (Account IDs are 0 when logged out.)
    auto id = Mod::get()->getSavedValue<std::string>("client-id", "");
    if (id.empty()) {
        std::random_device rd;
        char buf[3];
        for (int i = 0; i < 12; i++) {
            snprintf(buf, sizeof(buf), "%02x", (unsigned)(rd() & 0xFF));
            id += buf;
        }
        Mod::get()->setSavedValue<std::string>("client-id", id);
    }
    return id;
}

std::string CollabManager::username() const {
    auto name = Mod::get()->getSettingValue<std::string>("username");
    if (name.empty() || name == "Player") {
        std::string gdName = GJAccountManager::sharedState()->m_username;
        if (!gdName.empty()) return gdName;
    }
    return name.empty() ? "Player" : name;
}

json CollabManager::baseMsg(char const* type) {
    json msg = matjson::makeObject({});
    msg["type"] = std::string(type);
    msg["userId"] = userId();
    msg["username"] = username();
    if (m_inSession) msg["sessionId"] = m_session.sessionId;
    return msg;
}

void CollabManager::post(json body, std::function<void(bool, json const&)> cb) {
    std::string target = url() + "/message";
    std::string payload = body.dump(0);

    std::thread([target, payload, cb = std::move(cb)] {
        auto res = web::WebRequest()
            .header("Content-Type", "application/json")
            .bodyString(payload)
            .postSync(target);

        bool ok = res.ok();
        std::string text;
        if (ok) {
            auto s = res.string();
            if (s) text = s.unwrap(); else ok = false;
        }
        queueInMainThread([ok, text, cb] {
            if (!ok) { cb(false, json()); return; }
            auto parsed = matjson::parse(text);
            if (!parsed) { cb(false, json()); return; }
            cb(true, parsed.unwrap());
        });
    }).detach();
}

void CollabManager::readPresence(json const& resp) {
    auto arr = resp["collaborators"].asArray();
    if (!arr) return;
    m_session.collaborators.clear();
    for (auto const& v : arr.unwrap()) {
        m_session.collaborators.push_back(v.asString().unwrapOr("?"));
    }
}

bool CollabManager::editorMatchesSession() const {
    auto* lel = LevelEditorLayer::get();
    return lel && lel->m_level && std::string(lel->m_level->m_levelName) == m_session.levelName;
}

// ---- server ---------------------------------------------------

void CollabManager::ping() {
    std::string target = url();
    std::thread([target] {
        auto res = web::WebRequest().getSync(target);
        bool ok = res.ok();
        queueInMainThread([ok] {
            auto* self = CollabManager::get();
            if (self->m_online != ok) log::info("[CollabV2] Server {}", ok ? "online" : "offline");
            self->m_online = ok;
        });
    }).detach();
}

// ---- sessions -------------------------------------------------

void CollabManager::createSession(Done done) {
    if (m_inSession) { done(false, "You are already in a session. Leave first."); return; }
    auto* lel = LevelEditorLayer::get();
    if (!lel || !lel->m_level) { done(false, "Open a level in the editor first."); return; }
    if (m_busy) { done(false, "Busy, try again in a second."); return; }

    std::string levelName = lel->m_level->m_levelName;
    std::string raw = currentLevelString();

    json msg = baseMsg("CREATE_SESSION");
    msg["levelName"] = levelName;
    msg["levelData"] = pack(raw);

    m_busy = true;
    post(msg, [this, levelName, raw, done](bool net, json const& r) {
        m_busy = false;
        m_online = net;
        if (!net) { done(false, "Could not reach the server. Check the Server URL in the mod settings."); return; }
        if (!flag(r, "ok")) { done(false, str(r, "error")); return; }

        m_session = CollabSession();
        m_session.sessionId = str(r, "sessionId");
        m_session.ownerName = username();
        m_session.levelName = levelName;
        m_session.isOwner = true;
        m_session.baseData = raw;
        m_session.baseVersion = m_session.remoteVersion = num(r, "version");
        m_inSession = true;
        m_pollTimer = m_pushTimer = 0.f;
        done(true, m_session.sessionId);
    });
}

void CollabManager::joinSession(std::string sessionId, Done done) {
    if (m_inSession) { done(false, "You are already in a session. Leave first."); return; }
    if (m_busy) { done(false, "Busy, try again in a second."); return; }

    std::transform(sessionId.begin(), sessionId.end(), sessionId.begin(), ::toupper);
    sessionId.erase(std::remove_if(sessionId.begin(), sessionId.end(), ::isspace), sessionId.end());

    json msg = baseMsg("JOIN_SESSION");
    msg["sessionId"] = sessionId;

    m_busy = true;
    post(msg, [this, done](bool net, json const& r) {
        m_busy = false;
        m_online = net;
        if (!net) { done(false, "Could not reach the server. Check the Server URL in the mod settings."); return; }
        if (!flag(r, "ok")) { done(false, str(r, "error")); return; }

        std::string raw = unpack(str(r, "levelData"));
        if (raw.empty()) { done(false, "The shared level was empty or corrupted."); return; }

        std::string importedName = str(r, "levelName") + " (collab)";
        bool owner = flag(r, "isOwner");

        m_session = CollabSession();
        m_session.sessionId = str(r, "sessionId");
        m_session.ownerName = str(r, "ownerName");
        m_session.levelName = importedName;
        m_session.isOwner = owner;
        m_session.baseData = raw;
        m_session.baseVersion = m_session.remoteVersion = num(r, "version");
        m_inSession = true;
        m_pollTimer = m_pushTimer = 0.f;
        readPresence(r);

        if (owner) {
            // The owner re-joining their own session: keep their own level, no import
            m_session.levelName = str(r, "levelName");
            done(true, "Rejoined your own session.");
            return;
        }

        markReceived(importedName);   // from now on this level can never be published
        done(true, "Imported \"" + importedName + "\".");
        importAsNewLevel(importedName, raw);
    });
}

void CollabManager::leaveSession() {
    if (!m_inSession) return;
    post(baseMsg("LEAVE_SESSION"), [](bool, json const&) {});
    m_inSession = false;
    m_session = CollabSession();
    log::info("[CollabV2] Left session.");
}

void CollabManager::sessionEnded(std::string const& why) {
    m_inSession = false;
    m_session = CollabSession();
    toast(why, NotificationIcon::Warning);
}

// ---- level import / apply --------------------------------------

void CollabManager::importAsNewLevel(std::string const& levelName, std::string const& raw) {
    auto* level = GameLevelManager::sharedState()->createNewLevel();
    if (!level) return;
    level->m_levelName = levelName;
    level->m_levelString = pack(raw);

    auto* scene = LevelEditorLayer::scene(level, false);
    CCDirector::sharedDirector()->replaceScene(CCTransitionFade::create(0.5f, scene));
}

void CollabManager::applyToEditor(std::string const& raw) {
    auto* lel = LevelEditorLayer::get();
    if (!lel || !lel->m_level) return;
    auto* level = lel->m_level;
    level->m_levelString = pack(raw);

    auto* scene = LevelEditorLayer::scene(level, false);
    CCDirector::sharedDirector()->replaceScene(CCTransitionFade::create(0.3f, scene));
}

// ---- syncing ----------------------------------------------------

void CollabManager::syncNow() {
    if (!m_inSession) return;
    if (m_busy) { toast("Sync already running...", NotificationIcon::Info); return; }
    if (!editorMatchesSession()) {
        toast("Open \"" + m_session.levelName + "\" in the editor to sync.", NotificationIcon::Warning);
        return;
    }

    std::string cur = currentLevelString();
    bool dirty = collab::hashLevel(cur) != collab::hashLevel(m_session.baseData);

    if (dirty) {
        m_busy = true;
        pushData(cur, m_session.baseVersion, true, 0);
        return;
    }

    json msg = baseMsg("PULL");
    msg["sinceVersion"] = m_session.baseVersion;
    m_busy = true;
    post(msg, [this](bool net, json const& r) {
        m_busy = false;
        m_online = net;
        if (!net) { toast("Could not reach the server.", NotificationIcon::Error); return; }
        if (!flag(r, "ok")) {
            if (flag(r, "closed")) sessionEnded(str(r, "error"));
            else toast(str(r, "error"), NotificationIcon::Error);
            return;
        }
        readPresence(r);
        m_session.remoteVersion = num(r, "version");
        if (!flag(r, "changed")) { toast("Already up to date."); return; }
        integrateRemote(unpack(str(r, "levelData")), num(r, "version"), true);
    });
}

// Uploads `raw`. On a version conflict (someone synced first) it merges with
// their copy and tries once more. m_busy must already be true.
void CollabManager::pushData(std::string raw, int baseVersion, bool manual, int attempt) {
    json msg = baseMsg("PUSH");
    msg["baseVersion"] = baseVersion;
    msg["levelData"] = pack(raw);

    post(msg, [this, raw, manual, attempt](bool net, json const& r) {
        if (!net) {
            m_busy = false; m_online = false;
            if (manual) toast("Could not reach the server.", NotificationIcon::Error);
            return;
        }
        m_online = true;

        if (flag(r, "ok")) {
            m_busy = false;
            m_session.baseData = raw;
            m_session.baseVersion = m_session.remoteVersion = num(r, "version");
            readPresence(r);
            if (manual) toast("Synced!");
            return;
        }

        if (flag(r, "closed")) { m_busy = false; sessionEnded(str(r, "error")); return; }

        if (flag(r, "conflict")) {
            int theirsVersion = num(r, "version");
            m_session.remoteVersion = theirsVersion;
            if (!manual || attempt >= 1) {
                // Automatic pushes never touch your editor; just tell you to sync.
                m_busy = false;
                if (manual) toast("Someone synced at the same time. Press Sync Now again.", NotificationIcon::Warning);
                return;
            }
            // Merge their copy into what is in the editor right now, then push the result.
            std::string theirs = unpack(str(r, "levelData"));
            std::string cur = currentLevelString();
            std::string merged = collab::mergeLevels(m_session.baseData, cur, theirs);
            m_session.baseData = theirs;
            m_session.baseVersion = theirsVersion;
            bool changed = collab::hashLevel(merged) != collab::hashLevel(cur);
            pushData(merged, theirsVersion, manual, attempt + 1);
            if (changed) applyToEditor(merged);
            toast("Merged with your friends' changes.");
            return;
        }

        m_busy = false;
        if (manual) toast(str(r, "error").empty() ? "Sync failed." : str(r, "error"), NotificationIcon::Error);
    });
}

// Brings the server copy into the editor, keeping any local edits.
void CollabManager::integrateRemote(std::string const& theirs, int theirsVersion, bool manual) {
    if (theirs.empty()) return;
    std::string cur = currentLevelString();
    bool localChanges = collab::hashLevel(cur) != collab::hashLevel(m_session.baseData);
    std::string merged = localChanges ? collab::mergeLevels(m_session.baseData, cur, theirs) : theirs;

    m_session.baseData = theirs;
    m_session.baseVersion = m_session.remoteVersion = theirsVersion;

    if (collab::hashLevel(merged) != collab::hashLevel(cur)) {
        applyToEditor(merged);
        if (manual) toast("Updated with your friends' changes.");
    } else if (manual) {
        toast("Already up to date.");
    }
    // If merged differs from theirs, the next sync pushes it.
}

void CollabManager::tick(float dt) {
    if (!m_inSession || m_busy) return;
    if (!editorMatchesSession()) return;

    m_pollTimer += dt;
    m_pushTimer += dt;

    // Auto-sync: upload your own changes every 5s. This never reloads your editor.
    if (m_pushTimer >= 5.f && Mod::get()->getSettingValue<bool>("auto-sync")) {
        m_pushTimer = 0.f;
        std::string cur = currentLevelString();
        if (collab::hashLevel(cur) != collab::hashLevel(m_session.baseData)) {
            m_busy = true;
            pushData(cur, m_session.baseVersion, false, 0);
            return;
        }
    }

    // Cheap status poll every 3s: who is online, is there a newer copy?
    if (m_pollTimer >= 3.f) {
        m_pollTimer = 0.f;
        m_busy = true;
        post(baseMsg("STATUS"), [this](bool net, json const& r) {
            m_busy = false;
            m_online = net;
            if (!net) return;
            if (!flag(r, "ok")) {
                if (flag(r, "closed")) sessionEnded(str(r, "error"));
                return;
            }
            int v = num(r, "version");
            bool wasNew = hasRemoteUpdates();
            m_session.remoteVersion = std::max(m_session.remoteVersion, v);
            if (!wasNew && hasRemoteUpdates() && Mod::get()->getSettingValue<bool>("notify-on-edit")) {
                toast("Your friends made changes - press Sync Now.", NotificationIcon::Info);
            }

            // Presence: notify on joins/leaves
            auto before = m_session.collaborators;
            readPresence(r);
            for (auto& n : m_session.collaborators)
                if (std::find(before.begin(), before.end(), n) == before.end())
                    toast(n + " joined the session!");
            for (auto& n : before)
                if (std::find(m_session.collaborators.begin(), m_session.collaborators.end(), n) == m_session.collaborators.end())
                    toast(n + " left the session.", NotificationIcon::Warning);
        });
    }
}

// ---- THE CORE PUBLISH GUARD -------------------------------------
// A level you received can never be published. The list is saved to disk, so
// it survives restarting the game and leaving the session.

void CollabManager::markReceived(std::string const& levelName) {
    auto list = Mod::get()->getSavedValue<std::vector<std::string>>("received-levels", {});
    if (std::find(list.begin(), list.end(), levelName) == list.end()) {
        list.push_back(levelName);
        Mod::get()->setSavedValue<std::vector<std::string>>("received-levels", list);
    }
}

bool CollabManager::canPublishLevel(std::string const& levelName) const {
    if (m_inSession && !m_session.isOwner && m_session.levelName == levelName) return false;
    auto list = Mod::get()->getSavedValue<std::vector<std::string>>("received-levels", {});
    return std::find(list.begin(), list.end(), levelName) == list.end();
}

std::string CollabManager::getPublishBlockReason(std::string const& levelName) const {
    if (canPublishLevel(levelName)) return "";
    return "This level was shared to you by another player.\n"
           "Only the original owner can publish it.";
}
