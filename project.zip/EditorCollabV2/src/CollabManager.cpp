#include "CollabManager.hpp"
#include <Geode/ui/Notification.hpp>
#include <algorithm>
#include <random>

CollabManager* CollabManager::s_instance = nullptr;

namespace {
    constexpr char const* kMagic = "ECV2";

    std::string pack(std::string const& raw) {
        return std::string(ZipUtils::compressString(raw, false, 0));
    }
    std::string unpack(std::string const& packed) {
        return std::string(ZipUtils::decompressString(packed, false, 0));
    }
    void toast(std::string const& text, NotificationIcon icon = NotificationIcon::Success) {
        Notification::create(text, icon)->show();
    }

    // Package = 5 lines: ECV2 / ownerId / original level name / sender name / packed level
    struct Package {
        bool valid = false;
        std::string ownerId, name, fromName, packed;
    };

    Package parsePackage(std::string text) {
        Package p;
        // trim whitespace around the whole thing
        while (!text.empty() && isspace((unsigned char)text.back())) text.pop_back();
        size_t start = 0;
        while (start < text.size() && isspace((unsigned char)text[start])) start++;
        text = text.substr(start);

        std::string lines[5];
        size_t pos = 0;
        for (int i = 0; i < 4; i++) {
            size_t nl = text.find('\n', pos);
            if (nl == std::string::npos) return p;
            lines[i] = text.substr(pos, nl - pos);
            if (!lines[i].empty() && lines[i].back() == '\r') lines[i].pop_back();
            pos = nl + 1;
        }
        lines[4] = text.substr(pos);
        lines[4].erase(std::remove_if(lines[4].begin(), lines[4].end(), ::isspace), lines[4].end());
        if (lines[0] != kMagic || lines[4].empty() || lines[1].empty()) return p;
        p.ownerId = lines[1]; p.name = lines[2]; p.fromName = lines[3]; p.packed = lines[4];
        p.valid = true;
        return p;
    }
}

CollabManager* CollabManager::get() {
    if (!s_instance) s_instance = new CollabManager();
    return s_instance;
}

std::string CollabManager::userId() {
    // Random id made once per install; marks which levels are yours.
    auto id = Mod::get()->getSavedValue<std::string>("client-id", "");
    if (id.empty()) {
        std::random_device rd;
        char buf[3];
        for (int i = 0; i < 12; i++) {
            snprintf(buf, sizeof(buf), "%02x", (unsigned)(rd() & 0xFF));
            id += buf;
        }
        Mod::get()->setSavedValue<std::string>("client-id", id);
    }
    return id;
}

std::string CollabManager::username() const {
    auto name = Mod::get()->getSettingValue<std::string>("username");
    if (name.empty() || name == "Player") {
        std::string gdName = GJAccountManager::sharedState()->m_username;
        if (!gdName.empty()) return gdName;
    }
    return name.empty() ? "Player" : name;
}

// ---- Send ----------------------------------------------------

void CollabManager::sendToClipboard() {
    auto* lel = LevelEditorLayer::get();
    if (!lel || !lel->m_level) { toast("Open a level in the editor first.", NotificationIcon::Warning); return; }

    std::string localName = lel->m_level->m_levelName;
    std::string raw = std::string(lel->getLevelString());
    if (raw.empty()) { toast("The level is empty.", NotificationIcon::Warning); return; }

    // Who owns it? If you received this level, the original owner stays the owner.
    std::string ownerId = userId();
    std::string origName = localName;
    auto origin = Mod::get()->getSavedValue<std::string>("origin-" + localName, "");
    if (!origin.empty()) {
        auto nl = origin.find('\n');
        if (nl != std::string::npos) { ownerId = origin.substr(0, nl); origName = origin.substr(nl + 1); }
    }

    std::string packed = pack(raw);
    std::string pkg = std::string(kMagic) + "\n" + ownerId + "\n" + origName + "\n" + username() + "\n" + packed;
    geode::utils::clipboard::write(pkg);

    // What we just sent is now the shared starting point for the next merge.
    Mod::get()->setSavedValue<std::string>("base-" + localName, packed);

    lastInfo = "Sent " + std::to_string(pkg.size() / 1024) + " KB";
    toast("Copied! Paste it to your friend in Discord (or anywhere).");
}

// ---- Receive -------------------------------------------------

void CollabManager::receiveFromClipboard() {
    auto pkg = parsePackage(geode::utils::clipboard::read());
    if (!pkg.valid) {
        toast("Clipboard has no collab level. Ask your friend to press Send, then copy their message.",
              NotificationIcon::Error);
        return;
    }
    std::string theirs = unpack(pkg.packed);
    if (theirs.empty()) {
        toast("That level data is damaged or cut off. Ask for it again.", NotificationIcon::Error);
        return;
    }

    bool mine = pkg.ownerId == userId();
    std::string localName = mine ? pkg.name : pkg.name + " (collab)";

    auto* lel = LevelEditorLayer::get();
    bool editingIt = lel && lel->m_level && std::string(lel->m_level->m_levelName) == localName;

    if (editingIt) {
        // Merge their copy into the level you have open
        std::string cur = std::string(lel->getLevelString());
        std::string base = unpack(Mod::get()->getSavedValue<std::string>("base-" + localName, ""));
        std::string merged = collab::mergeLevels(base, cur, theirs);

        Mod::get()->setSavedValue<std::string>("base-" + localName, pkg.packed);
        lastInfo = "Merged from " + pkg.fromName;

        if (collab::hashLevel(merged) == collab::hashLevel(cur)) {
            toast("Nothing new from " + pkg.fromName + ".");
        } else {
            toast("Merged " + pkg.fromName + "'s changes!");
            applyToEditor(merged);
        }
        return;
    }

    // Not editing the matching level: bring it in as a new local level
    std::string newName = localName;
    if (mine) newName = pkg.name + " (merged)";
    if (!mine) {
        markReceived(newName);
        Mod::get()->setSavedValue<std::string>("origin-" + newName, pkg.ownerId + "\n" + pkg.name);
    }
    Mod::get()->setSavedValue<std::string>("base-" + newName, pkg.packed);
    lastInfo = "Imported from " + pkg.fromName;
    toast("Imported \"" + newName + "\" from " + pkg.fromName + ".");
    openAsNewLevel(newName, theirs);
}

void CollabManager::openAsNewLevel(std::string const& name, std::string const& raw) {
    auto* level = GameLevelManager::sharedState()->createNewLevel();
    if (!level) return;
    level->m_levelName = name;
    level->m_levelString = pack(raw);
    auto* scene = LevelEditorLayer::scene(level, false);
    CCDirector::sharedDirector()->replaceScene(CCTransitionFade::create(0.5f, scene));
}

void CollabManager::applyToEditor(std::string const& raw) {
    auto* lel = LevelEditorLayer::get();
    if (!lel || !lel->m_level) return;
    auto* level = lel->m_level;
    level->m_levelString = pack(raw);
    auto* scene = LevelEditorLayer::scene(level, false);
    CCDirector::sharedDirector()->replaceScene(CCTransitionFade::create(0.3f, scene));
}

// ---- THE CORE PUBLISH GUARD -------------------------------------
// A level you received can never be published. The list is saved to disk, so
// it survives restarting the game.

void CollabManager::markReceived(std::string const& localName) {
    auto list = Mod::get()->getSavedValue<std::vector<std::string>>("received-levels", {});
    if (std::find(list.begin(), list.end(), localName) == list.end()) {
        list.push_back(localName);
        Mod::get()->setSavedValue<std::vector<std::string>>("received-levels", list);
    }
}

bool CollabManager::canPublishLevel(std::string const& levelName) const {
    auto list = Mod::get()->getSavedValue<std::vector<std::string>>("received-levels", {});
    return std::find(list.begin(), list.end(), levelName) == list.end();
}

std::string CollabManager::getPublishBlockReason(std::string const& levelName) const {
    if (canPublishLevel(levelName)) return "";
    return "This level was shared to you by another player.\n"
           "Only the original owner can publish it.";
}
