#include "CollabManager.hpp"
#include <Geode/utils/web.hpp>
#include <Geode/ui/Notification.hpp>
#include <thread>
#include <algorithm>

namespace {
    // ws://host -> http://host, wss://host -> https://host
    std::string toHttpUrl(std::string url) {
        if (url.rfind("wss://", 0) == 0) return "https://" + url.substr(6);
        if (url.rfind("ws://", 0) == 0) return "http://" + url.substr(5);
        return url;
    }
}

CollabManager* CollabManager::s_instance = nullptr;

CollabManager* CollabManager::get() {
    if (!s_instance)
        s_instance = new CollabManager();
    return s_instance;
}

bool CollabManager::connect(const std::string& url) {
    m_wsUrl = url;

    // Get account info
    auto* gjam = GJAccountManager::sharedState();
    m_myAccountId = std::to_string(gjam->m_accountID);
    m_myUsername = Mod::get()->getSettingValue<std::string>("username");

    // Check in the background that the server answers
    std::thread([httpUrl = toHttpUrl(url), wsUrl = url] {
        auto res = web::WebRequest().getSync(httpUrl);
        if (res.ok()) {
            queueInMainThread([wsUrl] {
                log::info("[CollabV2] Connected to server: {}", wsUrl);
            });
        }
    }).detach();

    m_connected = true; // optimistic for local dev
    return true;
}

void CollabManager::disconnect() {
    m_connected = false;
    m_inSession = false;
    log::info("[CollabV2] Disconnected.");
}

bool CollabManager::createSession(const std::string& levelData, const std::string& levelName) {
    if (!m_connected) return false;

    m_session.sessionId = std::to_string(std::rand() % 999999 + 100000);
    m_session.ownerName = m_myUsername;
    m_session.ownerAccountId = m_myAccountId;
    m_session.levelData = levelData;
    m_session.levelName = levelName;
    m_session.isOwner = true;
    m_session.canPublish = true; // owner can always publish
    m_session.collaborators.clear();
    m_inSession = true;

    log::info("[CollabV2] Session created: {}", m_session.sessionId);

    if (onSessionCreated)
        onSessionCreated(m_session.sessionId);

    return true;
}

bool CollabManager::joinSession(const std::string& sessionId) {
    if (!m_connected) return false;

    // In real implementation this requests session data from server
    // For now we set up the structure

    m_session.sessionId = sessionId;
    m_session.isOwner = false;
    m_session.canPublish = false; // Collaborator CANNOT publish
    m_inSession = true;

    // Track that we received this level from someone else
    m_receivedLevels[m_session.levelName] = m_session.ownerAccountId;

    log::info("[CollabV2] Joined session: {}", sessionId);
    return true;
}

void CollabManager::leaveSession() {
    if (!m_inSession) return;

    json msg = matjson::makeObject({});
    msg["type"] = "LEAVE_SESSION";
    msg["sessionId"] = m_session.sessionId;
    msg["userId"] = m_myAccountId;
    msg["username"] = m_myUsername;
    sendMessage(msg);

    m_inSession = false;
    log::info("[CollabV2] Left session.");
}

bool CollabManager::shareLevel(const std::string& friendId, const std::string& levelData) {
    if (!m_connected) return false;
    if (!isOwner()) {
        // Cannot share a level you received from someone else
        if (onError)
            onError("You cannot reshare a level shared to you!");
        return false;
    }

    json msg = matjson::makeObject({});
    msg["type"] = "SHARE_LEVEL";
    msg["fromId"] = m_myAccountId;
    msg["fromName"] = m_myUsername;
    msg["toId"] = friendId;
    msg["sessionId"] = m_session.sessionId;
    msg["levelName"] = m_session.levelName;
    msg["levelData"] = levelData;
    msg["canPublish"] = false; // Receiver explicitly cannot publish
    sendMessage(msg);

    log::info("[CollabV2] Level shared to friend: {}", friendId);
    return true;
}

bool CollabManager::receiveSharedLevel(const json& shareData) {
    std::string levelName = shareData["levelName"].asString().unwrapOr("");
    std::string ownerAccountId = shareData["fromId"].asString().unwrapOr("");
    std::string ownerName = shareData["fromName"].asString().unwrapOr("");

    // Register that we received this level
    m_receivedLevels[levelName] = ownerAccountId;

    m_session.levelName = levelName;
    m_session.levelData = shareData["levelData"].asString().unwrapOr("");
    m_session.ownerName = ownerName;
    m_session.ownerAccountId = ownerAccountId;
    m_session.isOwner = false;
    m_session.canPublish = false;
    m_session.sessionId = shareData["sessionId"].asString().unwrapOr("");
    m_inSession = true;

    log::info("[CollabV2] Received shared level '{}' from {}", levelName, ownerName);
    return true;
}

void CollabManager::sendObjectAdd(const std::string& objData) {
    if (!m_inSession) return;

    json msg = matjson::makeObject({});
    msg["type"] = "EDIT";
    msg["editType"] = "ADD";
    msg["sessionId"] = m_session.sessionId;
    msg["authorId"] = m_myAccountId;
    msg["authorName"] = m_myUsername;
    msg["objectData"] = objData;
    sendMessage(msg);
}

void CollabManager::sendObjectDelete(int objId) {
    if (!m_inSession) return;

    json msg = matjson::makeObject({});
    msg["type"] = "EDIT";
    msg["editType"] = "DELETE";
    msg["sessionId"] = m_session.sessionId;
    msg["authorId"] = m_myAccountId;
    msg["authorName"] = m_myUsername;
    msg["objectId"] = objId;
    sendMessage(msg);
}

void CollabManager::sendObjectModify(int objId, const std::string& objData) {
    if (!m_inSession) return;

    json msg = matjson::makeObject({});
    msg["type"] = "EDIT";
    msg["editType"] = "MODIFY";
    msg["sessionId"] = m_session.sessionId;
    msg["authorId"] = m_myAccountId;
    msg["authorName"] = m_myUsername;
    msg["objectId"] = objId;
    msg["objectData"] = objData;
    sendMessage(msg);
}

void CollabManager::applyPendingEdits() {
    if (m_pendingEdits.empty()) return;

    for (auto& edit : m_pendingEdits) {
        log::info("[CollabV2] Applying edit from {}: {}", edit.authorName, edit.editType);
        if (onEditReceived)
            onEditReceived(edit);
    }
    m_pendingEdits.clear();
}

void CollabManager::syncLevelData(const std::string& levelData) {
    if (!m_inSession || !isOwner()) return;

    json msg = matjson::makeObject({});
    msg["type"] = "SYNC";
    msg["sessionId"] = m_session.sessionId;
    msg["levelData"] = levelData;
    msg["authorId"] = m_myAccountId;
    sendMessage(msg);

    m_session.lastSync = std::chrono::steady_clock::now();
}

void CollabManager::requestFullSync() {
    if (!m_inSession) return;

    json msg = matjson::makeObject({});
    msg["type"] = "REQUEST_SYNC";
    msg["sessionId"] = m_session.sessionId;
    msg["requesterId"] = m_myAccountId;
    sendMessage(msg);
}

// ============================================================
// THE CORE PUBLISH GUARD
// This is the 1 rule — you cannot publish a received level
// ============================================================
bool CollabManager::canPublishLevel() const {
    // If in a session and you are NOT the owner -> BLOCK
    if (m_inSession && !m_session.isOwner) {
        return false;
    }

    // Check received levels map
    auto it = m_receivedLevels.find(m_session.levelName);
    if (it != m_receivedLevels.end()) {
        // This level was received from someone else
        return false;
    }

    return true;
}

std::string CollabManager::getPublishBlockReason() const {
    if (m_inSession && !m_session.isOwner) {
        return "This level was shared to you by " + m_session.ownerName +
               ".\nYou cannot publish someone else's shared level.";
    }

    auto it = m_receivedLevels.find(m_session.levelName);
    if (it != m_receivedLevels.end()) {
        return "You received this level from another player.\n"
               "Only the original owner can publish it.";
    }

    return "";
}

std::string CollabManager::getMergedLevelData() {
    // In real implementation this would merge local + all collaborator edits
    return m_session.levelData;
}

void CollabManager::sendMessage(const json& data) {
    // Sends over HTTP POST to the server (in a background thread)
    std::string url = toHttpUrl(m_wsUrl) + "/message";
    std::string body = data.dump();

    std::thread([url, body] {
        auto res = web::WebRequest()
            .header("Content-Type", "application/json")
            .bodyString(body)
            .postSync(url);
        if (!res.ok()) {
            queueInMainThread([] {
                log::warn("[CollabV2] Failed to send message");
            });
        }
    }).detach();
}

void CollabManager::handleMessage(const std::string& msg) {
    auto parsed = matjson::parse(msg);
    if (!parsed) {
        log::error("[CollabV2] Parse error");
        return;
    }
    auto data = parsed.unwrap();
    auto str = [&](char const* key) -> std::string {
        return data[key].asString().unwrapOr("");
    };

    std::string type = str("type");

    if (type == "EDIT") {
        PendingEdit edit;
        edit.authorName = str("authorName");
        edit.authorId = str("authorId");
        edit.editType = str("editType");
        edit.objectId = 0;
        if (data.contains("objectData"))
            edit.objectData = str("objectData");
        if (data.contains("objectId"))
            edit.objectId = static_cast<int>(data["objectId"].asInt().unwrapOr(0));
        m_pendingEdits.push_back(edit);

        if (Mod::get()->getSettingValue<bool>("notify-on-edit")) {
            Notification::create(
                edit.authorName + " made an edit",
                NotificationIcon::Info
            )->show();
        }

    } else if (type == "SYNC") {
        m_session.levelData = str("levelData");
        if (onSyncReceived)
            onSyncReceived(m_session.levelData);

    } else if (type == "FRIEND_JOINED") {
        std::string name = str("username");
        m_session.collaborators.push_back(name);
        if (onFriendJoined)
            onFriendJoined(name);

    } else if (type == "FRIEND_LEFT") {
        std::string name = str("username");
        auto it = std::find(m_session.collaborators.begin(),
                            m_session.collaborators.end(), name);
        if (it != m_session.collaborators.end())
            m_session.collaborators.erase(it);
        if (onFriendLeft)
            onFriendLeft(name);

    } else if (type == "SHARE_LEVEL") {
        receiveSharedLevel(data);
    }
}

void CollabManager::fetchFriends() {
    // Pulls from GD friends list
    // In real implementation hooks GJ_getFriendsAccountIDs
    // Mock data for now
    m_friends.clear();
    // Will be populated via hook on GameLevelManager
    log::info("[CollabV2] Fetching friends list...");
}