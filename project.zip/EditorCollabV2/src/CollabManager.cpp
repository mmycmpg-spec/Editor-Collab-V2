#include "CollabManager.hpp"
#include <Geode/ui/Notification.hpp>
#include <algorithm>
#include <random>

CollabManager* CollabManager::s_instance = nullptr;

namespace {
    constexpr char const* kMagic = "ECV2";

    std::string pack(std::string const& raw) {
        return std::string(ZipUtils::compressString(raw, false, 0));
    }
    std::string unpack(std::string const& packed) {
        return std::string(ZipUtils::decompressString(packed, false, 0));
    }
    void toast(std::string const& text, NotificationIcon icon = NotificationIcon::Success) {
        Notification::create(text, icon)->show();
    }

    // A packed level is gzip+base64, which always starts with "H4sI". Checking this
    // first keeps garbage from ever reaching the decompressor.
    bool looksPacked(std::string const& p) {
        return p.size() > 16 && p.size() < 40u * 1024 * 1024 && p.rfind("H4sI", 0) == 0;
    }

    // Package = 5 lines: ECV2 / ownerId / original level name / sender name / packed level
    struct Package {
        bool valid = false;
        std::string ownerId, name, fromName, packed;
    };

    Package parsePackage(std::string text) {
        Package p;
        // trim whitespace around the whole thing
        while (!text.empty() && isspace((unsigned char)text.back())) text.pop_back();
        size_t start = 0;
        while (start < text.size() && isspace((unsigned char)text[start])) start++;
        text = text.substr(start);

        std::string lines[5];
        size_t pos = 0;
        for (int i = 0; i < 4; i++) {
            size_t nl = text.find('\n', pos);
            if (nl == std::string::npos) return p;
            lines[i] = text.substr(pos, nl - pos);
            if (!lines[i].empty() && lines[i].back() == '\r') lines[i].pop_back();
            pos = nl + 1;
        }
        lines[4] = text.substr(pos);
        lines[4].erase(std::remove_if(lines[4].begin(), lines[4].end(), ::isspace), lines[4].end());
        if (lines[0] != kMagic || lines[1].empty() || !looksPacked(lines[4])) return p;
        p.ownerId = lines[1]; p.name = lines[2]; p.fromName = lines[3]; p.packed = lines[4];
        p.valid = true;
        return p;
    }
}

CollabManager* CollabManager::get() {
    if (!s_instance) s_instance = new CollabManager();
    return s_instance;
}

std::string CollabManager::userId() {
    // Random id made once per install; marks which levels are yours.
    auto id = Mod::get()->getSavedValue<std::string>("client-id", "");
    if (id.empty()) {
        std::random_device rd;
        char buf[3];
        for (int i = 0; i < 12; i++) {
            snprintf(buf, sizeof(buf), "%02x", (unsigned)(rd() & 0xFF));
            id += buf;
        }
        Mod::get()->setSavedValue<std::string>("client-id", id);
    }
    return id;
}

std::string CollabManager::username() const {
    auto name = Mod::get()->getSettingValue<std::string>("username");
    if (name.empty() || name == "Player") {
        std::string gdName = GJAccountManager::sharedState()->m_username;
        if (!gdName.empty()) return gdName;
    }
    return name.empty() ? "Player" : name;
}

// ---- Session buttons -----------------------------------------

// Builds the code for the level open in the editor. Returns false if there is none.
bool CollabManager::copyLevel(std::string& pkgOut) {
    auto* lel = LevelEditorLayer::get();
    if (!lel || !lel->m_level) { toast("Open a level in the editor first.", NotificationIcon::Warning); return false; }

    std::string localName = lel->m_level->m_levelName;
    std::string raw = std::string(lel->getLevelString());
    if (raw.empty()) { toast("The level is empty.", NotificationIcon::Warning); return false; }

    // If you received this level, the original owner stays the owner.
    std::string ownerId = userId();
    std::string origName = localName;
    auto origin = Mod::get()->getSavedValue<std::string>("origin-" + localName, "");
    if (!origin.empty()) {
        auto nl = origin.find('\n');
        if (nl != std::string::npos) { ownerId = origin.substr(0, nl); origName = origin.substr(nl + 1); }
    }

    std::string packed = pack(raw);
    pkgOut = std::string(kMagic) + "\n" + ownerId + "\n" + origName + "\n" + username() + "\n" + packed;
    geode::utils::clipboard::write(pkgOut);

    // What we just handed out is the shared starting point for the next merge.
    Mod::get()->setSavedValue<std::string>("base-" + localName, packed);
    m_levelName = localName;
    return true;
}

void CollabManager::createSession() {
    if (m_inSession) {
        FLAlertLayer::create("Already in a session", "Press Leave Session first.", "OK")->show();
        return;
    }
    std::string pkg;
    if (!copyLevel(pkg)) return;

    m_inSession = true;
    m_host = true;
    m_otherName = "";
    FLAlertLayer::create(
        "Session Created!",
        "Your session code was copied to your clipboard.\n\n"
        "Send it to your friends (paste it in Discord or any chat - if it is too long, "
        "paste it into a .txt file and send that).\n\n"
        "They open the editor, copy it, and press <cy>Join Session</c>.",
        "OK")->show();
}

void CollabManager::joinSession() {
    if (m_inSession) {
        FLAlertLayer::create("Already in a session", "Press Leave Session first.", "OK")->show();
        return;
    }
    receive(true);
}

void CollabManager::shareLevel() {
    std::string pkg;
    if (!copyLevel(pkg)) return;
    toast("Level copied! Paste it to your friend. (They cannot publish it.)");
}

void CollabManager::syncNow() {
    receive(false);
}

void CollabManager::leaveSession() {
    if (!m_inSession) { toast("You are not in a session.", NotificationIcon::Info); return; }
    m_inSession = false;
    m_host = false;
    m_otherName.clear();
    toast("Left the session.", NotificationIcon::Info);
}

std::string CollabManager::statusText() const {
    if (!m_inSession) return "No session";
    if (m_host) return "Hosting: " + m_levelName;
    return "Joined: " + m_levelName;
}

// Reads a code from the clipboard. If you have the matching level open it is
// merged into it, otherwise the level is imported as a NEW level and opened.
void CollabManager::receive(bool joining) {
    auto pkg = parsePackage(geode::utils::clipboard::read());
    if (!pkg.valid) {
        toast(joining ? "Copy the host's session code first, then press Join Session."
                      : "Copy your friend's level code first, then press Sync Now.",
              NotificationIcon::Error);
        return;
    }
    std::string theirs = unpack(pkg.packed);
    if (theirs.empty() || theirs.find(';') == std::string::npos) {
        toast("That code is damaged or cut off. Ask for it again.", NotificationIcon::Error);
        return;
    }

    bool mine = pkg.ownerId == userId();
    std::string localName = mine ? pkg.name : pkg.name + " (collab)";

    auto* lel = LevelEditorLayer::get();
    bool editingIt = lel && lel->m_level && std::string(lel->m_level->m_levelName) == localName;

    if (editingIt) {
        std::string cur = std::string(lel->getLevelString());
        std::string base = unpack(Mod::get()->getSavedValue<std::string>("base-" + localName, ""));
        std::string merged = collab::mergeLevels(base, cur, theirs);
        Mod::get()->setSavedValue<std::string>("base-" + localName, pkg.packed);

        if (joining) { m_inSession = true; m_host = mine; m_levelName = localName; m_otherName = pkg.fromName; }
        if (collab::hashLevel(merged) == collab::hashLevel(cur)) {
            toast("Nothing new from " + pkg.fromName + ".");
        } else {
            toast("Merged " + pkg.fromName + "'s changes!");
            applyToEditor(merged);
        }
        return;
    }

    std::string newName = mine ? pkg.name + " (merged)" : localName;
    if (!mine) {
        markReceived(newName);
        Mod::get()->setSavedValue<std::string>("origin-" + newName, pkg.ownerId + "\n" + pkg.name);
    }
    Mod::get()->setSavedValue<std::string>("base-" + newName, pkg.packed);

    m_inSession = true;
    m_host = mine;
    m_levelName = newName;
    m_otherName = pkg.fromName;

    toast("Joining " + pkg.fromName + "'s level...");
    openAsNewLevel(newName, theirs);   // teleports you into the level
}

// Scene swaps are deferred to the next frame. Replacing the scene from inside a
// button press (while the editor is still handling that touch) is a classic crash.
void CollabManager::openAsNewLevel(std::string name, std::string raw) {
    queueInMainThread([name = std::move(name), raw = std::move(raw)] {
        auto* level = GameLevelManager::sharedState()->createNewLevel();
        if (!level) return;
        level->m_levelName = name;
        level->m_levelString = pack(raw);
        auto* scene = LevelEditorLayer::scene(level, false);
        if (!scene) return;
        CCDirector::sharedDirector()->replaceScene(CCTransitionFade::create(0.5f, scene));
    });
}

void CollabManager::applyToEditor(std::string raw) {
    queueInMainThread([raw = std::move(raw)] {
        auto* lel = LevelEditorLayer::get();
        if (!lel || !lel->m_level) return;
        auto* level = lel->m_level;
        level->m_levelString = pack(raw);
        auto* scene = LevelEditorLayer::scene(level, false);
        if (!scene) return;
        CCDirector::sharedDirector()->replaceScene(CCTransitionFade::create(0.3f, scene));
    });
}

// ---- THE CORE PUBLISH GUARD -------------------------------------
// A level you received can never be published. The list is saved to disk, so
// it survives restarting the game.

void CollabManager::markReceived(std::string const& localName) {
    auto list = Mod::get()->getSavedValue<std::vector<std::string>>("received-levels", {});
    if (std::find(list.begin(), list.end(), localName) == list.end()) {
        list.push_back(localName);
        Mod::get()->setSavedValue<std::vector<std::string>>("received-levels", list);
    }
}

bool CollabManager::canPublishLevel(std::string const& levelName) const {
    auto list = Mod::get()->getSavedValue<std::vector<std::string>>("received-levels", {});
    return std::find(list.begin(), list.end(), levelName) == list.end();
}

std::string CollabManager::getPublishBlockReason(std::string const& levelName) const {
    if (canPublishLevel(levelName)) return "";
    return "This level was shared to you by another player.\n"
           "Only the original owner can publish it.";
}
