#include <Geode/Geode.hpp>
#include "CollabManager.hpp"

using namespace geode::prelude;

$on_mod(Loaded) {
    log::info("Editor Collab v2 loaded!");

    auto serverUrl = Mod::get()->getSettingValue<std::string>("server-url");
    CollabManager::get()->connect(serverUrl);
}
