#include <Geode/Geode.hpp>
#include "CollabManager.hpp"

using namespace geode::prelude;

$on_mod(Loaded) {
    log::info("Editor Collab v2 loaded!");
    CollabManager::get()->ping();
}
