#pragma once
#include <string>

// A tiny relay server that runs inside the game on the host's phone, plus the
// code that lets another phone on the same Wi-Fi / hotspot find it.
// No Geode code in here, only the C++ standard library and POSIX sockets.
namespace collab {

    // Starts the server once (later calls just return the port).
    // Returns the TCP port, or 0 if it could not start.
    int startLocalServer();

    // Looks for a phone on the local network that is hosting this code.
    // Returns "http://ip:port", or "" if nobody answered.
    std::string discoverHost(std::string const& code);

}
