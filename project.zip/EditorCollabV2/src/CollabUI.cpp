#include "CollabUI.hpp"
#include <algorithm>

CollabPanel* CollabPanel::create() {
    auto ret = new CollabPanel();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

namespace {
    CCMenuItemSpriteExtra* makeBtn(CCMenu* menu, CCObject* target, SEL_MenuHandler cb,
                                   char const* text, char const* tex, float scale = 0.5f) {
        auto* spr = ButtonSprite::create(text, "bigFont.fnt", tex, scale);
        auto* btn = CCMenuItemSpriteExtra::create(spr, target, cb);
        menu->addChild(btn);
        return btn;
    }

    CCLabelBMFont* makeLabel(CCNode* parent, char const* text, float scale, CCPoint pos, ccColor3B color) {
        auto* l = CCLabelBMFont::create(text, "chatFont.fnt");
        l->setScale(scale);
        l->setPosition(pos);
        l->setColor(color);
        parent->addChild(l);
        return l;
    }
}

bool CollabPanel::init() {
    if (!CCLayer::init()) return false;

    constexpr float W = kWidth;
    constexpr float H = kHeight;
    this->setContentSize({W, H});

    // Touches: behind the menu buttons, so buttons work and the rest of the panel drags it.
    this->setTouchMode(kCCTouchesOneByOne);
    this->setTouchPriority(-127);
    this->setTouchEnabled(true);

    auto bg = CCScale9Sprite::create("GJ_square01.png");
    bg->setContentSize({W, H});
    bg->setPosition({W / 2, H / 2});
    bg->setOpacity(235);
    addChild(bg);

    auto* title = CCLabelBMFont::create("Editor Collab v2", "bigFont.fnt");
    title->setScale(0.42f);
    title->setPosition({W / 2 - 22, H - 18});
    title->setColor({255, 220, 80});
    addChild(title);

    m_levelLabel = makeLabel(this, "", 0.5f, {W / 2, H - 42}, {255, 255, 255});
    m_publishLabel = makeLabel(this, "", 0.4f, {W / 2, H - 60}, {100, 255, 100});
    m_publishLabel->setWidth(230);

    makeLabel(this, "Send: copies your level. Message it to your friend.", 0.36f, {W / 2, H - 80}, {180, 230, 255});
    makeLabel(this, "Receive: paste your friend's message first, then press it.", 0.36f, {W / 2, H - 91}, {180, 230, 255});

    m_infoLabel = makeLabel(this, "", 0.4f, {W / 2, 62}, {255, 220, 80});

    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    addChild(menu);

    auto* send = makeBtn(menu, this, menu_selector(CollabPanel::onSend), "Send", "GJ_button_01.png");
    auto* recv = makeBtn(menu, this, menu_selector(CollabPanel::onReceive), "Receive", "GJ_button_02.png");
    float w1 = send->getScaledContentSize().width, w2 = recv->getScaledContentSize().width;
    float gap = 10.f, x = (W - (w1 + w2 + gap)) / 2;
    send->setPosition({x + w1 / 2, 30});
    recv->setPosition({x + w1 + gap + w2 / 2, 30});

    auto* smaller = makeBtn(menu, this, menu_selector(CollabPanel::onSmaller), "-", "GJ_button_01.png", 0.4f);
    auto* bigger  = makeBtn(menu, this, menu_selector(CollabPanel::onBigger),  "+", "GJ_button_01.png", 0.4f);
    smaller->setPosition({W - 40, H - 18});
    bigger->setPosition({W - 16, H - 18});

    scheduleUpdate();
    refreshUI();
    return true;
}

bool CollabPanel::ccTouchBegan(CCTouch* touch, CCEvent*) {
    auto local = this->convertToNodeSpace(touch->getLocation());
    m_dragging = CCRect(0, 0, kWidth, kHeight).containsPoint(local);
    return m_dragging;
}

void CollabPanel::ccTouchMoved(CCTouch* touch, CCEvent*) {
    if (!m_dragging || !getParent()) return;
    auto now = getParent()->convertToNodeSpace(touch->getLocation());
    auto prev = getParent()->convertToNodeSpace(touch->getPreviousLocation());
    this->setPosition(getPosition() + (now - prev));
}

void CollabPanel::ccTouchEnded(CCTouch*, CCEvent*) {
    if (!m_dragging) return;
    m_dragging = false;
    auto pos = getPosition();
    Mod::get()->setSavedValue<float>("panel-x", pos.x);
    Mod::get()->setSavedValue<float>("panel-y", pos.y);
}

void CollabPanel::ccTouchCancelled(CCTouch* touch, CCEvent* event) { ccTouchEnded(touch, event); }

void CollabPanel::applyScale(float scale) {
    scale = std::clamp(scale, 0.5f, 1.6f);
    this->setScale(scale);
    Mod::get()->setSavedValue<float>("panel-scale", scale);
}
void CollabPanel::onBigger(CCObject*) { applyScale(getScale() + 0.1f); }
void CollabPanel::onSmaller(CCObject*) { applyScale(getScale() - 0.1f); }

void CollabPanel::update(float dt) {
    m_refreshTimer += dt;
    if (m_refreshTimer >= 0.5f) {
        m_refreshTimer = 0.f;
        refreshUI();
    }
}

void CollabPanel::refreshUI() {
    auto* mgr = CollabManager::get();
    auto* lel = LevelEditorLayer::get();
    std::string name = (lel && lel->m_level) ? std::string(lel->m_level->m_levelName) : "";

    m_levelLabel->setString(name.empty() ? "No level open" : ("Editing: " + name).c_str());

    if (name.empty()) {
        m_publishLabel->setString("");
    } else if (mgr->canPublishLevel(name)) {
        m_publishLabel->setString("You can publish this level.");
        m_publishLabel->setColor({100, 255, 100});
    } else {
        m_publishLabel->setString("You cannot publish this level.\nIt belongs to another player.");
        m_publishLabel->setColor({255, 80, 80});
    }
    m_infoLabel->setString(mgr->lastInfo.c_str());
}

void CollabPanel::onSend(CCObject*) { CollabManager::get()->sendToClipboard(); }
void CollabPanel::onReceive(CCObject*) { CollabManager::get()->receiveFromClipboard(); }

// ================================================================
// CollabButton (floating toolbar button)
// ================================================================

CollabButton* CollabButton::create() {
    auto ret = new CollabButton();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

bool CollabButton::init() {
    if (!CCNode::init()) return false;

    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    addChild(menu);

    CCSprite* sprite = CCSprite::create("collab_icon.png"_spr);
    if (!sprite) sprite = CCSprite::createWithSpriteFrameName("GJ_editBtn_001.png");
    if (sprite) sprite->setScale(30.f / std::max(sprite->getContentSize().height, 1.f));

    auto* btn = CCMenuItemSpriteExtra::create(sprite, this, menu_selector(CollabButton::onTogglePanel));
    menu->addChild(btn);
    return true;
}

void CollabButton::onTogglePanel(CCObject*) {
    m_panelOpen = !m_panelOpen;

    if (m_panelOpen) {
        m_panel = CollabPanel::create();

        auto winSize = CCDirector::sharedDirector()->getWinSize();
        float scale = Mod::get()->getSavedValue<float>("panel-scale", 0.9f);
        m_panel->setScale(scale);

        float defX = winSize.width - CollabPanel::kWidth * scale - 10.f;
        float defY = winSize.height - CollabPanel::kHeight * scale - 50.f;
        m_panel->setPosition({Mod::get()->getSavedValue<float>("panel-x", defX),
                              Mod::get()->getSavedValue<float>("panel-y", defY)});

        getParent()->addChild(m_panel, 100);
    } else if (m_panel) {
        m_panel->removeFromParent();
        m_panel = nullptr;
    }
}
