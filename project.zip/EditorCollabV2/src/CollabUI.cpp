#include "CollabUI.hpp"
#include <algorithm>
#include <Geode/ui/Notification.hpp>

// ================================================================
// CollabPanel
// ================================================================

CollabPanel* CollabPanel::create() {
    auto ret = new CollabPanel();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

namespace {
    CCMenuItemSpriteExtra* makeBtn(CCMenu* menu, CCObject* target, SEL_MenuHandler cb,
                                   char const* text, char const* tex, CCPoint pos, float scale = 0.5f) {
        auto* spr = ButtonSprite::create(text, "bigFont.fnt", tex, scale);
        auto* btn = CCMenuItemSpriteExtra::create(spr, target, cb);
        btn->setPosition(pos);
        menu->addChild(btn);
        return btn;
    }
}

CollabPanel::~CollabPanel() {
    // The callbacks capture `this`, so remove them when the panel goes away
    auto* mgr = CollabManager::get();
    mgr->onFriendJoined = nullptr;
    mgr->onFriendLeft = nullptr;
    mgr->onEditReceived = nullptr;
    mgr->onSessionCreated = nullptr;
}

bool CollabPanel::init() {
    if (!CCLayer::init()) return false;

    auto* mgr = CollabManager::get();
    constexpr float W = kWidth;
    constexpr float H = kHeight;

    this->setContentSize({W, H});

    // Touches: sit just behind the menu buttons so buttons still work,
    // but anything else on the panel drags it.
    this->setTouchMode(kCCTouchesOneByOne);
    this->setTouchPriority(-127);
    this->setTouchEnabled(true);

    // Background
    auto bg = CCScale9Sprite::create("GJ_square01.png");
    bg->setContentSize({W, H});
    bg->setPosition({W / 2, H / 2});
    bg->setOpacity(235);
    addChild(bg);

    // Title
    auto* title = CCLabelBMFont::create("Editor Collab v2", "bigFont.fnt");
    title->setScale(0.42f);
    title->setPosition({W / 2 - 22, H - 18});
    title->setColor({255, 220, 80});
    addChild(title);

    // Status / session / owner
    m_statusLabel = CCLabelBMFont::create("Not Connected", "chatFont.fnt");
    m_statusLabel->setScale(0.5f);
    m_statusLabel->setPosition({W / 2, H - 40});
    addChild(m_statusLabel);

    m_sessionIdLabel = CCLabelBMFont::create("Session: --", "chatFont.fnt");
    m_sessionIdLabel->setScale(0.42f);
    m_sessionIdLabel->setPosition({W / 2, H - 56});
    m_sessionIdLabel->setColor({200, 200, 200});
    addChild(m_sessionIdLabel);

    m_ownerLabel = CCLabelBMFont::create("Owner: --", "chatFont.fnt");
    m_ownerLabel->setScale(0.42f);
    m_ownerLabel->setPosition({W / 2, H - 70});
    addChild(m_ownerLabel);

    // Collaborators
    auto* collabTitle = CCLabelBMFont::create("Collaborators:", "chatFont.fnt");
    collabTitle->setScale(0.42f);
    collabTitle->setAnchorPoint({0, 0.5f});
    collabTitle->setPosition({14, H - 88});
    collabTitle->setColor({180, 230, 255});
    addChild(collabTitle);

    m_collaboratorList = CCNode::create();
    m_collaboratorList->setPosition({20, H - 102});
    addChild(m_collaboratorList);

    // Publish status
    m_publishStatusLabel = CCLabelBMFont::create("", "chatFont.fnt");
    m_publishStatusLabel->setScale(0.38f);
    m_publishStatusLabel->setPosition({W / 2, 78});
    m_publishStatusLabel->setColor({255, 100, 100});
    m_publishStatusLabel->setWidth(230);
    addChild(m_publishStatusLabel);

    // Buttons
    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    addChild(menu);

    m_createBtn = makeBtn(menu, this, menu_selector(CollabPanel::onCreateSession),
                          "Create", "GJ_button_01.png", {48, 52});
    m_joinBtn = makeBtn(menu, this, menu_selector(CollabPanel::onJoinSession),
                        "Join", "GJ_button_02.png", {125, 52});
    m_shareBtn = makeBtn(menu, this, menu_selector(CollabPanel::onShareLevel),
                         "Share", "GJ_button_03.png", {202, 52});
    m_syncBtn = makeBtn(menu, this, menu_selector(CollabPanel::onManualSync),
                        "Sync", "GJ_button_04.png", {86, 22});
    m_leaveBtn = makeBtn(menu, this, menu_selector(CollabPanel::onLeaveSession),
                         "Leave", "GJ_button_06.png", {164, 22});

    // Resize buttons (top right)
    makeBtn(menu, this, menu_selector(CollabPanel::onSmaller),
            "-", "GJ_button_01.png", {W - 38, H - 18}, 0.45f);
    makeBtn(menu, this, menu_selector(CollabPanel::onBigger),
            "+", "GJ_button_01.png", {W - 15, H - 18}, 0.45f);

    // Setup callbacks
    mgr->onFriendJoined = [this](std::string name) {
        Notification::create(name + " joined the session!", NotificationIcon::Success)->show();
        updateCollaboratorList();
    };

    mgr->onFriendLeft = [this](std::string name) {
        Notification::create(name + " left the session.", NotificationIcon::Warning)->show();
        updateCollaboratorList();
    };

    mgr->onEditReceived = [this](PendingEdit) {
        updateCollaboratorList();
    };

    mgr->onSessionCreated = [this](std::string) {
        refreshUI();
    };

    mgr->onError = [](std::string error) {
        FLAlertLayer::create("Collab Error", error, "OK")->show();
    };

    scheduleUpdate();
    refreshUI();
    return true;
}

// ---- Dragging ------------------------------------------------

bool CollabPanel::ccTouchBegan(CCTouch* touch, CCEvent*) {
    auto local = this->convertToNodeSpace(touch->getLocation());
    m_dragging = CCRect(0, 0, kWidth, kHeight).containsPoint(local);
    return m_dragging; // swallow touches on the panel so the editor ignores them
}

void CollabPanel::ccTouchMoved(CCTouch* touch, CCEvent*) {
    if (!m_dragging || !getParent()) return;
    auto now = getParent()->convertToNodeSpace(touch->getLocation());
    auto prev = getParent()->convertToNodeSpace(touch->getPreviousLocation());
    this->setPosition(getPosition() + (now - prev));
}

void CollabPanel::ccTouchEnded(CCTouch*, CCEvent*) {
    if (!m_dragging) return;
    m_dragging = false;
    auto pos = getPosition();
    Mod::get()->setSavedValue<float>("panel-x", pos.x);
    Mod::get()->setSavedValue<float>("panel-y", pos.y);
}

void CollabPanel::ccTouchCancelled(CCTouch* touch, CCEvent* event) {
    ccTouchEnded(touch, event);
}

// ---- Resizing ------------------------------------------------

void CollabPanel::applyScale(float scale) {
    scale = std::clamp(scale, 0.5f, 1.6f);
    this->setScale(scale);
    Mod::get()->setSavedValue<float>("panel-scale", scale);
}

void CollabPanel::onBigger(CCObject*) { applyScale(getScale() + 0.1f); }
void CollabPanel::onSmaller(CCObject*) { applyScale(getScale() - 0.1f); }

void CollabPanel::update(float dt) {
    auto* mgr = CollabManager::get();

    // Auto sync
    if (Mod::get()->getSettingValue<bool>("auto-sync") && mgr->isInSession() && mgr->isOwner()) {
        m_autoSyncTimer += dt;
        if (m_autoSyncTimer >= m_autoSyncInterval) {
            m_autoSyncTimer = 0.f;
            onManualSync(nullptr);
        }
    }

    // Apply pending edits from collaborators
    mgr->applyPendingEdits();

    // Keep publish status updated
    updatePublishStatus();
}

void CollabPanel::refreshUI() {
    auto* mgr = CollabManager::get();

    if (!mgr->isConnected()) {
        m_statusLabel->setString("Not Connected");
        m_statusLabel->setColor({255, 100, 100});
        m_sessionIdLabel->setString("Session: --");
        m_ownerLabel->setString("Owner: --");
        return;
    }

    if (!mgr->isInSession()) {
        m_statusLabel->setString("Connected - No Session");
        m_statusLabel->setColor({200, 200, 100});
        m_sessionIdLabel->setString("Session: --");
        m_ownerLabel->setString("Owner: --");
        return;
    }

    auto& session = mgr->getSession();

    m_statusLabel->setString(("In Session - " + session.levelName).c_str());
    m_statusLabel->setColor({100, 255, 100});
    m_sessionIdLabel->setString(("ID: " + session.sessionId).c_str());
    m_ownerLabel->setString(("Owner: " + session.ownerName).c_str());

    if (mgr->isOwner()) {
        m_ownerLabel->setColor({255, 220, 80});
    } else {
        m_ownerLabel->setColor({180, 180, 180});
    }

    updateCollaboratorList();
    updatePublishStatus();
}

void CollabPanel::updateCollaboratorList() {
    m_collaboratorList->removeAllChildren();

    auto& session = CollabManager::get()->getSession();
    float y = 0;
    int shown = 0;

    for (auto& name : session.collaborators) {
        if (shown >= 3) {
            auto* more = CCLabelBMFont::create(
                ("+" + std::to_string(session.collaborators.size() - shown) + " more").c_str(),
                "chatFont.fnt");
            more->setScale(0.36f);
            more->setAnchorPoint({0, 0.5f});
            more->setPosition({0, y});
            more->setColor({150, 150, 150});
            m_collaboratorList->addChild(more);
            break;
        }
        auto* label = CCLabelBMFont::create(("- " + name).c_str(), "chatFont.fnt");
        label->setScale(0.4f);
        label->setAnchorPoint({0, 0.5f});
        label->setPosition({0, y});
        label->setColor({180, 230, 255});
        m_collaboratorList->addChild(label);
        y -= 12.f;
        shown++;
    }

    if (session.collaborators.empty()) {
        auto* label = CCLabelBMFont::create("No collaborators yet", "chatFont.fnt");
        label->setScale(0.36f);
        label->setAnchorPoint({0, 0.5f});
        label->setColor({150, 150, 150});
        m_collaboratorList->addChild(label);
    }
}

void CollabPanel::updatePublishStatus() {
    auto* mgr = CollabManager::get();

    if (!mgr->isInSession()) {
        m_publishStatusLabel->setString("");
        return;
    }

    if (!mgr->canPublishLevel()) {
        m_publishStatusLabel->setString(
            "You cannot publish this level.\nIt belongs to another player.");
        m_publishStatusLabel->setColor({255, 80, 80});
    } else {
        m_publishStatusLabel->setString("You can publish this level.");
        m_publishStatusLabel->setColor({100, 255, 100});
    }
}

void CollabPanel::onCreateSession(CCObject*) {
    auto* mgr = CollabManager::get();

    if (mgr->isInSession()) {
        FLAlertLayer::create(
            "Already in Session",
            "You are already in a session. Leave first.",
            "OK")->show();
        return;
    }

    // Get current level data from editor
    auto* editor = LevelEditorLayer::get();
    if (!editor) {
        FLAlertLayer::create("No Level", "Open a level in the editor first.", "OK")->show();
        return;
    }

    std::string levelName = editor->m_level->m_levelName;
    std::string levelData = editor->m_level->m_levelString;

    if (mgr->createSession(levelData, levelName)) {
        auto& session = mgr->getSession();
        FLAlertLayer::create(
            "Session Created!",
            ("Session ID: " + session.sessionId +
             "\n\nShare this ID with your friend so they can join!").c_str(),
            "OK")->show();
        refreshUI();
    }
}

void CollabPanel::onJoinSession(CCObject*) {
    auto* popup = JoinSessionPopup::create();
    popup->show();
}

void CollabPanel::onShareLevel(CCObject*) {
    auto* mgr = CollabManager::get();

    if (!mgr->isInSession()) {
        FLAlertLayer::create(
            "No Session",
            "Create a session first before sharing.",
            "OK")->show();
        return;
    }

    if (!mgr->isOwner()) {
        FLAlertLayer::create(
            "Cannot Share",
            "You can only share levels you own.\n"
            "You cannot reshare a level that was shared to you.",
            "OK")->show();
        return;
    }

    auto* popup = ShareLevelPopup::create();
    popup->show();
}

void CollabPanel::onLeaveSession(CCObject*) {
    geode::createQuickPopup(
        "Leave Session",
        "Are you sure you want to leave the collab session?",
        "No", "Yes",
        [this](FLAlertLayer*, bool confirm) {
            if (confirm) {
                CollabManager::get()->leaveSession();
                refreshUI();
            }
        }
    );
}

void CollabPanel::onManualSync(CCObject*) {
    auto* editor = LevelEditorLayer::get();
    if (!editor) return;

    std::string levelData = editor->m_level->m_levelString;
    CollabManager::get()->syncLevelData(levelData);

    Notification::create("Level synced with collaborators", NotificationIcon::Success)->show();
}

// ================================================================
// CollabButton (floating toolbar button)
// ================================================================

CollabButton* CollabButton::create() {
    auto ret = new CollabButton();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

bool CollabButton::init() {
    if (!CCNode::init()) return false;

    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    addChild(menu);

    // Use the mod's own icon, scaled down to a small button
    CCSprite* sprite = CCSprite::create("collab_icon.png"_spr);
    if (!sprite) sprite = CCSprite::createWithSpriteFrameName("GJ_editBtn_001.png");
    if (sprite) {
        float target = 30.f;
        sprite->setScale(target / std::max(sprite->getContentSize().height, 1.f));
    }

    m_btn = CCMenuItemSpriteExtra::create(
        sprite, this, menu_selector(CollabButton::onTogglePanel));
    menu->addChild(m_btn);

    return true;
}

void CollabButton::onTogglePanel(CCObject*) {
    m_panelOpen = !m_panelOpen;

    if (m_panelOpen) {
        m_panel = CollabPanel::create();

        auto winSize = CCDirector::sharedDirector()->getWinSize();
        float scale = Mod::get()->getSavedValue<float>("panel-scale", 0.9f);
        m_panel->setScale(scale);

        float defX = winSize.width - CollabPanel::kWidth * scale - 10.f;
        float defY = winSize.height - CollabPanel::kHeight * scale - 50.f;
        float x = Mod::get()->getSavedValue<float>("panel-x", defX);
        float y = Mod::get()->getSavedValue<float>("panel-y", defY);
        m_panel->setPosition({x, y});

        getParent()->addChild(m_panel, 100);
    } else {
        if (m_panel) {
            m_panel->removeFromParent();
            m_panel = nullptr;
        }
    }
}

// ================================================================
// ShareLevelPopup
// ================================================================

ShareLevelPopup* ShareLevelPopup::create() {
    auto ret = new ShareLevelPopup();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

bool ShareLevelPopup::init() {
    if (!Popup::init(380, 280)) return false;
    setTitle("Share Level With Friend");

    auto* subLabel = CCLabelBMFont::create(
        "Choose a friend to share your level with.\n"
        "They will be able to edit and decorate it.",
        "chatFont.fnt");
    subLabel->setScale(0.45f);
    subLabel->setPosition({m_size.width / 2, m_size.height - 75});
    subLabel->setAlignment(kCCTextAlignmentCenter);
    m_mainLayer->addChild(subLabel);

    auto* ruleLabel = CCLabelBMFont::create(
        "Rule: They CANNOT publish your level.", "chatFont.fnt");
    ruleLabel->setScale(0.42f);
    ruleLabel->setColor({255, 100, 100});
    ruleLabel->setPosition({m_size.width / 2, m_size.height - 100});
    m_mainLayer->addChild(ruleLabel);

    buildFriendsList();
    return true;
}

void ShareLevelPopup::buildFriendsList() {
    auto* mgr = CollabManager::get();
    mgr->fetchFriends();

    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    m_mainLayer->addChild(menu);

    float startY = m_size.height - 135;

    if (mgr->m_friends.empty()) {
        auto* noFriends = CCLabelBMFont::create(
            "No friends found.\nAdd friends in GD first!",
            "chatFont.fnt");
        noFriends->setScale(0.5f);
        noFriends->setPosition({m_size.width / 2, startY - 20});
        noFriends->setColor({180, 180, 180});
        m_mainLayer->addChild(noFriends);
        return;
    }

    for (int i = 0; i < (int)mgr->m_friends.size() && i < 5; i++) {
        auto& [name, accountId] = mgr->m_friends[i];

        auto* row = ButtonSprite::create(
            ("Share with " + name).c_str(), "bigFont.fnt", "GJ_button_01.png", 0.65f);
        auto* btn = CCMenuItemSpriteExtra::create(
            row, this, menu_selector(ShareLevelPopup::onShareToFriend));
        btn->setPosition({m_size.width / 2, startY - (i * 38.f)});
        btn->setTag(i);
        menu->addChild(btn);
    }
}

void ShareLevelPopup::onShareToFriend(CCObject* sender) {
    auto* btn = static_cast<CCMenuItemSpriteExtra*>(sender);
    int idx = btn->getTag();
    auto& mgr = *CollabManager::get();

    if (idx < (int)mgr.m_friends.size()) {
        auto& [name, accountId] = mgr.m_friends[idx];

        auto* editor = LevelEditorLayer::get();
        if (!editor) return;

        std::string levelData = editor->m_level->m_levelString;
        mgr.shareLevel(accountId, levelData);

        FLAlertLayer::create(
            "Level Shared!",
            ("Your level has been shared with " + name + "!\n\n"
             "They can edit and decorate it.\n"
             "They cannot publish it.").c_str(),
            "OK")->show();

        onClose(nullptr);
    }
}

// ================================================================
// JoinSessionPopup
// ================================================================

JoinSessionPopup* JoinSessionPopup::create() {
    auto ret = new JoinSessionPopup();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

bool JoinSessionPopup::init() {
    if (!Popup::init(320, 200)) return false;
    setTitle("Join Collab Session");

    auto* label = CCLabelBMFont::create(
        "Enter the Session ID your friend shared:", "chatFont.fnt");
    label->setScale(0.45f);
    label->setPosition({m_size.width / 2, 145});
    m_mainLayer->addChild(label);

    m_sessionInput = geode::TextInput::create(240, "Session ID...", "bigFont.fnt");
    m_sessionInput->setPosition({m_size.width / 2, 110});
    m_mainLayer->addChild(m_sessionInput);

    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    m_mainLayer->addChild(menu);

    auto* joinSprite = ButtonSprite::create(
        "Join", "bigFont.fnt", "GJ_button_01.png", 0.8f);
    auto* joinBtn = CCMenuItemSpriteExtra::create(
        joinSprite, this, menu_selector(JoinSessionPopup::onJoin));
    joinBtn->setPosition({m_size.width / 2, 65});
    menu->addChild(joinBtn);

    return true;
}

void JoinSessionPopup::onJoin(CCObject*) {
    std::string sessionId = m_sessionInput->getString();

    if (sessionId.empty()) {
        FLAlertLayer::create("Error", "Please enter a session ID.", "OK")->show();
        return;
    }

    auto* mgr = CollabManager::get();
    if (mgr->joinSession(sessionId)) {
        FLAlertLayer::create(
            "Joined!",
            ("You joined session " + sessionId + "!\n\n"
             "You can now edit the shared level.\n"
             "Remember: You cannot publish this level.").c_str(),
            "OK")->show();
        onClose(nullptr);
    } else {
        FLAlertLayer::create("Error", "Could not join session. Check the ID and try again.", "OK")->show();
    }
}