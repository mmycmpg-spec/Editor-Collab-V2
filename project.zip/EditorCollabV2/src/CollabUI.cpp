#include "CollabUI.hpp"
#include <Geode/ui/Notification.hpp>
#include <algorithm>

namespace {
    CCMenuItemSpriteExtra* makeBtn(CCMenu* menu, CCObject* target, SEL_MenuHandler cb,
                                   char const* text, char const* tex, CCPoint pos, float scale = 0.5f) {
        auto* spr = ButtonSprite::create(text, "bigFont.fnt", tex, scale);
        auto* btn = CCMenuItemSpriteExtra::create(spr, target, cb);
        btn->setPosition(pos);
        menu->addChild(btn);
        return btn;
    }
}

// ================================================================
// CollabPanel
// ================================================================

CollabPanel* CollabPanel::create() {
    auto ret = new CollabPanel();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

CollabPanel::~CollabPanel() {
    CollabManager::get()->onStateChanged = nullptr;
}

bool CollabPanel::init() {
    if (!CCLayer::init()) return false;

    constexpr float W = kWidth;
    constexpr float H = kHeight;

    this->setContentSize({W, H});

    // Touches sit just behind the menu buttons, so buttons still work
    // and any other touch on the panel drags it.
    this->setTouchMode(kCCTouchesOneByOne);
    this->setTouchPriority(-127);
    this->setTouchEnabled(true);

    auto bg = CCScale9Sprite::create("GJ_square01.png");
    bg->setContentSize({W, H});
    bg->setPosition({W / 2, H / 2});
    bg->setOpacity(235);
    addChild(bg);

    auto* title = CCLabelBMFont::create("Editor Collab v2", "bigFont.fnt");
    title->setScale(0.42f);
    title->setPosition({W / 2 - 22, H - 18});
    title->setColor({255, 220, 80});
    addChild(title);

    m_statusLabel = CCLabelBMFont::create("Not in a session", "chatFont.fnt");
    m_statusLabel->setScale(0.5f);
    m_statusLabel->setPosition({W / 2, H - 40});
    addChild(m_statusLabel);

    m_codeLabel = CCLabelBMFont::create("Code: ----", "bigFont.fnt");
    m_codeLabel->setScale(0.5f);
    m_codeLabel->setPosition({W / 2, H - 60});
    addChild(m_codeLabel);

    m_ownerLabel = CCLabelBMFont::create("Owner: --", "chatFont.fnt");
    m_ownerLabel->setScale(0.42f);
    m_ownerLabel->setPosition({W / 2, H - 78});
    addChild(m_ownerLabel);

    auto* collabTitle = CCLabelBMFont::create("Collaborators:", "chatFont.fnt");
    collabTitle->setScale(0.42f);
    collabTitle->setAnchorPoint({0, 0.5f});
    collabTitle->setPosition({14, H - 95});
    collabTitle->setColor({180, 230, 255});
    addChild(collabTitle);

    m_collaboratorList = CCNode::create();
    m_collaboratorList->setPosition({20, H - 108});
    addChild(m_collaboratorList);

    m_publishStatusLabel = CCLabelBMFont::create("", "chatFont.fnt");
    m_publishStatusLabel->setScale(0.38f);
    m_publishStatusLabel->setPosition({W / 2, 74});
    m_publishStatusLabel->setColor({255, 100, 100});
    m_publishStatusLabel->setWidth(230);
    addChild(m_publishStatusLabel);

    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    addChild(menu);

    makeBtn(menu, this, menu_selector(CollabPanel::onCreateSession),
            "Create", "GJ_button_01.png", {48, 48});
    makeBtn(menu, this, menu_selector(CollabPanel::onJoinSession),
            "Join", "GJ_button_02.png", {125, 48});
    makeBtn(menu, this, menu_selector(CollabPanel::onCopyCode),
            "Copy", "GJ_button_03.png", {202, 48});
    makeBtn(menu, this, menu_selector(CollabPanel::onLeaveSession),
            "Leave", "GJ_button_06.png", {125, 18});

    makeBtn(menu, this, menu_selector(CollabPanel::onSmaller),
            "-", "GJ_button_01.png", {W - 38, H - 18}, 0.45f);
    makeBtn(menu, this, menu_selector(CollabPanel::onBigger),
            "+", "GJ_button_01.png", {W - 15, H - 18}, 0.45f);

    CollabManager::get()->onStateChanged = [this] { refreshUI(); };

    refreshUI();
    return true;
}

// ---- Dragging ------------------------------------------------

bool CollabPanel::ccTouchBegan(CCTouch* touch, CCEvent*) {
    auto local = this->convertToNodeSpace(touch->getLocation());
    m_dragging = CCRect(0, 0, kWidth, kHeight).containsPoint(local);
    return m_dragging;
}

void CollabPanel::ccTouchMoved(CCTouch* touch, CCEvent*) {
    if (!m_dragging || !getParent()) return;
    auto now = getParent()->convertToNodeSpace(touch->getLocation());
    auto prev = getParent()->convertToNodeSpace(touch->getPreviousLocation());
    this->setPosition(getPosition() + (now - prev));
}

void CollabPanel::ccTouchEnded(CCTouch*, CCEvent*) {
    if (!m_dragging) return;
    m_dragging = false;
    auto pos = getPosition();
    Mod::get()->setSavedValue<float>("panel-x", pos.x);
    Mod::get()->setSavedValue<float>("panel-y", pos.y);
}

void CollabPanel::ccTouchCancelled(CCTouch* touch, CCEvent* event) {
    ccTouchEnded(touch, event);
}

// ---- Resizing ------------------------------------------------

void CollabPanel::applyScale(float scale) {
    scale = std::clamp(scale, 0.5f, 1.6f);
    this->setScale(scale);
    Mod::get()->setSavedValue<float>("panel-scale", scale);
}

void CollabPanel::onBigger(CCObject*) { applyScale(getScale() + 0.1f); }
void CollabPanel::onSmaller(CCObject*) { applyScale(getScale() - 0.1f); }

// ---- Content -------------------------------------------------

void CollabPanel::refreshUI() {
    auto* mgr = CollabManager::get();

    if (!mgr->isInSession()) {
        m_statusLabel->setString("Not in a session");
        m_statusLabel->setColor({255, 255, 255});
        m_codeLabel->setString("Code: ----");
        m_codeLabel->setColor({150, 150, 150});
        m_ownerLabel->setString("Owner: --");
        m_publishStatusLabel->setString("");
        updateCollaboratorList();
        return;
    }

    auto const& session = mgr->getSession();
    m_statusLabel->setString(mgr->isOwner() ? "You are hosting" : "You joined a session");
    m_statusLabel->setColor({100, 255, 100});
    m_codeLabel->setString(("Code: " + session.code).c_str());
    m_codeLabel->setColor({255, 220, 80});
    m_ownerLabel->setString(("Owner: " + session.ownerName).c_str());

    if (mgr->isOwner()) {
        m_publishStatusLabel->setString("You can publish this level.");
        m_publishStatusLabel->setColor({100, 255, 100});
    } else {
        m_publishStatusLabel->setString("You cannot publish this level.\nIt belongs to the owner.");
        m_publishStatusLabel->setColor({255, 80, 80});
    }
    updateCollaboratorList();
}

void CollabPanel::updateCollaboratorList() {
    m_collaboratorList->removeAllChildren();

    auto const& session = CollabManager::get()->getSession();
    float y = 0;
    int shown = 0;

    for (auto& name : session.collaborators) {
        if (shown >= 3) {
            auto* more = CCLabelBMFont::create(
                ("+" + std::to_string(session.collaborators.size() - shown) + " more").c_str(),
                "chatFont.fnt");
            more->setScale(0.36f);
            more->setAnchorPoint({0, 0.5f});
            more->setPosition({0, y});
            more->setColor({150, 150, 150});
            m_collaboratorList->addChild(more);
            break;
        }
        auto* label = CCLabelBMFont::create(("- " + name).c_str(), "chatFont.fnt");
        label->setScale(0.4f);
        label->setAnchorPoint({0, 0.5f});
        label->setPosition({0, y});
        label->setColor({180, 230, 255});
        m_collaboratorList->addChild(label);
        y -= 12.f;
        shown++;
    }

    if (session.collaborators.empty()) {
        auto* label = CCLabelBMFont::create("Nobody else yet", "chatFont.fnt");
        label->setScale(0.36f);
        label->setAnchorPoint({0, 0.5f});
        label->setColor({150, 150, 150});
        m_collaboratorList->addChild(label);
    }
}

void CollabPanel::onCreateSession(CCObject*) {
    auto* editor = LevelEditorLayer::get();
    if (!editor) {
        FLAlertLayer::create("No Level", "Open a level in the editor first, then press Create.", "OK")->show();
        return;
    }

    CollabManager::get()->createSession(editor, [](bool ok, std::string message) {
        if (!ok) {
            FLAlertLayer::create("Could not create session", message, "OK")->show();
            return;
        }
        FLAlertLayer::create(
            "Session created!",
            "Your session code is:\n\n<cy>" + message + "</c>\n\n"
            "Friends must be on <cy>your hotspot</c> (or the same Wi-Fi), "
            "press <cg>Join</c> and type the code.\n"
            "They will be sent straight into this level.\n"
            "Keep Geometry Dash open while you collab.",
            "OK")->show();
    });
}

void CollabPanel::onJoinSession(CCObject*) {
    JoinSessionPopup::create()->show();
}

void CollabPanel::onCopyCode(CCObject*) {
    auto* mgr = CollabManager::get();
    if (!mgr->isInSession()) {
        Notification::create("Not in a session", NotificationIcon::Warning)->show();
        return;
    }
    geode::utils::clipboard::write(mgr->getSession().code);
    Notification::create("Code copied", NotificationIcon::Success)->show();
}

void CollabPanel::onLeaveSession(CCObject*) {
    if (!CollabManager::get()->isInSession()) {
        Notification::create("Not in a session", NotificationIcon::Warning)->show();
        return;
    }
    geode::createQuickPopup(
        "Leave Session",
        "Are you sure you want to leave the collab session?",
        "No", "Yes",
        [](FLAlertLayer*, bool confirm) {
            if (confirm) CollabManager::get()->leaveSession();
        }
    );
}

// ================================================================
// CollabButton
// ================================================================

CollabButton* CollabButton::create() {
    auto ret = new CollabButton();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

bool CollabButton::init() {
    if (!CCNode::init()) return false;

    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    addChild(menu);

    CCSprite* sprite = CCSprite::create("collab_icon.png"_spr);
    if (!sprite) sprite = CCSprite::createWithSpriteFrameName("GJ_editBtn_001.png");
    if (sprite) {
        float target = 30.f;
        sprite->setScale(target / std::max(sprite->getContentSize().height, 1.f));
    }

    m_btn = CCMenuItemSpriteExtra::create(
        sprite, this, menu_selector(CollabButton::onTogglePanel));
    menu->addChild(m_btn);

    return true;
}

void CollabButton::onTogglePanel(CCObject*) {
    m_panelOpen = !m_panelOpen;

    if (m_panelOpen) {
        m_panel = CollabPanel::create();

        auto winSize = CCDirector::sharedDirector()->getWinSize();
        float scale = Mod::get()->getSavedValue<float>("panel-scale", 0.9f);
        m_panel->setScale(scale);

        float defX = winSize.width - CollabPanel::kWidth * scale - 10.f;
        float defY = winSize.height - CollabPanel::kHeight * scale - 50.f;
        float x = Mod::get()->getSavedValue<float>("panel-x", defX);
        float y = Mod::get()->getSavedValue<float>("panel-y", defY);
        m_panel->setPosition({x, y});

        getParent()->addChild(m_panel, 100);
    } else {
        if (m_panel) {
            m_panel->removeFromParent();
            m_panel = nullptr;
        }
    }
}

// ================================================================
// JoinSessionPopup
// ================================================================

JoinSessionPopup* JoinSessionPopup::create() {
    auto ret = new JoinSessionPopup();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

bool JoinSessionPopup::init() {
    if (!Popup::init(300, 190)) return false;
    setTitle("Join Collab Session");

    auto* label = CCLabelBMFont::create(
        "Type the 4 digit code your friend gave you:", "chatFont.fnt");
    label->setScale(0.5f);
    label->setPosition({m_size.width / 2, m_size.height - 55});
    m_mainLayer->addChild(label);

    m_codeInput = geode::TextInput::create(140, "Code", "bigFont.fnt");
    m_codeInput->setCommonFilter(geode::CommonFilter::Uint);
    m_codeInput->setMaxCharCount(4);
    m_codeInput->setPosition({m_size.width / 2, m_size.height - 90});
    m_mainLayer->addChild(m_codeInput);

    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    m_mainLayer->addChild(menu);

    auto* joinSprite = ButtonSprite::create("Join", "goldFont.fnt", "GJ_button_01.png", 0.8f);
    auto* joinBtn = CCMenuItemSpriteExtra::create(
        joinSprite, this, menu_selector(JoinSessionPopup::onJoin));
    joinBtn->setPosition({m_size.width / 2, 35});
    menu->addChild(joinBtn);

    return true;
}

void JoinSessionPopup::onJoin(CCObject*) {
    std::string code = m_codeInput->getString();

    if (code.size() != 4) {
        FLAlertLayer::create("Error", "Please type the 4 digit code.", "OK")->show();
        return;
    }

    // Joining replaces the current editor, so ask first if one is open
    if (LevelEditorLayer::get()) {
        geode::createQuickPopup(
            "Leave the editor?",
            "Joining opens the shared level and <cr>closes this editor</c>.\n"
            "Save your level first - unsaved work will be lost.",
            "Cancel", "Join",
            [this, code](FLAlertLayer*, bool confirm) {
                if (confirm) doJoin(code);
            }
        );
        return;
    }
    doJoin(code);
}

void JoinSessionPopup::doJoin(std::string const& code) {
    CollabManager::get()->joinSession(code, [](bool ok, std::string message) {
        if (!ok) {
            FLAlertLayer::create("Could not join", message, "OK")->show();
        }
        // On success the manager opens the level for us
    });
    onClose(nullptr);
}
