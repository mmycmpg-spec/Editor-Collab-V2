#include "CollabUI.hpp"
#include <algorithm>

CollabPanel* CollabPanel::create() {
    auto ret = new CollabPanel();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

namespace {
    CCMenuItemSpriteExtra* makeBtn(CCMenu* menu, CCObject* target, SEL_MenuHandler cb,
                                   char const* text, char const* tex, float scale = 0.5f) {
        auto* spr = ButtonSprite::create(text, "bigFont.fnt", tex, scale);
        auto* btn = CCMenuItemSpriteExtra::create(spr, target, cb);
        menu->addChild(btn);
        return btn;
    }

    // Centers a row of buttons using their real widths (shrinks them if the row is too wide),
    // so buttons can never overlap.
    void layoutRow(std::vector<CCMenuItemSpriteExtra*> const& btns, float y, float totalWidth) {
        constexpr float gap = 6.f;
        float used = gap * (btns.size() - 1);
        for (auto* b : btns) used += b->getScaledContentSize().width;
        float avail = totalWidth - 16.f;
        if (used > avail) {
            float k = avail / used;
            for (auto* b : btns) b->setScale(b->getScale() * k);
            used = gap * (btns.size() - 1);
            for (auto* b : btns) used += b->getScaledContentSize().width;
        }
        float x = (totalWidth - used) / 2;
        for (auto* b : btns) {
            float w = b->getScaledContentSize().width;
            b->setPosition({x + w / 2, y});
            x += w + gap;
        }
    }

    CCLabelBMFont* makeLabel(CCNode* parent, char const* text, float scale, CCPoint pos, ccColor3B color) {
        auto* l = CCLabelBMFont::create(text, "chatFont.fnt");
        l->setScale(scale);
        l->setPosition(pos);
        l->setColor(color);
        parent->addChild(l);
        return l;
    }
}

bool CollabPanel::init() {
    if (!CCLayer::init()) return false;

    constexpr float W = kWidth;
    constexpr float H = kHeight;
    this->setContentSize({W, H});

    // Touches: behind the menu buttons, so buttons work and the rest of the panel drags it.
    this->setTouchMode(kCCTouchesOneByOne);
    this->setTouchPriority(-127);
    this->setTouchEnabled(true);

    auto bg = CCScale9Sprite::create("GJ_square01.png");
    bg->setContentSize({W, H});
    bg->setPosition({W / 2, H / 2});
    bg->setOpacity(235);
    addChild(bg);

    auto* title = CCLabelBMFont::create("Editor Collab v2", "bigFont.fnt");
    title->setScale(0.42f);
    title->setPosition({W / 2 - 22, H - 18});
    title->setColor({255, 220, 80});
    addChild(title);

    m_sessionLabel = makeLabel(this, "", 0.5f, {W / 2, H - 40}, {100, 255, 100});
    m_levelLabel = makeLabel(this, "", 0.42f, {W / 2, H - 56}, {255, 255, 255});
    m_publishLabel = makeLabel(this, "", 0.4f, {W / 2, H - 72}, {100, 255, 100});
    m_publishLabel->setWidth(250);

    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    addChild(menu);

    constexpr float s = 0.4f;
    auto* create = makeBtn(menu, this, menu_selector(CollabPanel::onCreate), "Create Session", "GJ_button_01.png", s);
    auto* join   = makeBtn(menu, this, menu_selector(CollabPanel::onJoin),   "Join Session",   "GJ_button_02.png", s);
    auto* share  = makeBtn(menu, this, menu_selector(CollabPanel::onShare),  "Share Level",    "GJ_button_03.png", s);
    auto* sync   = makeBtn(menu, this, menu_selector(CollabPanel::onSync),   "Sync Now",       "GJ_button_04.png", s);
    auto* leave  = makeBtn(menu, this, menu_selector(CollabPanel::onLeave),  "Leave Session",  "GJ_button_06.png", s);
    layoutRow({create, join}, 70, W);
    layoutRow({share, sync}, 44, W);
    layoutRow({leave}, 18, W);

    auto* smaller = makeBtn(menu, this, menu_selector(CollabPanel::onSmaller), "-", "GJ_button_01.png", 0.4f);
    auto* bigger  = makeBtn(menu, this, menu_selector(CollabPanel::onBigger),  "+", "GJ_button_01.png", 0.4f);
    smaller->setPosition({W - 40, H - 18});
    bigger->setPosition({W - 16, H - 18});

    scheduleUpdate();
    refreshUI();
    return true;
}

bool CollabPanel::ccTouchBegan(CCTouch* touch, CCEvent*) {
    auto local = this->convertToNodeSpace(touch->getLocation());
    m_dragging = CCRect(0, 0, kWidth, kHeight).containsPoint(local);
    return m_dragging;
}

void CollabPanel::ccTouchMoved(CCTouch* touch, CCEvent*) {
    if (!m_dragging || !getParent()) return;
    auto now = getParent()->convertToNodeSpace(touch->getLocation());
    auto prev = getParent()->convertToNodeSpace(touch->getPreviousLocation());
    this->setPosition(getPosition() + (now - prev));
}

void CollabPanel::ccTouchEnded(CCTouch*, CCEvent*) {
    if (!m_dragging) return;
    m_dragging = false;
    auto pos = getPosition();
    Mod::get()->setSavedValue<float>("panel-x", pos.x);
    Mod::get()->setSavedValue<float>("panel-y", pos.y);
}

void CollabPanel::ccTouchCancelled(CCTouch* touch, CCEvent* event) { ccTouchEnded(touch, event); }

void CollabPanel::applyScale(float scale) {
    scale = std::clamp(scale, 0.5f, 1.6f);
    this->setScale(scale);
    Mod::get()->setSavedValue<float>("panel-scale", scale);
}
void CollabPanel::onBigger(CCObject*) { applyScale(getScale() + 0.1f); }
void CollabPanel::onSmaller(CCObject*) { applyScale(getScale() - 0.1f); }

void CollabPanel::update(float dt) {
    m_refreshTimer += dt;
    if (m_refreshTimer >= 0.5f) {
        m_refreshTimer = 0.f;
        refreshUI();
    }
}

void CollabPanel::refreshUI() {
    auto* mgr = CollabManager::get();
    auto* lel = LevelEditorLayer::get();
    std::string name = (lel && lel->m_level) ? std::string(lel->m_level->m_levelName) : "";

    m_sessionLabel->setString(mgr->statusText().c_str());
    m_sessionLabel->setColor(mgr->inSession() ? ccColor3B{100, 255, 100} : ccColor3B{200, 200, 100});
    m_levelLabel->setString(name.empty() ? "No level open" : ("Editing: " + name).c_str());

    if (name.empty()) {
        m_publishLabel->setString("");
    } else if (mgr->canPublishLevel(name)) {
        m_publishLabel->setString("You can publish this level.");
        m_publishLabel->setColor({100, 255, 100});
    } else {
        m_publishLabel->setString("You cannot publish this level - it belongs to another player.");
        m_publishLabel->setColor({255, 80, 80});
    }
}

void CollabPanel::onCreate(CCObject*) { CollabManager::get()->createSession(); }
void CollabPanel::onJoin(CCObject*)   { CollabManager::get()->joinSession(); }
void CollabPanel::onShare(CCObject*)  { CollabManager::get()->shareLevel(); }
void CollabPanel::onSync(CCObject*)   { CollabManager::get()->syncNow(); }
void CollabPanel::onLeave(CCObject*)  { CollabManager::get()->leaveSession(); }

// ================================================================
// CollabButton (floating toolbar button)
// ================================================================

CollabButton* CollabButton::create() {
    auto ret = new CollabButton();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

bool CollabButton::init() {
    if (!CCNode::init()) return false;

    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    addChild(menu);

    CCSprite* sprite = CCSprite::create("collab_icon.png"_spr);
    if (!sprite) sprite = CCSprite::createWithSpriteFrameName("GJ_editBtn_001.png");
    if (sprite) sprite->setScale(30.f / std::max(sprite->getContentSize().height, 1.f));

    auto* btn = CCMenuItemSpriteExtra::create(sprite, this, menu_selector(CollabButton::onTogglePanel));
    menu->addChild(btn);
    return true;
}

void CollabButton::onTogglePanel(CCObject*) {
    m_panelOpen = !m_panelOpen;

    if (m_panelOpen) {
        m_panel = CollabPanel::create();

        auto winSize = CCDirector::sharedDirector()->getWinSize();
        float scale = Mod::get()->getSavedValue<float>("panel-scale", 0.9f);
        m_panel->setScale(scale);

        float defX = winSize.width - CollabPanel::kWidth * scale - 10.f;
        float defY = winSize.height - CollabPanel::kHeight * scale - 50.f;
        m_panel->setPosition({Mod::get()->getSavedValue<float>("panel-x", defX),
                              Mod::get()->getSavedValue<float>("panel-y", defY)});

        getParent()->addChild(m_panel, 100);
    } else if (m_panel) {
        m_panel->removeFromParent();
        m_panel = nullptr;
    }
}
