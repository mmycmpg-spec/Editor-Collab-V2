#include "CollabUI.hpp"
#include <algorithm>
#include <Geode/ui/Notification.hpp>

// ================================================================
// CollabPanel
// ================================================================

CollabPanel* CollabPanel::create() {
    auto ret = new CollabPanel();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

namespace {
    CCMenuItemSpriteExtra* makeBtn(CCMenu* menu, CCObject* target, SEL_MenuHandler cb,
                                   char const* text, char const* tex, float scale = 0.45f) {
        auto* spr = ButtonSprite::create(text, "bigFont.fnt", tex, scale);
        auto* btn = CCMenuItemSpriteExtra::create(spr, target, cb);
        menu->addChild(btn);
        return btn;
    }

    // Centers buttons in a row using their real widths, so they can never overlap.
    void layoutRow(std::vector<CCMenuItemSpriteExtra*> const& btns, float y, float totalWidth) {
        constexpr float gap = 6.f;
        float used = gap * (btns.size() - 1);
        for (auto* b : btns) used += b->getScaledContentSize().width;
        float x = (totalWidth - used) / 2;
        for (auto* b : btns) {
            float w = b->getScaledContentSize().width;
            b->setPosition({x + w / 2, y});
            x += w + gap;
        }
    }
}

bool CollabPanel::init() {
    if (!CCLayer::init()) return false;

    constexpr float W = kWidth;
    constexpr float H = kHeight;

    this->setContentSize({W, H});

    // Touches: sit just behind the menu buttons so buttons still work,
    // but anything else on the panel drags it.
    this->setTouchMode(kCCTouchesOneByOne);
    this->setTouchPriority(-127);
    this->setTouchEnabled(true);

    auto bg = CCScale9Sprite::create("GJ_square01.png");
    bg->setContentSize({W, H});
    bg->setPosition({W / 2, H / 2});
    bg->setOpacity(235);
    addChild(bg);

    auto* title = CCLabelBMFont::create("Editor Collab v2", "bigFont.fnt");
    title->setScale(0.42f);
    title->setPosition({W / 2 - 22, H - 18});
    title->setColor({255, 220, 80});
    addChild(title);

    m_statusLabel = CCLabelBMFont::create("Not Connected", "chatFont.fnt");
    m_statusLabel->setScale(0.5f);
    m_statusLabel->setPosition({W / 2, H - 40});
    addChild(m_statusLabel);

    m_sessionIdLabel = CCLabelBMFont::create("Session: --", "chatFont.fnt");
    m_sessionIdLabel->setScale(0.42f);
    m_sessionIdLabel->setPosition({W / 2, H - 56});
    m_sessionIdLabel->setColor({200, 200, 200});
    addChild(m_sessionIdLabel);

    m_ownerLabel = CCLabelBMFont::create("Owner: --", "chatFont.fnt");
    m_ownerLabel->setScale(0.42f);
    m_ownerLabel->setPosition({W / 2, H - 70});
    addChild(m_ownerLabel);

    auto* collabTitle = CCLabelBMFont::create("Collaborators:", "chatFont.fnt");
    collabTitle->setScale(0.42f);
    collabTitle->setAnchorPoint({0, 0.5f});
    collabTitle->setPosition({14, H - 88});
    collabTitle->setColor({180, 230, 255});
    addChild(collabTitle);

    m_collaboratorList = CCNode::create();
    m_collaboratorList->setPosition({20, H - 102});
    addChild(m_collaboratorList);

    m_publishStatusLabel = CCLabelBMFont::create("", "chatFont.fnt");
    m_publishStatusLabel->setScale(0.38f);
    m_publishStatusLabel->setPosition({W / 2, 84});
    m_publishStatusLabel->setWidth(230);
    addChild(m_publishStatusLabel);

    m_updateLabel = CCLabelBMFont::create("", "chatFont.fnt");
    m_updateLabel->setScale(0.42f);
    m_updateLabel->setPosition({W / 2, 66});
    m_updateLabel->setColor({255, 220, 80});
    addChild(m_updateLabel);

    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    addChild(menu);

    auto* create = makeBtn(menu, this, menu_selector(CollabPanel::onCreateSession), "Create", "GJ_button_01.png");
    auto* join   = makeBtn(menu, this, menu_selector(CollabPanel::onJoinSession),   "Join",   "GJ_button_02.png");
    auto* copy   = makeBtn(menu, this, menu_selector(CollabPanel::onCopyId),        "Copy ID","GJ_button_03.png");
    auto* sync   = makeBtn(menu, this, menu_selector(CollabPanel::onSyncNow),       "Sync Now","GJ_button_04.png");
    auto* leave  = makeBtn(menu, this, menu_selector(CollabPanel::onLeaveSession),  "Leave",  "GJ_button_06.png");
    layoutRow({create, join, copy}, 44, W);
    layoutRow({sync, leave}, 18, W);

    // Resize buttons (top right)
    auto* smaller = makeBtn(menu, this, menu_selector(CollabPanel::onSmaller), "-", "GJ_button_01.png", 0.4f);
    auto* bigger  = makeBtn(menu, this, menu_selector(CollabPanel::onBigger),  "+", "GJ_button_01.png", 0.4f);
    smaller->setPosition({W - 40, H - 18});
    bigger->setPosition({W - 16, H - 18});

    CollabManager::get()->ping();
    scheduleUpdate();
    refreshUI();
    return true;
}

// ---- Dragging ------------------------------------------------

bool CollabPanel::ccTouchBegan(CCTouch* touch, CCEvent*) {
    auto local = this->convertToNodeSpace(touch->getLocation());
    m_dragging = CCRect(0, 0, kWidth, kHeight).containsPoint(local);
    return m_dragging; // swallow touches on the panel so the editor ignores them
}

void CollabPanel::ccTouchMoved(CCTouch* touch, CCEvent*) {
    if (!m_dragging || !getParent()) return;
    auto now = getParent()->convertToNodeSpace(touch->getLocation());
    auto prev = getParent()->convertToNodeSpace(touch->getPreviousLocation());
    this->setPosition(getPosition() + (now - prev));
}

void CollabPanel::ccTouchEnded(CCTouch*, CCEvent*) {
    if (!m_dragging) return;
    m_dragging = false;
    auto pos = getPosition();
    Mod::get()->setSavedValue<float>("panel-x", pos.x);
    Mod::get()->setSavedValue<float>("panel-y", pos.y);
}

void CollabPanel::ccTouchCancelled(CCTouch* touch, CCEvent* event) {
    ccTouchEnded(touch, event);
}

// ---- Resizing ------------------------------------------------

void CollabPanel::applyScale(float scale) {
    scale = std::clamp(scale, 0.5f, 1.6f);
    this->setScale(scale);
    Mod::get()->setSavedValue<float>("panel-scale", scale);
}

void CollabPanel::onBigger(CCObject*) { applyScale(getScale() + 0.1f); }
void CollabPanel::onSmaller(CCObject*) { applyScale(getScale() - 0.1f); }

// ---- State ---------------------------------------------------

void CollabPanel::update(float dt) {
    m_refreshTimer += dt;
    if (m_refreshTimer >= 0.5f) {
        m_refreshTimer = 0.f;
        refreshUI();
    }
}

void CollabPanel::refreshUI() {
    auto* mgr = CollabManager::get();

    if (!mgr->isInSession()) {
        m_statusLabel->setString(mgr->isConnected() ? "Server online - no session" : "Server offline");
        m_statusLabel->setColor(mgr->isConnected() ? ccColor3B{200, 200, 100} : ccColor3B{255, 100, 100});
        m_sessionIdLabel->setString("Session: --");
        m_ownerLabel->setString("Owner: --");
        m_ownerLabel->setColor({180, 180, 180});
        m_publishStatusLabel->setString("");
        m_updateLabel->setString("");
        updateCollaboratorList();
        return;
    }

    auto& session = mgr->getSession();
    m_statusLabel->setString(("In Session - " + session.levelName).c_str());
    m_statusLabel->setColor({100, 255, 100});
    m_sessionIdLabel->setString(("ID: " + session.sessionId).c_str());
    m_ownerLabel->setString(("Owner: " + session.ownerName).c_str());
    m_ownerLabel->setColor(mgr->isOwner() ? ccColor3B{255, 220, 80} : ccColor3B{180, 180, 180});

    if (mgr->canPublishLevel(session.levelName)) {
        m_publishStatusLabel->setString("You can publish this level.");
        m_publishStatusLabel->setColor({100, 255, 100});
    } else {
        m_publishStatusLabel->setString("You cannot publish this level.\nIt belongs to another player.");
        m_publishStatusLabel->setColor({255, 80, 80});
    }

    m_updateLabel->setString(mgr->hasRemoteUpdates() ? "Friends changed the level - Sync Now!" : "");
    updateCollaboratorList();
}

void CollabPanel::updateCollaboratorList() {
    m_collaboratorList->removeAllChildren();

    auto& names = CollabManager::get()->getSession().collaborators;
    float y = 0;
    int shown = 0;

    for (auto& name : names) {
        if (shown >= 3) {
            auto* more = CCLabelBMFont::create(
                ("+" + std::to_string(names.size() - shown) + " more").c_str(), "chatFont.fnt");
            more->setScale(0.36f);
            more->setAnchorPoint({0, 0.5f});
            more->setPosition({0, y});
            more->setColor({150, 150, 150});
            m_collaboratorList->addChild(more);
            break;
        }
        auto* label = CCLabelBMFont::create(("- " + name).c_str(), "chatFont.fnt");
        label->setScale(0.4f);
        label->setAnchorPoint({0, 0.5f});
        label->setPosition({0, y});
        label->setColor({180, 230, 255});
        m_collaboratorList->addChild(label);
        y -= 12.f;
        shown++;
    }

    if (names.empty()) {
        auto* label = CCLabelBMFont::create("No collaborators online", "chatFont.fnt");
        label->setScale(0.36f);
        label->setAnchorPoint({0, 0.5f});
        label->setColor({150, 150, 150});
        m_collaboratorList->addChild(label);
    }
}

// ---- Buttons -------------------------------------------------

void CollabPanel::onCreateSession(CCObject*) {
    CollabManager::get()->createSession([](bool ok, std::string msg) {
        if (!ok) {
            FLAlertLayer::create("Collab", msg, "OK")->show();
            return;
        }
        geode::utils::clipboard::write(msg);
        FLAlertLayer::create(
            "Session Created!",
            "Session ID: " + msg + "\n\nIt was copied to your clipboard.\n"
            "Send it to your friend - they press Join and paste it.",
            "OK")->show();
    });
}

void CollabPanel::onJoinSession(CCObject*) {
    if (CollabManager::get()->isInSession()) {
        FLAlertLayer::create("Already in Session", "You are already in a session. Leave first.", "OK")->show();
        return;
    }
    JoinSessionPopup::create()->show();
}

void CollabPanel::onCopyId(CCObject*) {
    auto* mgr = CollabManager::get();
    if (!mgr->isInSession()) {
        FLAlertLayer::create("No Session", "Create a session first.", "OK")->show();
        return;
    }
    geode::utils::clipboard::write(mgr->getSession().sessionId);
    Notification::create("Session ID copied", NotificationIcon::Success)->show();
}

void CollabPanel::onLeaveSession(CCObject*) {
    if (!CollabManager::get()->isInSession()) return;
    geode::createQuickPopup(
        "Leave Session",
        "Are you sure you want to leave the collab session?",
        "No", "Yes",
        [](FLAlertLayer*, bool confirm) {
            if (confirm) CollabManager::get()->leaveSession();
        }
    );
}

void CollabPanel::onSyncNow(CCObject*) {
    if (!CollabManager::get()->isInSession()) {
        FLAlertLayer::create("No Session", "Create or join a session first.", "OK")->show();
        return;
    }
    CollabManager::get()->syncNow();
}

// ================================================================
// CollabButton (floating toolbar button)
// ================================================================

CollabButton* CollabButton::create() {
    auto ret = new CollabButton();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

bool CollabButton::init() {
    if (!CCNode::init()) return false;

    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    addChild(menu);

    CCSprite* sprite = CCSprite::create("collab_icon.png"_spr);
    if (!sprite) sprite = CCSprite::createWithSpriteFrameName("GJ_editBtn_001.png");
    if (sprite) {
        float target = 30.f;
        sprite->setScale(target / std::max(sprite->getContentSize().height, 1.f));
    }

    auto* btn = CCMenuItemSpriteExtra::create(
        sprite, this, menu_selector(CollabButton::onTogglePanel));
    menu->addChild(btn);

    return true;
}

void CollabButton::onTogglePanel(CCObject*) {
    m_panelOpen = !m_panelOpen;

    if (m_panelOpen) {
        m_panel = CollabPanel::create();

        auto winSize = CCDirector::sharedDirector()->getWinSize();
        float scale = Mod::get()->getSavedValue<float>("panel-scale", 0.9f);
        m_panel->setScale(scale);

        float defX = winSize.width - CollabPanel::kWidth * scale - 10.f;
        float defY = winSize.height - CollabPanel::kHeight * scale - 50.f;
        float x = Mod::get()->getSavedValue<float>("panel-x", defX);
        float y = Mod::get()->getSavedValue<float>("panel-y", defY);
        m_panel->setPosition({x, y});

        getParent()->addChild(m_panel, 100);
    } else if (m_panel) {
        m_panel->removeFromParent();
        m_panel = nullptr;
    }
}

// ================================================================
// JoinSessionPopup
// ================================================================

JoinSessionPopup* JoinSessionPopup::create() {
    auto ret = new JoinSessionPopup();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

bool JoinSessionPopup::init() {
    if (!Popup::init(320, 200)) return false;
    setTitle("Join Collab Session");

    auto* label = CCLabelBMFont::create(
        "Enter the Session ID your friend shared:", "chatFont.fnt");
    label->setScale(0.45f);
    label->setPosition({m_size.width / 2, 145});
    m_mainLayer->addChild(label);

    m_sessionInput = geode::TextInput::create(240, "Session ID...", "bigFont.fnt");
    m_sessionInput->setPosition({m_size.width / 2, 110});
    m_sessionInput->setMaxCharCount(8);
    m_mainLayer->addChild(m_sessionInput);

    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    m_mainLayer->addChild(menu);

    auto* joinSprite = ButtonSprite::create("Join", "bigFont.fnt", "GJ_button_01.png", 0.8f);
    auto* joinBtn = CCMenuItemSpriteExtra::create(
        joinSprite, this, menu_selector(JoinSessionPopup::onJoin));
    joinBtn->setPosition({m_size.width / 2, 65});
    menu->addChild(joinBtn);

    return true;
}

void JoinSessionPopup::onJoin(CCObject*) {
    std::string sessionId = m_sessionInput->getString();
    if (sessionId.empty()) {
        FLAlertLayer::create("Error", "Please enter a session ID.", "OK")->show();
        return;
    }

    // The manager imports the level as a NEW local level and opens it.
    // The popup closes first so the scene swap is clean.
    CollabManager::get()->joinSession(sessionId, [](bool ok, std::string msg) {
        if (!ok) {
            FLAlertLayer::create("Could not join", msg, "OK")->show();
            return;
        }
        Notification::create(msg + " You cannot publish it.", NotificationIcon::Success)->show();
    });
    onClose(nullptr);
}
