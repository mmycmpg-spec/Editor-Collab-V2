#pragma once
#include <Geode/Geode.hpp>
#include <functional>
#include <string>
#include <vector>
#include "LevelMerge.hpp"

using namespace geode::prelude;
using json = matjson::Value;

struct CollabSession {
    std::string sessionId;
    std::string ownerName;
    std::string levelName;           // name of the local editor level this session is tied to
    bool isOwner = false;
    std::vector<std::string> collaborators; // other people currently online

    std::string baseData;            // last copy we know the server has (raw level string)
    int baseVersion = 0;             // server version of baseData
    int remoteVersion = 0;           // newest server version we have heard of
};

// Sync model: every session has ONE shared copy on the server with a version
// number. "Sync Now" uploads your changes (merging with anyone else's if the
// server moved on) and downloads theirs. Nothing reloads under you unless you
// press Sync Now.
class CollabManager {
public:
    static CollabManager* get();

    using Done = std::function<void(bool ok, std::string message)>;

    // Server
    void ping();
    bool isConnected() const { return m_online; }

    // Session management
    void createSession(Done done);
    void joinSession(std::string sessionId, Done done);
    void leaveSession();
    bool isInSession() const { return m_inSession; }
    bool isOwner() const { return m_inSession && m_session.isOwner; }
    CollabSession& getSession() { return m_session; }

    // Sync
    void syncNow();                   // manual: push + pull + merge
    void tick(float dt);              // called every second while the editor is open
    bool hasRemoteUpdates() const { return m_inSession && m_session.remoteVersion > m_session.baseVersion; }
    bool isBusy() const { return m_busy; }

    // Publish guard - you can never publish a level you received
    bool canPublishLevel(std::string const& levelName) const;
    std::string getPublishBlockReason(std::string const& levelName) const;

private:
    CollabManager() = default;
    static CollabManager* s_instance;

    bool m_online = false;
    bool m_inSession = false;
    bool m_busy = false;
    float m_pollTimer = 0.f;
    float m_pushTimer = 0.f;
    CollabSession m_session;

    std::string url() const;
    std::string userId();
    std::string username() const;
    void post(json body, std::function<void(bool netOk, json const& resp)> cb);
    json baseMsg(char const* type);

    bool editorMatchesSession() const;
    void pushData(std::string raw, int baseVersion, bool manual, int attempt);
    void integrateRemote(std::string const& theirsRaw, int theirsVersion, bool manual);
    void applyToEditor(std::string const& raw);
    void importAsNewLevel(std::string const& levelName, std::string const& raw);
    void markReceived(std::string const& levelName);
    void sessionEnded(std::string const& why);
    void readPresence(json const& resp);
};
