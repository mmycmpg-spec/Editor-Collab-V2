#pragma once
#include <Geode/Geode.hpp>
#include <string>
#include "LevelMerge.hpp"

using namespace geode::prelude;

// No server. Friends swap levels through the clipboard:
//   Send    -> copies your level to the clipboard (you paste it to them in Discord, etc.)
//   Receive -> reads a level from the clipboard and merges / imports it
class CollabManager {
public:
    static CollabManager* get();

    void sendToClipboard();
    void receiveFromClipboard();

    // Publish guard - you can never publish a level you received
    bool canPublishLevel(std::string const& levelName) const;
    std::string getPublishBlockReason(std::string const& levelName) const;

    std::string lastInfo; // shown in the panel

private:
    CollabManager() = default;
    static CollabManager* s_instance;

    std::string userId();
    std::string username() const;
    void markReceived(std::string const& localName);
    void openAsNewLevel(std::string const& name, std::string const& raw);
    void applyToEditor(std::string const& raw);
};
