#pragma once
#include <Geode/Geode.hpp>
#include <string>
#include "LevelMerge.hpp"

using namespace geode::prelude;

// No server. A "session code" is the level itself packed into text.
//   Create Session -> you host; code is copied to your clipboard
//   Join Session   -> reads the host's code from the clipboard, imports the level and opens it
//   Share Level    -> copies your current copy of the level (so friends can get your changes)
//   Sync Now       -> merges a copy from the clipboard into the level you have open
class CollabManager {
public:
    static CollabManager* get();

    void createSession();
    void joinSession();
    void shareLevel();
    void syncNow();
    void leaveSession();

    bool inSession() const { return m_inSession; }
    std::string statusText() const;

    // Publish guard - you can never publish a level you received
    bool canPublishLevel(std::string const& levelName) const;
    std::string getPublishBlockReason(std::string const& levelName) const;

private:
    CollabManager() = default;
    static CollabManager* s_instance;

    bool m_inSession = false;
    bool m_host = false;
    std::string m_levelName;   // local level the session is about
    std::string m_otherName;   // host / last friend

    std::string userId();
    std::string username() const;
    bool copyLevel(std::string& packedOut);
    void receive(bool joining);
    void markReceived(std::string const& localName);
    void openAsNewLevel(std::string name, std::string raw);
    void applyToEditor(std::string raw);
};
