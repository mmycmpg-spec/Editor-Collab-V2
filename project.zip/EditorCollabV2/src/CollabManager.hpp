#pragma once
#include <Geode/Geode.hpp>
#include <atomic>
#include <chrono>
#include <functional>
#include <string>
#include <unordered_map>
#include <vector>

using namespace geode::prelude;

struct CollabSession {
    std::string code;        // the 4 digit code friends type to join
    std::string ownerName;
    std::string levelName;
    std::string clientId;    // our id on the server
    bool isOwner = false;
    std::vector<std::string> collaborators; // the other people in the session
};

// Edits received from a collaborator
struct RemoteDiff {
    std::string from;
    std::vector<std::string> added;   // object save strings
    std::vector<std::string> removed;
};

class CollabManager {
public:
    static CollabManager* get();

    using DoneCallback = std::function<void(bool ok, std::string message)>;

    // Session management (the callbacks run on the main thread)
    void createSession(LevelEditorLayer* editor, DoneCallback cb);
    void joinSession(std::string const& code, DoneCallback cb);
    void leaveSession();

    bool isInSession() const { return m_inSession; }
    bool isOwner() const { return m_inSession && m_session.isOwner; }
    CollabSession const& getSession() const { return m_session; }

    // Call about once per second while an editor is open
    void editorTick(LevelEditorLayer* editor);

    // Publish guard - levels received through a session can't be published
    bool canPublishLevel(std::string const& levelName) const;
    std::string getPublishBlockReason(std::string const& levelName) const;

    // The panel listens to this so it can refresh itself
    std::function<void()> onStateChanged;

private:
    CollabManager() = default;

    using ObjectCounts = std::unordered_map<std::string, int>;

    static ObjectCounts scanObjects(LevelEditorLayer* editor);
    static std::string saveString(GameObject* obj, LevelEditorLayer* editor);

    void applyRemote(LevelEditorLayer* editor, RemoteDiff const& diff);
    void sendDiff(std::vector<std::string> added, std::vector<std::string> removed);

    void startPolling();
    void handleEvents(std::string const& text);
    void endSession(std::string const& reason);
    void markReceived(std::string const& levelName);
    void changed();

    static std::string onlineUrl(); // optional online server from the settings (empty = Wi-Fi / hotspot mode)

    CollabSession m_session;
    std::string m_base; // where this session talks to (the host's phone, or an online server)
    bool m_inSession = false;
    std::atomic<int> m_generation{0}; // bumps to stop old polling threads

    GJGameLevel* m_levelPtr = nullptr; // the level this session is editing
    bool m_snapshotReady = false;
    ObjectCounts m_snapshot;           // what the server already knows about
    std::vector<RemoteDiff> m_pendingRemote;
    std::chrono::steady_clock::time_point m_lastEditNotice{};
};
