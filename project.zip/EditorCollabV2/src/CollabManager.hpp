#pragma once
#include <Geode/Geode.hpp>
#include <chrono>
#include <functional>
#include <unordered_map>

using namespace geode::prelude;
using json = matjson::Value;

// Who owns a shared session
struct CollabSession {
    std::string sessionId;
    std::string ownerName;
    std::string ownerAccountId;
    std::string levelData;
    std::string levelName;
    bool isOwner = false;   // are YOU the owner of this session?
    bool canPublish = false; // only true if isOwner
    std::vector<std::string> collaborators;
    std::chrono::steady_clock::time_point lastSync;
};

// A pending edit from a collaborator
struct PendingEdit {
    std::string authorName;
    std::string authorId;
    std::string objectData;
    std::string editType; // "ADD", "DELETE", "MODIFY"
    int objectId;
};

class CollabManager {
public:
    static CollabManager* get();

    // Session management
    bool createSession(const std::string& levelData, const std::string& levelName);
    bool joinSession(const std::string& sessionId);
    void leaveSession();
    bool isInSession() const { return m_inSession; }
    bool isOwner() const { return m_session.isOwner; }
    CollabSession& getSession() { return m_session; }

    // Level sharing
    bool shareLevel(const std::string& friendId, const std::string& levelData);
    bool receiveSharedLevel(const json& shareData);

    // Editing
    void sendObjectAdd(const std::string& objData);
    void sendObjectDelete(int objId);
    void sendObjectModify(int objId, const std::string& objData);
    void applyPendingEdits();

    // Sync
    void syncLevelData(const std::string& levelData);
    void requestFullSync();
    std::string getMergedLevelData();

    // Publish guard — CORE RULE
    bool canPublishLevel() const;
    std::string getPublishBlockReason() const;

    // Connection
    bool connect(const std::string& url);
    void disconnect();
    bool isConnected() const { return m_connected; }

    // Callbacks
    std::function<void(PendingEdit)> onEditReceived;
    std::function<void(std::string)> onFriendJoined;
    std::function<void(std::string)> onFriendLeft;
    std::function<void(std::string)> onSyncReceived;
    std::function<void(std::string)> onSessionCreated;
    std::function<void(std::string)> onError;

    // Friends list (fetched from GD account)
    std::vector<std::pair<std::string,std::string>> m_friends; // {name, accountId}
    void fetchFriends();

    // Pending edits queue
    std::vector<PendingEdit> m_pendingEdits;

private:
    CollabManager() = default;
    static CollabManager* s_instance;

    CollabSession m_session;
    bool m_inSession = false;
    bool m_connected = false;

    // Track received levels — used to block publishing
    // Key: levelName, Value: ownerAccountId
    std::unordered_map<std::string, std::string> m_receivedLevels;

    void handleMessage(const std::string& msg);
    void sendMessage(const json& data);

    std::string m_wsUrl;
    std::string m_myAccountId;
    std::string m_myUsername;
};