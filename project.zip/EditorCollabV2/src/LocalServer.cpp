#include "LocalServer.hpp"

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cstdlib>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <deque>
#include <map>
#include <mutex>
#include <random>
#include <thread>
#include <unordered_map>
#include <vector>

#if !defined(_WIN32)
    #include <arpa/inet.h>
    #include <net/if.h>
    #include <netinet/in.h>
    #include <sys/ioctl.h>
    #include <sys/socket.h>
    #include <sys/time.h>
    #include <unistd.h>
#endif

namespace collab {

#if defined(_WIN32)

int startLocalServer() { return 0; }
std::string discoverHost(std::string const&) { return ""; }

#else

namespace {

constexpr int kFirstPort = 47777;
constexpr int kPortTries = 10;
constexpr int kDiscoveryPort = 47778;
constexpr size_t kMaxBody = 25 * 1024 * 1024;
constexpr int kPollSeconds = 25;

// ---------------------------------------------------------------------------
// Tiny JSON helpers (we only handle flat objects of strings / string arrays)
// ---------------------------------------------------------------------------

std::string jsonString(std::string const& s) {
    std::string out = "\"";
    for (unsigned char c : s) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20) {
                    char buf[8];
                    snprintf(buf, sizeof(buf), "\\u%04x", c);
                    out += buf;
                } else {
                    out += static_cast<char>(c);
                }
        }
    }
    out += "\"";
    return out;
}

std::string jsonArray(std::vector<std::string> const& items) {
    std::string out = "[";
    for (size_t i = 0; i < items.size(); i++) {
        if (i) out += ",";
        out += jsonString(items[i]);
    }
    out += "]";
    return out;
}

struct Json {
    std::map<std::string, std::string> str;
    std::map<std::string, std::vector<std::string>> arr;
    std::string get(std::string const& key) const {
        auto it = str.find(key);
        return it == str.end() ? std::string() : it->second;
    }
};

struct Parser {
    std::string const& s;
    size_t i = 0;
    explicit Parser(std::string const& text) : s(text) {}

    void ws() {
        while (i < s.size() && (s[i] == ' ' || s[i] == '\n' || s[i] == '\r' || s[i] == '\t')) i++;
    }

    static void putUtf8(std::string& out, unsigned cp) {
        if (cp < 0x80) out += static_cast<char>(cp);
        else if (cp < 0x800) {
            out += static_cast<char>(0xC0 | (cp >> 6));
            out += static_cast<char>(0x80 | (cp & 0x3F));
        } else {
            out += static_cast<char>(0xE0 | (cp >> 12));
            out += static_cast<char>(0x80 | ((cp >> 6) & 0x3F));
            out += static_cast<char>(0x80 | (cp & 0x3F));
        }
    }

    bool string(std::string& out) {
        if (i >= s.size() || s[i] != '"') return false;
        i++;
        out.clear();
        while (i < s.size()) {
            char c = s[i++];
            if (c == '"') return true;
            if (c != '\\') {
                out += c;
                continue;
            }
            if (i >= s.size()) return false;
            char e = s[i++];
            switch (e) {
                case 'n': out += '\n'; break;
                case 'r': out += '\r'; break;
                case 't': out += '\t'; break;
                case 'b': out += '\b'; break;
                case 'f': out += '\f'; break;
                case 'u': {
                    if (i + 4 > s.size()) return false;
                    unsigned cp = static_cast<unsigned>(std::strtoul(s.substr(i, 4).c_str(), nullptr, 16));
                    i += 4;
                    putUtf8(out, cp);
                    break;
                }
                default: out += e; // " \ /
            }
        }
        return false;
    }

    bool object(Json& out) {
        ws();
        if (i >= s.size() || s[i] != '{') return false;
        i++;
        ws();
        if (i < s.size() && s[i] == '}') { i++; return true; }
        while (i < s.size()) {
            ws();
            std::string key;
            if (!string(key)) return false;
            ws();
            if (i >= s.size() || s[i] != ':') return false;
            i++;
            ws();
            if (i < s.size() && s[i] == '"') {
                std::string v;
                if (!string(v)) return false;
                out.str[key] = v;
            } else if (i < s.size() && s[i] == '[') {
                i++;
                std::vector<std::string> list;
                ws();
                if (i < s.size() && s[i] == ']') {
                    i++;
                } else {
                    while (i < s.size()) {
                        ws();
                        std::string v;
                        if (!string(v)) return false;
                        list.push_back(std::move(v));
                        ws();
                        if (i < s.size() && s[i] == ',') { i++; continue; }
                        if (i < s.size() && s[i] == ']') { i++; break; }
                        return false;
                    }
                }
                out.arr[key] = std::move(list);
            } else {
                // number / true / false / null: skip it
                while (i < s.size() && s[i] != ',' && s[i] != '}') i++;
            }
            ws();
            if (i < s.size() && s[i] == ',') { i++; continue; }
            if (i < s.size() && s[i] == '}') { i++; return true; }
            return false;
        }
        return false;
    }
};

bool parseJson(std::string const& text, Json& out) {
    Parser p(text);
    return p.object(out);
}

// ---------------------------------------------------------------------------
// Session state
// ---------------------------------------------------------------------------

struct Client {
    std::string name;
    std::deque<std::string> queue; // each entry is one event, as JSON
};

struct Session {
    std::string code;
    std::string ownerId;
    std::string ownerName;
    std::string levelName;
    std::string header;
    std::unordered_map<std::string, std::pair<int, uint64_t>> objects; // text -> {count, order}
    uint64_t nextOrder = 0;
    std::map<std::string, Client> clients;
    bool ended = false; // owner left; only existing clients may still read events
};

std::mutex g_mutex;
std::condition_variable g_cv;
std::map<std::string, Session> g_sessions;
std::atomic<int> g_port{0};
std::once_flag g_startOnce;

std::string randomHex(int bytes) {
    static std::mt19937_64 rng{std::random_device{}()};
    std::string out;
    char buf[3];
    for (int i = 0; i < bytes; i++) {
        snprintf(buf, sizeof(buf), "%02x", static_cast<unsigned>(rng() & 0xFF));
        out += buf;
    }
    return out;
}

std::string newCode() {
    static std::mt19937 rng{std::random_device{}()};
    for (int i = 0; i < 300; i++) {
        std::string code = std::to_string(1000 + rng() % 9000);
        if (!g_sessions.count(code)) return code;
    }
    return "";
}

void parseLevel(std::string const& level, Session& s) {
    s.objects.clear();
    s.nextOrder = 0;
    size_t start = 0;
    bool first = true;
    while (start <= level.size()) {
        size_t end = level.find(';', start);
        if (end == std::string::npos) end = level.size();
        std::string part = level.substr(start, end - start);
        if (first) {
            s.header = part;
            first = false;
        } else if (!part.empty()) {
            auto& e = s.objects[part];
            if (e.first == 0) e.second = s.nextOrder++;
            e.first++;
        }
        if (end == level.size()) break;
        start = end + 1;
    }
}

std::string buildLevel(Session const& s) {
    std::vector<std::pair<uint64_t, std::string const*>> order;
    order.reserve(s.objects.size());
    for (auto& [text, e] : s.objects) order.push_back({e.second, &text});
    std::sort(order.begin(), order.end());
    std::string out = s.header + ";";
    for (auto& [o, text] : order) {
        int count = s.objects.at(*text).first;
        for (int i = 0; i < count; i++) {
            out += *text;
            out += ';';
        }
    }
    return out;
}

void applyDiff(Session& s, std::vector<std::string> const& added, std::vector<std::string> const& removed) {
    for (auto& obj : removed) {
        auto it = s.objects.find(obj);
        if (it == s.objects.end()) continue;
        if (--it->second.first <= 0) s.objects.erase(it);
    }
    for (auto& obj : added) {
        auto& e = s.objects[obj];
        if (e.first == 0) e.second = s.nextOrder++;
        e.first++;
    }
}

// call with g_mutex held
void pushEvent(Session& s, std::string const& event, std::string const& exceptId = "") {
    for (auto& [id, client] : s.clients) {
        if (id != exceptId) client.queue.push_back(event);
    }
    g_cv.notify_all();
}

// ---------------------------------------------------------------------------
// Request handling
// ---------------------------------------------------------------------------

struct Response {
    int status = 200;
    std::string body;
};

Response err(int status, std::string const& message) {
    return {status, "{\"error\":" + jsonString(message) + "}"};
}

Response handleCreate(Json const& b) {
    std::lock_guard lock(g_mutex);
    std::string code = newCode();
    if (code.empty()) return err(503, "No free session codes");

    Session s;
    s.code = code;
    s.ownerId = randomHex(8);
    s.ownerName = b.get("name").substr(0, 32);
    if (s.ownerName.empty()) s.ownerName = "Owner";
    s.levelName = b.get("levelName").substr(0, 64);
    if (s.levelName.empty()) s.levelName = "Collab level";
    parseLevel(b.get("levelString"), s);
    s.clients[s.ownerId].name = s.ownerName;

    std::string clientId = s.ownerId;
    g_sessions[code] = std::move(s);
    return {200, "{\"code\":" + jsonString(code) + ",\"clientId\":" + jsonString(clientId) + "}"};
}

Response handleJoin(Json const& b) {
    std::lock_guard lock(g_mutex);
    auto it = g_sessions.find(b.get("code"));
    if (it == g_sessions.end() || it->second.ended) return err(404, "Session not found");
    Session& s = it->second;

    std::string clientId = randomHex(8);
    std::string name = b.get("name").substr(0, 32);
    if (name.empty()) name = "Player";

    std::vector<std::string> users;
    for (auto& [id, c] : s.clients) users.push_back(c.name);

    s.clients[clientId].name = name;
    pushEvent(s, "{\"type\":\"joined\",\"name\":" + jsonString(name) + "}", clientId);

    return {200,
        "{\"clientId\":" + jsonString(clientId) +
        ",\"ownerName\":" + jsonString(s.ownerName) +
        ",\"levelName\":" + jsonString(s.levelName) +
        ",\"levelString\":" + jsonString(buildLevel(s)) +
        ",\"users\":" + jsonArray(users) + "}"};
}

Response handleDiff(Json const& b) {
    std::lock_guard lock(g_mutex);
    auto it = g_sessions.find(b.get("code"));
    if (it == g_sessions.end() || !it->second.clients.count(b.get("clientId")))
        return err(404, "Session not found");
    Session& s = it->second;

    std::vector<std::string> added, removed;
    if (auto a = b.arr.find("added"); a != b.arr.end()) added = a->second;
    if (auto r = b.arr.find("removed"); r != b.arr.end()) removed = r->second;
    applyDiff(s, added, removed);

    pushEvent(s,
        "{\"type\":\"diff\",\"from\":" + jsonString(s.clients[b.get("clientId")].name) +
        ",\"added\":" + jsonArray(added) + ",\"removed\":" + jsonArray(removed) + "}",
        b.get("clientId"));
    return {200, "{\"ok\":true}"};
}

Response handleLeave(Json const& b) {
    std::lock_guard lock(g_mutex);
    auto it = g_sessions.find(b.get("code"));
    if (it == g_sessions.end()) return {200, "{\"ok\":true}"};
    Session& s = it->second;
    auto client = s.clients.find(b.get("clientId"));
    if (client == s.clients.end()) return {200, "{\"ok\":true}"};

    if (b.get("clientId") == s.ownerId) {
        s.ended = true;
        pushEvent(s, "{\"type\":\"ended\",\"reason\":\"The owner closed the session\"}", s.ownerId);
        // give pollers a moment to receive the event, then drop the session
        std::string code = s.code;
        std::thread([code] {
            std::this_thread::sleep_for(std::chrono::seconds(5));
            std::lock_guard lock(g_mutex);
            g_sessions.erase(code);
            g_cv.notify_all();
        }).detach();
    } else {
        std::string name = client->second.name;
        s.clients.erase(client);
        pushEvent(s, "{\"type\":\"left\",\"name\":" + jsonString(name) + "}");
    }
    return {200, "{\"ok\":true}"};
}

Response handlePoll(std::string const& code, std::string const& clientId) {
    std::unique_lock lock(g_mutex);
    auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(kPollSeconds);

    while (true) {
        auto it = g_sessions.find(code);
        if (it == g_sessions.end() || !it->second.clients.count(clientId))
            return err(404, "Session not found");
        Client& c = it->second.clients[clientId];
        if (!c.queue.empty()) {
            std::string body = "{\"events\":[";
            bool first = true;
            while (!c.queue.empty()) {
                if (!first) body += ",";
                first = false;
                body += c.queue.front();
                c.queue.pop_front();
            }
            body += "]}";
            return {200, body};
        }
        if (g_cv.wait_until(lock, deadline) == std::cv_status::timeout) {
            return {200, "{\"events\":[]}"};
        }
    }
}

Response handleInfo(std::string const& code) {
    std::lock_guard lock(g_mutex);
    auto it = g_sessions.find(code);
    if (it == g_sessions.end() || it->second.ended) return err(404, "Session not found");
    return {200, "{\"found\":true,\"owner\":" + jsonString(it->second.ownerName) + "}"};
}

// ---------------------------------------------------------------------------
// HTTP plumbing
// ---------------------------------------------------------------------------

std::string urlParam(std::string const& query, std::string const& key) {
    std::string needle = key + "=";
    size_t pos = 0;
    while (pos < query.size()) {
        size_t end = query.find('&', pos);
        if (end == std::string::npos) end = query.size();
        if (query.compare(pos, needle.size(), needle) == 0)
            return query.substr(pos + needle.size(), end - pos - needle.size());
        pos = end + 1;
    }
    return "";
}

bool sendAll(int fd, std::string const& data) {
    size_t sent = 0;
    while (sent < data.size()) {
        ssize_t n = ::send(fd, data.data() + sent, data.size() - sent, 0);
        if (n <= 0) return false;
        sent += static_cast<size_t>(n);
    }
    return true;
}

void handleConnection(int fd) {
    timeval tv{};
    tv.tv_sec = 15;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    std::string data;
    char buf[8192];
    size_t headerEnd = std::string::npos;
    while (headerEnd == std::string::npos) {
        ssize_t n = ::recv(fd, buf, sizeof(buf), 0);
        if (n <= 0) { ::close(fd); return; }
        data.append(buf, static_cast<size_t>(n));
        headerEnd = data.find("\r\n\r\n");
        if (data.size() > 65536 && headerEnd == std::string::npos) { ::close(fd); return; }
    }

    std::string head = data.substr(0, headerEnd);
    std::string body = data.substr(headerEnd + 4);

    // request line
    size_t lineEnd = head.find("\r\n");
    std::string line = head.substr(0, lineEnd == std::string::npos ? head.size() : lineEnd);
    size_t sp1 = line.find(' ');
    size_t sp2 = line.find(' ', sp1 == std::string::npos ? 0 : sp1 + 1);
    if (sp1 == std::string::npos || sp2 == std::string::npos) { ::close(fd); return; }
    std::string method = line.substr(0, sp1);
    std::string target = line.substr(sp1 + 1, sp2 - sp1 - 1);

    // content length (case-insensitive search)
    size_t contentLength = 0;
    {
        std::string lower = head;
        std::transform(lower.begin(), lower.end(), lower.begin(), [](unsigned char c) { return std::tolower(c); });
        size_t p = lower.find("content-length:");
        if (p != std::string::npos) contentLength = static_cast<size_t>(std::strtoull(lower.c_str() + p + 15, nullptr, 10));
    }
    if (contentLength > kMaxBody) { ::close(fd); return; }
    while (body.size() < contentLength) {
        ssize_t n = ::recv(fd, buf, sizeof(buf), 0);
        if (n <= 0) { ::close(fd); return; }
        body.append(buf, static_cast<size_t>(n));
    }

    std::string path = target;
    std::string query;
    if (size_t q = target.find('?'); q != std::string::npos) {
        path = target.substr(0, q);
        query = target.substr(q + 1);
    }

    Response res;
    Json json;
    bool needsBody = method == "POST";
    if (needsBody && !parseJson(body, json)) {
        res = err(400, "Bad request");
    } else if (method == "POST" && path == "/create") res = handleCreate(json);
    else if (method == "POST" && path == "/join") res = handleJoin(json);
    else if (method == "POST" && path == "/diff") res = handleDiff(json);
    else if (method == "POST" && path == "/leave") res = handleLeave(json);
    else if (method == "GET" && path == "/poll") res = handlePoll(urlParam(query, "code"), urlParam(query, "clientId"));
    else if (method == "GET" && path == "/info") res = handleInfo(urlParam(query, "code"));
    else if (method == "GET" && path == "/") res = {200, "{\"ok\":true}"};
    else res = err(404, "Not found");

    std::string statusText = res.status == 200 ? "OK" : res.status == 404 ? "Not Found" : res.status == 400 ? "Bad Request" : "Error";
    std::string out = "HTTP/1.1 " + std::to_string(res.status) + " " + statusText + "\r\n"
                      "Content-Type: application/json\r\n"
                      "Content-Length: " + std::to_string(res.body.size()) + "\r\n"
                      "Connection: close\r\n\r\n" + res.body;
    sendAll(fd, out);
    ::shutdown(fd, SHUT_RDWR);
    ::close(fd);
}

void acceptLoop(int listenFd) {
    while (true) {
        int fd = ::accept(listenFd, nullptr, nullptr);
        if (fd < 0) {
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
            continue;
        }
        std::thread(handleConnection, fd).detach();
    }
}

// Answers "is anybody hosting this code?" questions from other phones
void discoveryLoop(int fd) {
    char buf[256];
    while (true) {
        sockaddr_in from{};
        socklen_t len = sizeof(from);
        ssize_t n = ::recvfrom(fd, buf, sizeof(buf) - 1, 0, reinterpret_cast<sockaddr*>(&from), &len);
        if (n <= 0) {
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
            continue;
        }
        buf[n] = 0;
        std::string msg(buf);
        if (msg.rfind("ECV2?", 0) != 0) continue;
        std::string code = msg.substr(5);

        bool have;
        {
            std::lock_guard lock(g_mutex);
            auto it = g_sessions.find(code);
            have = it != g_sessions.end() && !it->second.ended;
        }
        if (!have) continue;

        std::string reply = "ECV2!" + std::to_string(g_port.load());
        ::sendto(fd, reply.data(), reply.size(), 0, reinterpret_cast<sockaddr*>(&from), len);
    }
}

void startAll() {
    int listenFd = ::socket(AF_INET, SOCK_STREAM, 0);
    if (listenFd < 0) return;
    int yes = 1;
    setsockopt(listenFd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));

    int port = 0;
    for (int i = 0; i < kPortTries; i++) {
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = htonl(INADDR_ANY);
        addr.sin_port = htons(static_cast<uint16_t>(kFirstPort + i));
        if (::bind(listenFd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) == 0) {
            port = kFirstPort + i;
            break;
        }
    }
    if (port == 0 || ::listen(listenFd, 32) != 0) {
        ::close(listenFd);
        return;
    }
    g_port = port;
    std::thread(acceptLoop, listenFd).detach();

    int udpFd = ::socket(AF_INET, SOCK_DGRAM, 0);
    if (udpFd >= 0) {
        setsockopt(udpFd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = htonl(INADDR_ANY);
        addr.sin_port = htons(kDiscoveryPort);
        if (::bind(udpFd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) == 0) {
            std::thread(discoveryLoop, udpFd).detach();
        } else {
            ::close(udpFd);
        }
    }
}

// ---------------------------------------------------------------------------
// Finding a host on the local network
// ---------------------------------------------------------------------------

struct LocalNet {
    uint32_t addr;  // host byte order
    uint32_t mask;
};

std::vector<LocalNet> localNetworks() {
    std::vector<LocalNet> out;
    int fd = ::socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) return out;

    ifconf ifc{};
    char buffer[4096];
    ifc.ifc_len = sizeof(buffer);
    ifc.ifc_buf = buffer;
    if (::ioctl(fd, SIOCGIFCONF, &ifc) == 0) {
        auto* req = reinterpret_cast<ifreq*>(buffer);
        size_t count = static_cast<size_t>(ifc.ifc_len) / sizeof(ifreq);
        for (size_t i = 0; i < count; i++) {
            ifreq item = req[i];
            if (item.ifr_addr.sa_family != AF_INET) continue;
            uint32_t addr = ntohl(reinterpret_cast<sockaddr_in*>(&item.ifr_addr)->sin_addr.s_addr);

            ifreq flags = item;
            if (::ioctl(fd, SIOCGIFFLAGS, &flags) != 0) continue;
            if (!(flags.ifr_flags & IFF_UP) || (flags.ifr_flags & IFF_LOOPBACK)) continue;

            ifreq netmask = item;
            uint32_t mask = 0xFFFFFF00;
            if (::ioctl(fd, SIOCGIFNETMASK, &netmask) == 0)
                mask = ntohl(reinterpret_cast<sockaddr_in*>(&netmask.ifr_addr)->sin_addr.s_addr);

            out.push_back({addr, mask});
        }
    }
    ::close(fd);
    return out;
}

std::string ipToString(uint32_t ip) {
    in_addr a{};
    a.s_addr = htonl(ip);
    char buf[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &a, buf, sizeof(buf));
    return buf;
}

} // namespace

int startLocalServer() {
    std::call_once(g_startOnce, startAll);
    return g_port.load();
}

std::string discoverHost(std::string const& code) {
    // Where to ask: every network broadcast address, plus the usual
    // "phone hotspot" addresses (a hotspot host is normally the .1 address)
    std::vector<std::string> targets;
    auto add = [&](std::string ip) {
        if (std::find(targets.begin(), targets.end(), ip) == targets.end()) targets.push_back(ip);
    };

    for (auto& net : localNetworks()) {
        uint32_t network = net.addr & net.mask;
        add(ipToString(network | ~net.mask));  // broadcast address
        add(ipToString(network | 1));          // usual gateway / hotspot host
        add(ipToString(network | 2));
    }
    add("255.255.255.255");
    add("192.168.43.1");  // Android hotspot
    add("192.168.49.1");  // Wi-Fi Direct
    add("172.20.10.1");   // iPhone hotspot
    add("192.168.137.1"); // Windows hotspot

    int fd = ::socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) return "";
    int yes = 1;
    setsockopt(fd, SOL_SOCKET, SO_BROADCAST, &yes, sizeof(yes));

    std::string query = "ECV2?" + code;
    auto sendAllTargets = [&] {
        for (auto& ip : targets) {
            sockaddr_in to{};
            to.sin_family = AF_INET;
            to.sin_port = htons(kDiscoveryPort);
            if (inet_pton(AF_INET, ip.c_str(), &to.sin_addr) != 1) continue;
            ::sendto(fd, query.data(), query.size(), 0, reinterpret_cast<sockaddr*>(&to), sizeof(to));
        }
    };

    std::string result;
    auto start = std::chrono::steady_clock::now();
    auto lastSend = start - std::chrono::seconds(10);

    while (std::chrono::steady_clock::now() - start < std::chrono::milliseconds(3500)) {
        auto now = std::chrono::steady_clock::now();
        if (now - lastSend > std::chrono::milliseconds(700)) {
            sendAllTargets();
            lastSend = now;
        }

        timeval tv{};
        tv.tv_sec = 0;
        tv.tv_usec = 200 * 1000;
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

        char buf[128];
        sockaddr_in from{};
        socklen_t len = sizeof(from);
        ssize_t n = ::recvfrom(fd, buf, sizeof(buf) - 1, 0, reinterpret_cast<sockaddr*>(&from), &len);
        if (n <= 0) continue;
        buf[n] = 0;
        std::string msg(buf);
        if (msg.rfind("ECV2!", 0) != 0) continue;

        char ip[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &from.sin_addr, ip, sizeof(ip));
        result = std::string("http://") + ip + ":" + msg.substr(5);
        break;
    }

    ::close(fd);
    return result;
}

#endif // !_WIN32

} // namespace collab
